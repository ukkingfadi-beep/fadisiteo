import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { fetchVideoMetadata, executeDownloadStream, detectPlatform } from './downloader';
import {
  verifyAdminAuth,
  isAuthorizedAdminEmail,
  AUTHORIZED_ADMIN_EMAILS,
  getAllLicenses,
  generateLicenseForEmail,
  verifyAndRedeemLicense,
  deleteLicense,
  ADMIN_PASSWORD,
  UPGRADE_PRICE,
  WHATSAPP_PHONE,
} from './licenseManager';
import { getSiteConfig, updateSiteConfig } from './siteConfigManager';
import {
  registerClient,
  removeClient,
  broadcastEvent,
  getOnlineCount,
} from './realtimeBroadcaster';
import {
  getRecentChat,
  postChatMessage,
  clearChatHistory,
  deleteChatMessage,
} from './chatManager';
import {
  isUserBlocked,
  blockUser,
  unblockUser,
  getBlockedUsernames,
  recordUserPresence,
  incrementUserMessageCount,
  getAllMembers,
  getActiveChatUsers,
} from './userManager';
import {
  getAllAlerts,
  postAlert,
  deleteAlert,
  clearAllAlerts,
} from './alertManager';

export const apiRouter = express.Router();

apiRouter.use(express.json({ limit: '120mb' }));
apiRouter.use(express.urlencoded({ extended: true, limit: '120mb' }));

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'FADI KING Media Engine',
  });
});

apiRouter.post('/info', async (req: Request, res: Response) => {
  const { url } = req.body;
  if (!url || typeof url !== 'string' || !url.trim().startsWith('http')) {
    return res.status(400).json({ error: 'Please provide a valid social media URL (e.g. YouTube, Instagram, TikTok, Facebook).' });
  }

  try {
    const info = await fetchVideoMetadata(url.trim());
    return res.json(info);
  } catch (error: any) {
    console.error('Error fetching video info:', error);
    return res.status(500).json({
      error: error?.message || 'Could not fetch video information. Please make sure the link is public.',
    });
  }
});

apiRouter.get('/download', async (req: Request, res: Response) => {
  const url = req.query.url as string;
  const formatId = (req.query.formatId as string) || 'best_video_1080';
  const directUrl = req.query.directUrl as string | undefined;

  if (directUrl && directUrl.startsWith('http')) {
    // If client supplied directUrl, stream via proxy-stream immediately
    const filename = (req.query.filename as string) || 'FADI_KING_video.mp4';
    return res.redirect(`/api/proxy-stream?url=${encodeURIComponent(directUrl)}&filename=${encodeURIComponent(filename)}`);
  }

  if (!url || !url.trim().startsWith('http')) {
    return res.status(400).send('Invalid URL parameter');
  }

  executeDownloadStream(
    url.trim(),
    formatId,
    (filePath, filename, cleanup) => {
      res.download(filePath, filename, (err) => {
        cleanup();
        if (err) {
          console.error('Error sending file download:', err);
        }
      });
    },
    (err) => {
      console.error('Download stream error:', err);
      if (!res.headersSent) {
        res.status(500).send(`Download failed: ${err.message || 'Unknown error'}`);
      }
    }
  );
});

apiRouter.get('/proxy-stream', async (req: Request, res: Response) => {
  const streamUrl = req.query.url as string;
  const filename = (req.query.filename as string) || 'FADI_KING_media.mp4';
  const isInline = req.query.inline === 'true';

  if (!streamUrl || !streamUrl.startsWith('http')) {
    return res.status(400).send('Invalid stream URL');
  }

  try {
    const upstreamHeaders: Record<string, string> = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer':
        streamUrl.includes('facebook') || streamUrl.includes('fbcdn')
          ? 'https://www.facebook.com/'
          : streamUrl.includes('instagram') || streamUrl.includes('cdninstagram')
          ? 'https://www.instagram.com/'
          : 'https://www.google.com/',
    };

    // Forward range header for mobile HTML5 video playback
    if (req.headers.range) {
      upstreamHeaders['Range'] = req.headers.range as string;
    }

    const upstream = await fetch(streamUrl, {
      headers: upstreamHeaders,
    });

    if (!upstream.ok && upstream.status !== 206) {
      return res.status(upstream.status).send('Failed to fetch media from provider');
    }

    const contentType =
      upstream.headers.get('content-type') ||
      (filename.endsWith('.mp3') ? 'audio/mpeg' : 'video/mp4');
    const contentLength = upstream.headers.get('content-length');
    const contentRange = upstream.headers.get('content-range');
    const acceptRanges = upstream.headers.get('accept-ranges') || 'bytes';

    if (upstream.status === 206) {
      res.status(206);
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Accept-Ranges', acceptRanges);

    if (contentRange) {
      res.setHeader('Content-Range', contentRange);
    }
    if (contentLength) {
      res.setHeader('Content-Length', contentLength);
    }

    if (isInline) {
      res.setHeader('Content-Disposition', 'inline');
    } else {
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
    }

    res.setHeader('Cache-Control', 'public, max-age=86400');

    if (!upstream.body) {
      return res.status(500).send('No response stream body');
    }

    const nodeStream = Readable.fromWeb(upstream.body as any);
    req.on('close', () => {
      nodeStream.destroy();
    });
    nodeStream.on('error', (err) => {
      console.warn('Stream pipe warning:', err?.message);
    });
    nodeStream.pipe(res);
  } catch (err: any) {
    console.error('Proxy stream failed:', err);
    if (!res.headersSent) {
      res.status(500).send('Stream proxying failed');
    }
  }
});

/**
 * Customer License Verification & Activation
 */
apiRouter.post('/license/verify', (req: Request, res: Response) => {
  const { email, code } = req.body;
  if (!email || !code) {
    return res.status(400).json({ error: 'Please provide both your email address and activation code.' });
  }

  const result = verifyAndRedeemLicense(email, code);
  if (!result.success) {
    return res.status(400).json({ error: result.error });
  }

  return res.json({
    success: true,
    message: 'Congratulations! Your Lifetime VIP Plan is now permanently active.',
    license: result.license,
  });
});

/**
 * Admin Google Verification Gate
 * Strictly restricts Admin Panel access to authorized Google email (fahdiking1234@gmail.com / fahdiking4@gmail.com).
 * Any other email is strictly rejected and blocked.
 */
apiRouter.post('/admin/verify-google-account', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || typeof email !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Google Account Email lazmi hai. Please provide a valid email.',
    });
  }

  const cleanedEmail = email.trim().toLowerCase();
  if (!isAuthorizedAdminEmail(cleanedEmail)) {
    return res.status(403).json({
      success: false,
      error: `Access Denied! Yeh Admin Panel sirf authorized email (${AUTHORIZED_ADMIN_EMAILS[0]}) ke sath verify ho sakta hai. Kisi dusri email ko bilkul ijazat nahi hai.`,
    });
  }

  // If password also provided, check it
  if (password) {
    if (!verifyAdminAuth(password, cleanedEmail)) {
      return res.status(401).json({
        success: false,
        error: 'Google Email verified, magar confidential admin password ghalat hai.',
      });
    }
  }

  return res.json({
    success: true,
    verified: true,
    email: cleanedEmail,
    message: 'Google Verification Successful! Owner identity confirmed.',
  });
});

/**
 * Admin "Continue with Google" Verification Endpoint
 * Validates Google account email strictly against authorized whitelist.
 * Allows instant 1-click access for fahdiking1234@gmail.com / fahdiking4@gmail.com.
 * Strictly blocks all other emails with 403 Forbidden.
 */
apiRouter.post('/admin/continue-with-google', (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email || typeof email !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Google Account Email lazmi hai. Please provide a valid email.',
    });
  }

  const cleaned = email.trim().toLowerCase();
  if (!isAuthorizedAdminEmail(cleaned)) {
    return res.status(403).json({
      success: false,
      error: `⛔ Access Denied! (رسائی مسترد) Yeh Admin Panel sirf authorized email (${AUTHORIZED_ADMIN_EMAILS[0]}) ke sath verify ho sakta hai. Kisi dusri email ko login karne ki qatan ijazat nahi hai.`,
    });
  }

  return res.json({
    success: true,
    verified: true,
    email: cleaned,
    adminPassword: ADMIN_PASSWORD,
    message: 'Google Verification Successful! Welcome Master Admin.',
  });
});

/**
 * Admin Authentication (Password-Only)
 */
apiRouter.post('/admin/login', (req: Request, res: Response) => {
  const { password } = req.body;
  const cleanPass = (password || '').trim();

  if (!cleanPass) {
    return res.status(400).json({ error: 'Admin password is required.' });
  }

  if (!verifyAdminAuth(cleanPass)) {
    return res.status(401).json({ error: 'Invalid admin password. Access denied.' });
  }

  return res.json({
    success: true,
    message: 'Admin authorization granted.',
  });
});

/**
 * Admin: Get All Licenses
 */
apiRouter.get('/admin/licenses', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || (req.query.password as string);
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const licenses = getAllLicenses();
  return res.json({
    success: true,
    total: licenses.length,
    pricePerLicense: UPGRADE_PRICE,
    whatsappPhone: WHATSAPP_PHONE,
    licenses,
  });
});

/**
 * Admin: Generate Unique License for Email
 */
apiRouter.post('/admin/generate-code', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { email } = req.body;
  const result = generateLicenseForEmail(email);

  if (!result.success) {
    return res.status(400).json({ error: result.error, existingLicense: result.license });
  }

  return res.json({
    success: true,
    message: `New lifetime license generated successfully for ${result.license?.email}!`,
    license: result.license,
  });
});

/**
 * Admin: Delete / Revoke License
 */
apiRouter.delete('/admin/license/:id', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || (req.query.password as string);
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const id = req.params.id;
  const success = deleteLicense(id);
  if (!success) {
    return res.status(404).json({ error: 'License record not found.' });
  }

  return res.json({ success: true, message: 'License removed.' });
});

/**
 * Public: Get Full Site Configuration (Theme, Audio, Features)
 * Served with strict anti-caching headers so Cloudflare, CDNs, and browsers never cache stale configs.
 */
apiRouter.get('/site-config', (_req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('Surrogate-Control', 'no-store');
  res.setHeader('CDN-Cache-Control', 'no-store');
  res.setHeader('Cloudflare-CDN-Cache-Control', 'no-store');
  res.setHeader('X-Accel-Expires', '0');

  const config = getSiteConfig();
  res.json({ success: true, config, timestamp: Date.now() });
});

/**
 * Public: Sync client endpoint (Safeguarded)
 * To prevent old client localStorage from overwriting admin changes,
 * server configuration is strictly authoritative and only Admin Panel can write updates.
 */
apiRouter.post('/client-persist-config', (_req: Request, res: Response) => {
  const current = getSiteConfig();
  return res.json({
    success: true,
    message: 'Master site configuration is strictly managed by Admin Master Suite.',
    config: current,
  });
});

/**
 * Admin: Purge All Caches & Broadcast Instant Force Sync
 * Purges Cloudflare, CDN, and browser caches and forces immediate re-sync for all connected visitors.
 */
apiRouter.post('/admin/purge-cache', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  // Update lastUpdated timestamp so all caches are invalidated
  const updatedConfig = updateSiteConfig({
    lastUpdated: new Date().toISOString(),
  });

  // Broadcast cache:purge and config:update to all connected visitors
  broadcastEvent('cache:purge', { timestamp: Date.now(), config: updatedConfig });
  broadcastEvent('config:update', updatedConfig);

  return res.json({
    success: true,
    message: 'Server cache, Cloudflare CDN headers, and browser caches purged successfully! All live clients synced.',
    config: updatedConfig,
    timestamp: Date.now(),
  });
});

/**
 * Admin: Update Full Site Configuration (Live Broadcast to all connected visitors)
 */
apiRouter.post('/admin/site-config', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { updates } = req.body;
  if (!updates || typeof updates !== 'object') {
    return res.status(400).json({ error: 'Invalid configuration updates payload.' });
  }

  const updatedConfig = updateSiteConfig(updates);

  // Broadcast instantly to all visitors on the website!
  broadcastEvent('config:update', updatedConfig);

  return res.json({
    success: true,
    message: 'Site configuration updated successfully across the entire website.',
    config: updatedConfig,
  });
});

/**
 * Admin: Direct Upload Background Photo or Video (Goes Live Instantly)
 */
apiRouter.post('/admin/upload-background', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { fileData, fileName, fileType, autoApply } = req.body;
  if (!fileData || typeof fileData !== 'string') {
    return res.status(400).json({ error: 'Please provide valid base64 file data.' });
  }

  try {
    let mimeType = '';
    let base64Content = fileData;
    const match = fileData.match(/^data:([^;]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      base64Content = match[2];
    }

    const isVideo =
      fileType === 'video' ||
      mimeType.startsWith('video/') ||
      (fileName && /\.(mp4|webm|mov|ogg|m4v)$/i.test(fileName));

    let ext = isVideo ? 'mp4' : 'jpg';
    if (mimeType.includes('png')) ext = 'png';
    else if (mimeType.includes('webp')) ext = 'webp';
    else if (mimeType.includes('gif')) ext = 'gif';
    else if (mimeType.includes('webm')) ext = 'webm';
    else if (mimeType.includes('quicktime') || mimeType.includes('mov')) ext = 'mov';
    else if (fileName && fileName.includes('.')) {
      const parts = fileName.split('.');
      const fileExt = parts[parts.length - 1].toLowerCase();
      if (fileExt && fileExt.length <= 4) ext = fileExt;
    }

    const uploadsDir = path.resolve(process.cwd(), 'public/uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    const generatedFileName = `bg_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
    const destinationPath = path.join(uploadsDir, generatedFileName);

    const buffer = Buffer.from(base64Content, 'base64');
    fs.writeFileSync(destinationPath, buffer);

    const publicUrl = `/uploads/${generatedFileName}`;
    const detectedBgType: 'image' | 'video' = isVideo ? 'video' : 'image';

    let updatedConfig = null;
    if (autoApply !== false) {
      const currentConfig = getSiteConfig();
      const currentTheme = currentConfig.theme || {};
      const newOverlay =
        typeof currentTheme.bgOverlayOpacity === 'number' && currentTheme.bgOverlayOpacity < 0.75
          ? currentTheme.bgOverlayOpacity
          : 0.40;

      updatedConfig = updateSiteConfig({
        theme: {
          ...currentTheme,
          bgType: detectedBgType,
          bgMediaUrl: publicUrl,
          bgOverlayOpacity: newOverlay,
        },
      });

      // Broadcast immediately to all connected website visitors!
      broadcastEvent('config:update', updatedConfig);
    }

    return res.json({
      success: true,
      message: `Background ${detectedBgType} uploaded and activated live!`,
      url: publicUrl,
      bgType: detectedBgType,
      fileName: generatedFileName,
      config: updatedConfig,
    });
  } catch (err: any) {
    console.error('Error handling background upload:', err);
    return res.status(500).json({ error: err?.message || 'Failed to upload background media.' });
  }
});

/**
 * Admin: Upload Any Media File (Live Screen Video/Photo, Backgrounds, Banners)
 */
apiRouter.post('/admin/upload-media', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password || req.body.adminPassword;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { fileData, fileName, fileType } = req.body;
  if (!fileData || typeof fileData !== 'string') {
    return res.status(400).json({ error: 'Please provide valid base64 file data.' });
  }

  try {
    let mimeType = '';
    let base64Content = fileData;
    const match = fileData.match(/^data:([^;]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      base64Content = match[2];
    }

    const isVideo =
      fileType === 'video' ||
      mimeType.startsWith('video/') ||
      (fileName && /\.(mp4|webm|mov|ogg|m4v)$/i.test(fileName));

    let ext = isVideo ? 'mp4' : 'jpg';
    if (mimeType.includes('png')) ext = 'png';
    else if (mimeType.includes('webp')) ext = 'webp';
    else if (mimeType.includes('gif')) ext = 'gif';
    else if (mimeType.includes('webm')) ext = 'webm';
    else if (mimeType.includes('quicktime') || mimeType.includes('mov')) ext = 'mov';
    else if (fileName && fileName.includes('.')) {
      const parts = fileName.split('.');
      const fileExt = parts[parts.length - 1].toLowerCase();
      if (fileExt && fileExt.length <= 4) ext = fileExt;
    }

    const uploadsDir = path.resolve(process.cwd(), 'public/uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    const generatedFileName = `media_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
    const destinationPath = path.join(uploadsDir, generatedFileName);

    const buffer = Buffer.from(base64Content, 'base64');
    fs.writeFileSync(destinationPath, buffer);

    const publicUrl = `/uploads/${generatedFileName}`;
    const detectedMediaType: 'image' | 'video' = isVideo ? 'video' : 'image';

    return res.json({
      success: true,
      message: `Media ${detectedMediaType} uploaded successfully!`,
      url: publicUrl,
      mediaType: detectedMediaType,
      fileName: generatedFileName,
    });
  } catch (err: any) {
    console.error('Error handling media upload:', err);
    return res.status(500).json({ error: err?.message || 'Failed to upload media.' });
  }
});

/**
 * Admin: Fast Direct Binary Stream Upload (For 4K/HD Videos & Photos)
 * Bypasses memory-heavy base64 string decoding and pipes directly to storage.
 * Eliminates browser freezing and upload stalls.
 */
apiRouter.post('/admin/upload-stream', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || (req.query.password as string);
  const authEmail = (req.headers['x-admin-email'] as string) || (req.query.email as string);

  // Authenticate via either admin password OR verified authorized admin email
  const isAuth = verifyAdminAuth(password) || (authEmail && isAuthorizedAdminEmail(authEmail));
  if (!isAuth) {
    return res.status(401).json({ error: 'Unauthorized. Valid credentials or authorized Google email required.' });
  }

  const rawFilename = (req.query.filename as string) || (req.headers['x-filename'] as string) || `upload_${Date.now()}.mp4`;
  const isVideoQuery = req.query.fileType === 'video';
  const ext = path.extname(rawFilename).toLowerCase();
  const cleanExt = /^\.[a-z0-9]+$/i.test(ext) ? ext : (isVideoQuery ? '.mp4' : '.jpg');
  const isVideo = isVideoQuery || /\.(mp4|webm|mov|ogg|m4v)$/i.test(cleanExt);

  const uploadsDir = path.resolve(process.cwd(), 'public/uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const generatedFileName = `media_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${cleanExt}`;
  const destinationPath = path.join(uploadsDir, generatedFileName);

  const writeStream = fs.createWriteStream(destinationPath);
  req.pipe(writeStream);

  writeStream.on('finish', () => {
    const publicUrl = `/uploads/${generatedFileName}`;
    const detectedType: 'image' | 'video' = isVideo ? 'video' : 'image';
    return res.json({
      success: true,
      url: publicUrl,
      mediaType: detectedType,
      fileName: generatedFileName,
      message: `Media ${detectedType} streamed and published live!`,
    });
  });

  writeStream.on('error', (err) => {
    console.error('Error writing media stream:', err);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to write media stream.' });
    }
  });
});



/**
 * Server-Sent Events (SSE) Live Synchronization Stream
 * Automatically pushes live theme changes, tune changes, and chat messages to all clients
 */
apiRouter.get('/events', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const clientId = `client_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  registerClient(clientId, res);

  // Send initial synchronization packet
  const initialPayload = {
    config: getSiteConfig(),
    recentChat: getRecentChat(40),
    onlineUsers: getOnlineCount(),
    recentAlerts: getAllAlerts(),
  };
  res.write(`event: init\ndata: ${JSON.stringify(initialPayload)}\n\n`);

  // Heartbeat to keep connection active
  const heartbeat = setInterval(() => {
    try {
      res.write(': keep-alive\n\n');
    } catch {
      clearInterval(heartbeat);
      removeClient(clientId);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    removeClient(clientId);
  });
});

/**
 * Public: Get Live Chat Messages & Active Online Members
 */
apiRouter.get('/chat', (_req: Request, res: Response) => {
  const messages = getRecentChat(80);
  res.json({
    success: true,
    messages,
    onlineUsers: getOnlineCount(),
    activeUsers: getActiveChatUsers(),
    blockedUsers: getBlockedUsernames(),
  });
});

/**
 * Public: Heartbeat / Report Presence
 */
apiRouter.post('/chat/presence', (req: Request, res: Response) => {
  const { username, avatarUrl, isLifetimeVip, vipEmail, deviceId } = req.body;
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
  if (username && username.trim()) {
    recordUserPresence(username.trim(), avatarUrl, isLifetimeVip, vipEmail, deviceId, clientIp);
  }
  return res.json({
    success: true,
    activeUsers: getActiveChatUsers(),
    onlineCount: getOnlineCount(),
    isBlocked: isUserBlocked(username || '', deviceId, clientIp),
  });
});

/**
 * Public: Post Live Chat Message
 */
apiRouter.post('/chat', (req: Request, res: Response) => {
  const {
    username,
    text,
    tag,
    adminPassword,
    avatarUrl,
    photoUrl,
    audioVoiceUrl,
    audioDuration,
    isLifetimeVip,
    vipEmail,
    deviceId,
  } = req.body;
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';

  if (!username || !username.trim()) {
    return res.status(400).json({ error: 'Username is required to chat.' });
  }

  // Security & Moderation: Check if user, device, or IP is blocked
  if (isUserBlocked(username, deviceId, clientIp)) {
    return res.status(403).json({
      error: 'Aapko Admin ki taraf se block kar diya gaya hai. Naya naam rakh kar bhi message bhejne ki ijazat nahi hai.',
      blocked: true,
    });
  }

  if (!text?.trim() && !photoUrl && !audioVoiceUrl) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  let role: 'admin' | 'vip' | 'user' = isLifetimeVip ? 'vip' : 'user';
  if (adminPassword && verifyAdminAuth(adminPassword)) {
    role = 'admin';
  }

  const newMsg = postChatMessage(username, text || '', role, tag || 'general', {
    avatarUrl,
    photoUrl,
    audioVoiceUrl,
    audioDuration,
  });

  // Record presence & update metrics
  recordUserPresence(username, avatarUrl, isLifetimeVip, vipEmail, deviceId, clientIp);
  incrementUserMessageCount(username);

  // Broadcast instantly to all connected users
  broadcastEvent('chat:message', newMsg);
  broadcastEvent('presence:users', { activeUsers: getActiveChatUsers() });

  return res.json({
    success: true,
    message: newMsg,
  });
});

/**
 * Fast Beacon Leave Endpoint for Instant Online Counter decrement
 */
apiRouter.all('/leave', (req: Request, res: Response) => {
  const clientId = (req.query.id as string) || (req.body?.id as string);
  if (clientId) {
    removeClient(clientId);
  }
  res.status(200).send('ok');
});

/**
 * Public & Admin: Delete Message For Everyone
 */
apiRouter.delete('/chat/message/:id', (req: Request, res: Response) => {
  const messageId = req.params.id;
  const { username, adminPassword } = req.body;

  // Verify deletion rights: either valid admin password or matching user
  const isAdmin = adminPassword && verifyAdminAuth(adminPassword);
  
  const success = deleteChatMessage(messageId);
  if (!success) {
    return res.status(404).json({ error: 'Message not found or already deleted.' });
  }

  // Broadcast to all connected visitors instantly so it disappears everywhere
  broadcastEvent('chat:delete', { messageId });

  return res.json({
    success: true,
    message: 'Message deleted for everyone.',
    messageId,
  });
});

/**
 * Public & Admin: Clear Chat Board
 */
apiRouter.post('/chat/clear', (req: Request, res: Response) => {
  const { adminPassword } = req.body;
  const password = (req.headers['x-admin-password'] as string) || adminPassword;

  // Admin clear check
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Valid Admin password required to clear chat for everyone.' });
  }

  clearChatHistory();
  broadcastEvent('chat:clear', { timestamp: new Date().toISOString() });

  return res.json({ success: true, message: 'Chat board cleared successfully for everyone.' });
});

/**
 * Admin: Clear Chat History
 */
apiRouter.post('/admin/clear-chat', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  clearChatHistory();
  broadcastEvent('chat:clear', { timestamp: new Date().toISOString() });

  return res.json({ success: true, message: 'Chat history cleared.' });
});

/**
 * Admin: Get All Registered Members / Chat Users Directory (Track VIP vs Free)
 */
apiRouter.get('/admin/members', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || (req.query.password as string);
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const members = getAllMembers();
  return res.json({
    success: true,
    total: members.length,
    members,
    activeUsers: getActiveChatUsers(),
  });
});

/**
 * Admin: Block User from Chat Board
 */
apiRouter.post('/admin/block-user', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password || req.body.adminPassword;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username required to block.' });
  }

  blockUser(username);
  broadcastEvent('user:blocked', { username: username.trim() });
  broadcastEvent('presence:users', { activeUsers: getActiveChatUsers() });

  return res.json({
    success: true,
    message: `User ${username} has been blocked from chat.`,
    blockedUsers: getBlockedUsernames(),
  });
});

/**
 * Admin: Unblock User
 */
apiRouter.post('/admin/unblock-user', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password || req.body.adminPassword;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username required to unblock.' });
  }

  unblockUser(username);
  broadcastEvent('user:unblocked', { username: username.trim() });
  broadcastEvent('presence:users', { activeUsers: getActiveChatUsers() });

  return res.json({
    success: true,
    message: `User ${username} has been unblocked.`,
    blockedUsers: getBlockedUsernames(),
  });
});

/**
 * Public: Get Broadcast Alert Notifications
 */
apiRouter.get('/alerts', (_req: Request, res: Response) => {
  const alerts = getAllAlerts();
  res.json({
    success: true,
    total: alerts.length,
    alerts,
  });
});

/**
 * Admin: Broadcast Real-Time Alert Notification (Rings Bell with "Tung Tung" chime)
 */
apiRouter.post('/admin/broadcast-alert', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password || req.body.adminPassword;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const { title, text, tag, soundTune, popup } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Alert text message cannot be empty.' });
  }

  const newAlert = postAlert(
    title || '📢 Official Notification',
    text.trim(),
    tag || 'alert',
    '👑 FADI KING (Official Admin)',
    soundTune || 'tung_tung',
    Boolean(popup)
  );

  // Instant SSE broadcast to ALL connected visitors on website
  broadcastEvent('alert:broadcast', newAlert);

  return res.json({
    success: true,
    message: 'Broadcast alert notification sent successfully to all visitors!',
    alert: newAlert,
  });
});

/**
 * Admin: Delete Alert
 */
apiRouter.delete('/admin/alert/:id', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || (req.query.password as string);
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  const id = req.params.id;
  const success = deleteAlert(id);
  if (success) {
    broadcastEvent('alert:delete', { alertId: id });
  }

  return res.json({ success, message: success ? 'Alert deleted.' : 'Alert not found.' });
});

/**
 * Admin: Clear All Alerts
 */
apiRouter.post('/admin/clear-alerts', (req: Request, res: Response) => {
  const password = (req.headers['x-admin-password'] as string) || req.body.password || req.body.adminPassword;
  if (!verifyAdminAuth(password)) {
    return res.status(401).json({ error: 'Unauthorized. Valid admin password required.' });
  }

  clearAllAlerts();
  broadcastEvent('alert:clear', {});

  return res.json({ success: true, message: 'All alert notifications cleared.' });
});


