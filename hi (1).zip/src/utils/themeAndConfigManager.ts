export type IconStyleType = '3d' | '2d' | 'animated' | 'colorful_glass';

export type ThemePreset =
  | 'obsidian_gold'
  | 'royal_espresso_brown'
  | 'crystal_white_glass'
  | 'midnight_cyan'
  | 'royal_emerald'
  | 'graphite_dark'
  | 'custom';

export type AnimationThemeType =
  | 'royal_gold_shimmer'
  | 'cyber_matrix'
  | 'cosmic_nebula'
  | 'neon_synthwave'
  | 'quantum_waves'
  | 'crystal_aurora'
  | 'clean_slate';

export interface ThemeDefinition {
  id: ThemePreset;
  preset?: ThemePreset;
  name: string;
  tagline: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  cardBg: string;
  borderColor: string;
  isWatercolor: boolean;
  paperTexture: boolean;
  glowIntensity: 'subtle' | 'vibrant' | 'ultra';
  animationTheme: AnimationThemeType;
  iconStyle?: IconStyleType;
  bgType: 'color' | 'image' | 'video';
  bgMediaUrl: string;
  bgOverlayOpacity: number;
  bgBlur: number;
}

export const THEME_PRESETS: Record<ThemePreset, ThemeDefinition> = {
  obsidian_gold: {
    id: 'obsidian_gold',
    preset: 'obsidian_gold',
    name: 'Royal Espresso Brown & Metallic Gold VIP',
    tagline: 'Deep espresso chocolate brown (#140c07 / #1e130a) with luxury metallic gold (#d4af37) & cognac bronze accents',
    primaryColor: '#d4af37',
    secondaryColor: '#c68642',
    accentColor: '#f59e0b',
    backgroundColor: '#140c07',
    cardBg: '#1e130a/90',
    borderColor: '#d4af37/30',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'vibrant',
    animationTheme: 'royal_gold_shimmer',
    iconStyle: '3d',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.88,
    bgBlur: 2,
  },
  royal_espresso_brown: {
    id: 'royal_espresso_brown',
    preset: 'royal_espresso_brown',
    name: 'Imperial Cognac & Mahogany Brown VIP',
    tagline: 'Ultra luxury smoked mocha mahogany with warm amber highlights and 24K gold borders',
    primaryColor: '#f5c542',
    secondaryColor: '#b45309',
    accentColor: '#e5a950',
    backgroundColor: '#160d08',
    cardBg: '#22140d/90',
    borderColor: '#c68642/40',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'ultra',
    animationTheme: 'royal_gold_shimmer',
    iconStyle: '3d',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.90,
    bgBlur: 2,
  },
  midnight_cyan: {
    id: 'midnight_cyan',
    preset: 'midnight_cyan',
    name: 'Midnight Titanium Cyan',
    tagline: 'Deep oceanic abyss with electric cyan shimmer and platinum',
    primaryColor: '#06b6d4',
    secondaryColor: '#0891b2',
    accentColor: '#38bdf8',
    backgroundColor: '#050b14',
    cardBg: '#0a1628/90',
    borderColor: '#06b6d4/35',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'vibrant',
    animationTheme: 'cyber_matrix',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.85,
    bgBlur: 2,
  },
  royal_emerald: {
    id: 'royal_emerald',
    preset: 'royal_emerald',
    name: 'Imperial Emerald & Gold',
    tagline: 'Deep jade sovereign luxury with metallic golden shimmer',
    primaryColor: '#10b981',
    secondaryColor: '#059669',
    accentColor: '#f59e0b',
    backgroundColor: '#040d0a',
    cardBg: '#091a13/90',
    borderColor: '#10b981/35',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'vibrant',
    animationTheme: 'royal_gold_shimmer',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.85,
    bgBlur: 2,
  },
  graphite_dark: {
    id: 'graphite_dark',
    preset: 'graphite_dark',
    name: 'Graphite Minimalist Dark',
    tagline: 'High contrast clean monochrome slate with silver accents',
    primaryColor: '#94a3b8',
    secondaryColor: '#64748b',
    accentColor: '#e2e8f0',
    backgroundColor: '#07090e',
    cardBg: '#0f121a/90',
    borderColor: '#475569/40',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'subtle',
    animationTheme: 'clean_slate',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.85,
    bgBlur: 2,
  },
  crystal_white_glass: {
    id: 'crystal_white_glass',
    preset: 'crystal_white_glass',
    name: 'Crystal White Pure Glass (Clean & Bright)',
    tagline: 'Ultra modern pure frosted crystal glass aesthetic with high readability',
    primaryColor: '#d97706',
    secondaryColor: '#b45309',
    accentColor: '#2563eb',
    backgroundColor: '#f1f5f9',
    cardBg: '#ffffff/90',
    borderColor: '#cbd5e1/80',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'subtle',
    animationTheme: 'clean_slate',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.90,
    bgBlur: 2,
  },
  custom: {
    id: 'custom',
    preset: 'custom',
    name: 'Custom Tailored Palette',
    tagline: 'Admin defined custom color blend',
    primaryColor: '#eab308',
    secondaryColor: '#ca8a04',
    accentColor: '#10b981',
    backgroundColor: '#070a12',
    cardBg: '#0e1424/90',
    borderColor: '#eab308/30',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'vibrant',
    animationTheme: 'royal_gold_shimmer',
    bgType: 'color',
    bgMediaUrl: '',
    bgOverlayOpacity: 0.85,
    bgBlur: 2,
  },
};

export interface HobbyTrack {
  id: string;
  name: string;
  genre: string;
  mood: string;
  bpm: number;
}

export const HOBBY_TRACKS: HobbyTrack[] = [
  { id: 'good_night_lofi', name: '🌙 FADI KING Good Night Lo-Fi (Dream Sleep Beats)', genre: 'Bedtime Lo-Fi Chill', mood: 'Peaceful Night Sleep & Deep Rest', bpm: 60 },
  { id: 'midnight_rain', name: '🌧️ Midnight Rain on Window & Distant Thunder', genre: 'Sleep Ambience', mood: 'Calming Rain & White Noise', bpm: 55 },
  { id: 'pakistani_sad_rubab', name: 'Dard Bhari Pashto & Sufi Rubab (Sad Instrumental) 😢', genre: 'Sad Rubab Instrumental', mood: 'Melancholic Strings & Deep Emotion', bpm: 68 },
  { id: 'pakistani_sad_darbari', name: 'Dukhi Raag Darbari Bansuri & Sarangi 😢', genre: 'Raag Darbari Sad Melancholy', mood: 'Heart Touching Sad Pakistani Classical', bpm: 62 },
  { id: 'pakistani_sad_ghazal', name: 'Ghamgheen Ghazal Harmonium & Rubab 😢', genre: 'Sad Ghazal Acoustic', mood: 'Soulful Nostalgia & Heartbreak', bpm: 70 },
  { id: 'pakistani_sad_tanhai', name: 'Tanhai Sad Flute & Deep Melancholy 😢', genre: 'Bansuri Sad Serenade', mood: 'Late Night Sad Reflection', bpm: 64 },
  { id: 'pakistani_coke_studio_sad', name: 'Coke Studio Soulful Sad Fusion', genre: 'Eastern Melancholy Fusion', mood: 'Deep Ambient Sitar & Acoustic', bpm: 72 },
  { id: 'royal_lounge', name: 'Royal Lo-Fi Chill Lounge', genre: 'Lo-Fi Chill', mood: 'Smooth & Relaxing', bpm: 84 },
  { id: 'deep_focus', name: 'Deep Ambient Calm', genre: 'Ambient Chill', mood: 'Dreamy & Peaceful', bpm: 75 },
  { id: 'custom_audio', name: 'Custom Stream / MP3 URL', genre: 'Custom Stream', mood: 'Admin Defined', bpm: 0 },
];

export interface LayoutConfig {
  containerWidth: '5xl' | '6xl' | '7xl' | 'full';
  dashboardStyle: 'dual_panel' | 'stacked' | 'compact';
  quickActionsPosition: 'top' | 'bottom' | 'hero';
  chatWidgetPosition: 'bottom-right' | 'bottom-left' | 'top-right' | 'embedded_card';
  searchBarPosition: 'top' | 'centered';
  headerStyle: 'royal_gold_vip' | 'classic' | 'minimal';
  borderGlow: boolean;
}

export interface ChatSecurityConfig {
  locked: boolean;
  lockNotice: string;
  requireVerification: boolean;
  vipOnly: boolean;
  botEnabled: boolean;
}

export interface ShowcaseSlide {
  id: string;
  tag: string;
  title: string;
  subtitle: string;
  price?: string;
  mediaType: 'image' | 'video';
  mediaUrl: string;
  buttonText: string;
  buttonAction: 'item_order' | 'whatsapp' | 'external' | 'upgrade_modal';
  buttonUrl?: string;
  showButton?: boolean;
}

export interface LiveScreenNoticeConfig {
  enabled: boolean;
  headline: string;
  details: string;
  badgeText: string;
  updatedAt: string;
  actionUrl?: string;
  screenMode?: 'carousel' | 'video' | 'photo';
  slides?: ShowcaseSlide[];
  buttonText?: string;
}

export interface ItemIconsConfig {
  logoIcon: 'crown' | 'shield' | 'flame' | 'diamond' | 'star' | 'rocket' | 'trophy' | 'zap';
  logoCustomUrl?: string;
  directDownloaderIcon: 'zap' | 'download' | 'rocket' | 'film' | 'sparkles' | 'play';
  batchDownloaderIcon: 'layers' | 'package' | 'list' | 'grid' | 'copy';
  audioStudioIcon: 'music' | 'headphones' | 'mic' | 'disc' | 'radio';
  streamVisualizerIcon: 'activity' | 'cpu' | 'waveform' | 'laser' | 'radar';
  vipBadgeIcon: 'crown' | 'sparkles' | 'gem' | 'award' | 'shield';
  iconStyle: '3d' | '2d' | 'animated' | 'colorful_glass';
}

export const DEFAULT_SHOWCASE_SLIDES: ShowcaseSlide[] = [
  {
    id: 'live_primary',
    tag: '',
    title: 'Live Showcase',
    subtitle: '',
    mediaType: 'video',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31911-large.mp4',
    buttonText: '',
    buttonAction: 'whatsapp',
    showButton: false,
  },
];

export const DEFAULT_ITEM_ICONS: ItemIconsConfig = {
  logoIcon: 'crown',
  directDownloaderIcon: 'zap',
  batchDownloaderIcon: 'layers',
  audioStudioIcon: 'music',
  streamVisualizerIcon: 'activity',
  vipBadgeIcon: 'crown',
  iconStyle: '3d',
};

export interface SiteConfigState {
  theme: ThemeDefinition;
  layout: LayoutConfig;
  chatSecurity: ChatSecurityConfig;
  itemIcons: ItemIconsConfig;
  audio: {
    bgMusicEnabled: boolean;
    autoplay: boolean;
    volume: number;
    selectedTrackId: string;
    customTrackUrl?: string;
    soundFxPack: 'royal' | 'arcade' | 'water' | 'minimal';
    showFloatingPlayer: boolean;
  };
  features: {
    freeDownloadQuota: number;
    planPricePKR: string;
    whatsappOrdersPhone: string;
    whatsappChannelUrl: string;
    announcementText: string;
    showAnnouncement: boolean;
    requireGateFollow: boolean;
    directDownloaderEnabled: boolean;
    batchDownloaderEnabled: boolean;
    audioStudioEnabled: boolean;
    liveChatEnabled: boolean;
    featuredPlatformsEnabled: boolean;
    downloadHistoryEnabled: boolean;
    faqSectionEnabled: boolean;
    liveScreenNotice: LiveScreenNoticeConfig;
  };
}

const CONFIG_LOCAL_KEY = 'fadiking_site_config';

export function getLocalConfig(): SiteConfigState {
  const defaultTheme = THEME_PRESETS.obsidian_gold;
  const initial: SiteConfigState = {
    theme: defaultTheme,
    layout: {
      containerWidth: '6xl',
      dashboardStyle: 'dual_panel',
      quickActionsPosition: 'hero',
      chatWidgetPosition: 'bottom-right',
      searchBarPosition: 'centered',
      headerStyle: 'royal_gold_vip',
      borderGlow: true,
    },
    chatSecurity: {
      locked: false,
      lockNotice: 'Live Chat is temporarily in VIP maintenance. Check back shortly!',
      requireVerification: false,
      vipOnly: false,
      botEnabled: true,
    },
    itemIcons: DEFAULT_ITEM_ICONS,
    audio: {
      bgMusicEnabled: true,
      autoplay: false,
      volume: 30,
      selectedTrackId: 'royal_lounge',
      customTrackUrl: '',
      soundFxPack: 'royal',
      showFloatingPlayer: true,
    },
    features: {
      freeDownloadQuota: 5,
      planPricePKR: '250 PKR',
      whatsappOrdersPhone: '923708392045',
      whatsappChannelUrl: 'https://whatsapp.com/channel/0029VbEGrIMFHWq1Sx2Nw03w',
      announcementText: '👑 FADI KING VIP — ROYAL 8K ULTRA HDR MEDIA SUITE',
      showAnnouncement: true,
      requireGateFollow: true,
      directDownloaderEnabled: true,
      batchDownloaderEnabled: true,
      audioStudioEnabled: true,
      liveChatEnabled: true,
      featuredPlatformsEnabled: true,
      downloadHistoryEnabled: true,
      faqSectionEnabled: true,
      liveScreenNotice: {
        enabled: true,
        headline: '⚡ FADI KING VIP 8K ULTRA HDR ENGINE ACTIVE — Zero Watermark, 100% Free Full Speed',
        details: 'All social media downloaders (TikTok, YouTube, Instagram Reels, Facebook, Twitter/X, Pinterest) ab maximum bitrate par chal rahe hain. Enjoy ultra-smooth speed!',
        badgeText: '👑 ROYAL VIP ENGINE',
        updatedAt: new Date().toISOString(),
        actionUrl: '',
        screenMode: 'carousel',
        slides: DEFAULT_SHOWCASE_SLIDES,
        buttonText: 'BUY NOW / UPGRADE (Rs. 250)',
      },
    },
  };

  if (typeof window === 'undefined') return initial;

  try {
    const raw = localStorage.getItem(CONFIG_LOCAL_KEY);
    const parsed = raw ? JSON.parse(raw) : {};

    // Restore background if saved
    const savedBg = localStorage.getItem('fadiking_bg_media_url');
    const savedBgType = (localStorage.getItem('fadiking_bg_type') as any) || undefined;
    const mergedTheme = {
      ...initial.theme,
      ...(parsed.theme || {}),
      bgMediaUrl: parsed.theme?.bgMediaUrl || savedBg || initial.theme.bgMediaUrl,
      bgType: parsed.theme?.bgType || savedBgType || initial.theme.bgType,
    };

    // Restore custom slides if saved
    let customSlides = parsed.features?.liveScreenNotice?.slides;
    if (!Array.isArray(customSlides) || customSlides.length === 0) {
      const savedSlidesRaw = localStorage.getItem('fadiking_saved_slides');
      if (savedSlidesRaw) {
        try {
          customSlides = JSON.parse(savedSlidesRaw);
        } catch {}
      }
    }
    if (!Array.isArray(customSlides) || customSlides.length === 0) {
      customSlides = DEFAULT_SHOWCASE_SLIDES;
    }

    return {
      ...initial,
      ...parsed,
      theme: mergedTheme,
      layout: { ...initial.layout, ...(parsed.layout || {}) },
      chatSecurity: { ...initial.chatSecurity, ...(parsed.chatSecurity || {}) },
      itemIcons: { ...initial.itemIcons, ...(parsed.itemIcons || {}) },
      audio: { ...initial.audio, ...(parsed.audio || {}) },
      features: {
        ...initial.features,
        ...(parsed.features || {}),
        liveScreenNotice: {
          ...initial.features.liveScreenNotice,
          ...((parsed.features && parsed.features.liveScreenNotice) || {}),
          slides: customSlides,
        },
      },
    };
  } catch {
    return initial;
  }
}

export function saveLocalConfig(config: SiteConfigState) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CONFIG_LOCAL_KEY, JSON.stringify(config));
    if (config.theme?.bgMediaUrl) {
      localStorage.setItem('fadiking_bg_media_url', config.theme.bgMediaUrl);
      localStorage.setItem('fadiking_bg_type', config.theme.bgType || 'image');
    }
    if (config.features?.liveScreenNotice?.slides && config.features.liveScreenNotice.slides.length > 0) {
      localStorage.setItem('fadiking_saved_slides', JSON.stringify(config.features.liveScreenNotice.slides));
    }
  } catch (e) {
    console.warn('Failed to save local config:', e);
  }
}

export function syncCustomAssetsToServer(bgMediaUrl?: string, bgType?: string, slides?: any[]) {
  if (typeof window === 'undefined') return;
  if (!bgMediaUrl && (!slides || slides.length === 0)) return;
  fetch('/api/client-persist-config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      bgMediaUrl: bgMediaUrl || undefined,
      bgType: bgType || undefined,
      slides: slides && slides.length > 0 ? slides : undefined,
    }),
  }).catch(() => {});
}

export async function fetchServerConfig(): Promise<SiteConfigState | null> {
  try {
    // Unique timestamp cache-buster and no-store to defeat Cloudflare/browser caching
    const cacheBuster = `_t=${Date.now()}`;
    const res = await fetch(`/api/site-config?${cacheBuster}`, {
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
      },
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.config) {
      const serverCfg = data.config;
      const themePreset = (serverCfg.theme?.preset as ThemePreset) || 'obsidian_gold';
      const basePreset = THEME_PRESETS[themePreset] || THEME_PRESETS.obsidian_gold;

      const mergedTheme = {
        ...basePreset,
        ...serverCfg.theme,
      };

      // Server is the authoritative single source of truth: sync localStorage with server
      if (typeof window !== 'undefined') {
        if (mergedTheme.bgMediaUrl) {
          localStorage.setItem('fadiking_bg_media_url', mergedTheme.bgMediaUrl);
          localStorage.setItem('fadiking_bg_type', mergedTheme.bgType || 'image');
        } else {
          localStorage.removeItem('fadiking_bg_media_url');
          localStorage.removeItem('fadiking_bg_type');
        }
      }

      const merged: SiteConfigState = {
        theme: mergedTheme,
        layout: {
          containerWidth: serverCfg.layout?.containerWidth || '6xl',
          dashboardStyle: serverCfg.layout?.dashboardStyle || 'dual_panel',
          quickActionsPosition: serverCfg.layout?.quickActionsPosition || 'hero',
          chatWidgetPosition: serverCfg.layout?.chatWidgetPosition || 'bottom-right',
          searchBarPosition: serverCfg.layout?.searchBarPosition || 'centered',
          headerStyle: serverCfg.layout?.headerStyle || 'royal_gold_vip',
          borderGlow: serverCfg.layout?.borderGlow !== false,
        },
        chatSecurity: {
          locked: Boolean(serverCfg.chatSecurity?.locked),
          lockNotice: serverCfg.chatSecurity?.lockNotice || 'Live Chat is temporarily in VIP maintenance. Check back shortly!',
          requireVerification: Boolean(serverCfg.chatSecurity?.requireVerification),
          vipOnly: Boolean(serverCfg.chatSecurity?.vipOnly),
          botEnabled: serverCfg.chatSecurity?.botEnabled !== false,
        },
        itemIcons: {
          ...DEFAULT_ITEM_ICONS,
          ...(serverCfg.itemIcons || {}),
        },
        audio: serverCfg.audio,
        features: {
          ...serverCfg.features,
          directDownloaderEnabled: serverCfg.features?.directDownloaderEnabled !== false,
          batchDownloaderEnabled: serverCfg.features?.batchDownloaderEnabled !== false,
          audioStudioEnabled: serverCfg.features?.audioStudioEnabled !== false,
          liveChatEnabled: serverCfg.features?.liveChatEnabled !== false,
          featuredPlatformsEnabled: serverCfg.features?.featuredPlatformsEnabled !== false,
          downloadHistoryEnabled: serverCfg.features?.downloadHistoryEnabled !== false,
          liveScreenNotice: {
            ...DEFAULT_CONFIG.features.liveScreenNotice,
            ...(serverCfg.features?.liveScreenNotice || {}),
            slides:
              Array.isArray(serverCfg.features?.liveScreenNotice?.slides) &&
              serverCfg.features.liveScreenNotice.slides.length > 0
                ? serverCfg.features.liveScreenNotice.slides
                : DEFAULT_SHOWCASE_SLIDES,
          },
        },
      };
      saveLocalConfig(merged);
      return merged;
    }
  } catch (err) {
    console.warn('Could not sync site config from server:', err);
  }
  return null;
}

export async function purgeCacheAndSync(password: string): Promise<{ success: boolean; message?: string }> {
  try {
    const res = await fetch('/api/admin/purge-cache', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-password': password,
      },
      body: JSON.stringify({ password }),
    });
    const data = await res.json();
    if (res.ok && data.success) {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('fadiking_bg_media_url');
        localStorage.removeItem('fadiking_bg_type');
        localStorage.removeItem('fadiking_saved_slides');
        localStorage.removeItem('fadiking_site_config_v2');
      }
      return { success: true, message: data.message };
    }
    return { success: false, message: data.error || 'Failed to purge cache' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Network connection failed' };
  }
}

export async function updateServerConfig(
  password: string,
  updates: Partial<SiteConfigState>
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch('/api/admin/site-config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-password': password,
      },
      body: JSON.stringify({ updates }),
    });

    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data.error || 'Unauthorized' };
    }

    if (data.config) {
      const updatedTheme = THEME_PRESETS[data.config.theme?.preset as ThemePreset] || THEME_PRESETS.obsidian_gold;
      const merged: SiteConfigState = {
        theme: { ...updatedTheme, ...data.config.theme },
        layout: {
          containerWidth: data.config.layout?.containerWidth || '6xl',
          dashboardStyle: data.config.layout?.dashboardStyle || 'dual_panel',
          quickActionsPosition: data.config.layout?.quickActionsPosition || 'hero',
          chatWidgetPosition: data.config.layout?.chatWidgetPosition || 'bottom-right',
          searchBarPosition: data.config.layout?.searchBarPosition || 'centered',
          headerStyle: data.config.layout?.headerStyle || 'royal_gold_vip',
          borderGlow: data.config.layout?.borderGlow !== false,
        },
        chatSecurity: {
          locked: Boolean(data.config.chatSecurity?.locked),
          lockNotice: data.config.chatSecurity?.lockNotice || 'Live Chat is temporarily in VIP maintenance. Check back shortly!',
          requireVerification: Boolean(data.config.chatSecurity?.requireVerification),
          vipOnly: Boolean(data.config.chatSecurity?.vipOnly),
          botEnabled: data.config.chatSecurity?.botEnabled !== false,
        },
        itemIcons: {
          ...DEFAULT_ITEM_ICONS,
          ...(data.config.itemIcons || {}),
        },
        audio: data.config.audio,
        features: {
          ...data.config.features,
          directDownloaderEnabled: data.config.features?.directDownloaderEnabled !== false,
          batchDownloaderEnabled: data.config.features?.batchDownloaderEnabled !== false,
          audioStudioEnabled: data.config.features?.audioStudioEnabled !== false,
          liveChatEnabled: data.config.features?.liveChatEnabled !== false,
          featuredPlatformsEnabled: data.config.features?.featuredPlatformsEnabled !== false,
          downloadHistoryEnabled: data.config.features?.downloadHistoryEnabled !== false,
          faqSectionEnabled: data.config.features?.faqSectionEnabled !== false,
          liveScreenNotice: {
            ...DEFAULT_CONFIG.features.liveScreenNotice,
            ...(data.config.features?.liveScreenNotice || {}),
            slides:
              Array.isArray(data.config.features?.liveScreenNotice?.slides) &&
              data.config.features.liveScreenNotice.slides.length > 0
                ? data.config.features.liveScreenNotice.slides
                : (typeof window !== 'undefined' && localStorage.getItem('fadiking_saved_slides'))
                ? JSON.parse(localStorage.getItem('fadiking_saved_slides')!)
                : (DEFAULT_CONFIG.features?.liveScreenNotice?.slides || DEFAULT_SHOWCASE_SLIDES),
          },
        },
      };
      saveLocalConfig(merged);
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Server connection failed' };
  }
}

export const DEFAULT_CONFIG = getLocalConfig();
