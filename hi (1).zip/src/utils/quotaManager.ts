/**
 * FADI KING Quota & Lifetime VIP License Manager
 * - Free users: 5 total video downloads
 * - Lifetime VIP: Unlimited downloads (Price: 250 PKR via WhatsApp 923708392045)
 */

export const MAX_FREE_DOWNLOADS = 5;
export const UPGRADE_PRICE_PKR = '250 PKR';
export const WHATSAPP_ORDERS_PHONE = '923708392045';

const QUOTA_STORAGE_KEY = 'fadiking_download_quota';
const LICENSE_STORAGE_KEY = 'fadiking_license_info';

export interface LicenseInfo {
  isLifetime: boolean;
  email?: string;
  code?: string;
  plan?: string;
  activatedAt?: string;
}

export interface QuotaState {
  remaining: number;
  total: number;
  isLifetime: boolean;
  email?: string;
}

/**
 * Dispatch custom event to notify all React components of quota or license changes
 */
function emitQuotaChange() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('fadiking-quota-updated'));
  }
}

export function getStoredLicense(): LicenseInfo {
  if (typeof window === 'undefined') return { isLifetime: false };
  try {
    const raw = localStorage.getItem(LICENSE_STORAGE_KEY);
    if (!raw) return { isLifetime: false };
    const parsed = JSON.parse(raw);
    return parsed.isLifetime ? parsed : { isLifetime: false };
  } catch {
    return { isLifetime: false };
  }
}

export function getQuotaState(): QuotaState {
  const license = getStoredLicense();
  if (license.isLifetime) {
    return {
      remaining: Infinity,
      total: Infinity,
      isLifetime: true,
      email: license.email,
    };
  }

  if (typeof window === 'undefined') {
    return { remaining: MAX_FREE_DOWNLOADS, total: MAX_FREE_DOWNLOADS, isLifetime: false };
  }

  const stored = localStorage.getItem(QUOTA_STORAGE_KEY);
  if (stored === null) {
    // First time visitor gets 5 free downloads
    localStorage.setItem(QUOTA_STORAGE_KEY, String(MAX_FREE_DOWNLOADS));
    return { remaining: MAX_FREE_DOWNLOADS, total: MAX_FREE_DOWNLOADS, isLifetime: false };
  }

  const parsed = parseInt(stored, 10);
  const remaining = isNaN(parsed) ? 0 : Math.max(0, parsed);
  return {
    remaining,
    total: MAX_FREE_DOWNLOADS,
    isLifetime: false,
  };
}

export function canDownload(): boolean {
  const state = getQuotaState();
  return state.isLifetime || state.remaining > 0;
}

/**
 * Consume 1 download from free quota.
 * Returns true if allowed, false if quota is exhausted.
 */
export function consumeDownload(): boolean {
  const license = getStoredLicense();
  if (license.isLifetime) {
    return true; // Lifetime VIP users never consume quota
  }

  if (typeof window === 'undefined') return false;

  const current = getQuotaState().remaining;
  if (current <= 0) {
    emitQuotaChange();
    return false;
  }

  const next = Math.max(0, current - 1);
  localStorage.setItem(QUOTA_STORAGE_KEY, String(next));
  emitQuotaChange();
  return true;
}

/**
 * Verify activation code with backend server and permanently unlock Lifetime VIP
 */
export async function activateLifetimeLicense(
  email: string,
  code: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch('/api/license/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim(), code: code.trim().toUpperCase() }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Invalid email or activation code.' };
    }

    const licenseData: LicenseInfo = {
      isLifetime: true,
      email: data.license?.email || email.trim(),
      code: data.license?.code || code.trim().toUpperCase(),
      plan: data.license?.plan || 'lifetime_vip',
      activatedAt: new Date().toISOString(),
    };

    localStorage.setItem(LICENSE_STORAGE_KEY, JSON.stringify(licenseData));
    emitQuotaChange();
    return { success: true };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Could not connect to server. Please check your internet connection.',
    };
  }
}

/**
 * Build prefilled WhatsApp URL for purchasing plan
 */
export function getWhatsAppPurchaseUrl(userEmail?: string): string {
  const base = `https://wa.me/${WHATSAPP_ORDERS_PHONE}`;
  let text = `Hello FADI KING! I want to upgrade to the Lifetime VIP Plan for ${UPGRADE_PRICE_PKR}. Please send me my activation code.`;
  if (userEmail && userEmail.trim()) {
    text += ` My Email: ${userEmail.trim()}`;
  }
  return `${base}?text=${encodeURIComponent(text)}`;
}

/**
 * Admin API Client
 */
export async function adminLogin(
  password: string,
  email?: string
): Promise<{ success: boolean; error?: string; email?: string }> {
  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, email }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { success: false, error: data.error || 'Authentication failed' };
    }
    return { success: true, email: data.email };
  } catch {
    return { success: false, error: 'Network error connecting to Admin Server' };
  }
}

export async function adminVerifyGoogleAccount(
  email: string,
  password?: string
): Promise<{ success: boolean; error?: string; verified?: boolean; email?: string }> {
  try {
    const res = await fetch('/api/admin/verify-google-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return {
        success: false,
        error:
          data.error ||
          'Access Denied: Only authorized email (fahdiking1234@gmail.com) can open the Admin Panel.',
      };
    }
    return { success: true, verified: true, email: data.email };
  } catch {
    return { success: false, error: 'Network error verifying Google account' };
  }
}

export async function adminContinueWithGoogle(
  email: string
): Promise<{ success: boolean; error?: string; verified?: boolean; email?: string; adminPassword?: string }> {
  try {
    const res = await fetch('/api/admin/continue-with-google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) {
      return {
        success: false,
        error:
          data.error ||
          '⛔ Access Denied: Yeh Admin Panel sirf authorized email ke sath verify ho sakta hai.',
      };
    }
    return {
      success: true,
      verified: true,
      email: data.email,
      adminPassword: data.adminPassword,
    };
  } catch {
    return { success: false, error: 'Network error connecting to Google verification server.' };
  }
}


export async function fetchAdminLicenses(password: string) {
  const res = await fetch('/api/admin/licenses', {
    headers: { 'x-admin-password': password },
  });
  if (!res.ok) throw new Error('Unauthorized');
  return res.json();
}

export async function adminGenerateCode(password: string, email: string) {
  const res = await fetch('/api/admin/generate-code', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-password': password,
    },
    body: JSON.stringify({ email }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to generate code');
  return data;
}

export async function adminDeleteLicense(password: string, id: string) {
  const res = await fetch(`/api/admin/license/${id}`, {
    method: 'DELETE',
    headers: { 'x-admin-password': password },
  });
  return res.ok;
}
