import type { SupportedPlatform } from '../types/downloader';

export function detectPlatform(url: string): { platform: SupportedPlatform; platformName: string } {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();

    if (host.includes('youtube.com') || host.includes('youtu.be')) {
      return { platform: 'youtube', platformName: 'YouTube' };
    }
    if (host.includes('instagram.com')) {
      return { platform: 'instagram', platformName: 'Instagram' };
    }
    if (host.includes('tiktok.com')) {
      return { platform: 'tiktok', platformName: 'TikTok' };
    }
    if (host.includes('facebook.com') || host.includes('fb.watch') || host.includes('fb.com')) {
      return { platform: 'facebook', platformName: 'Facebook' };
    }
    if (host.includes('twitter.com') || host.includes('x.com')) {
      return { platform: 'twitter', platformName: 'X / Twitter' };
    }
    if (host.includes('pinterest.com') || host.includes('pin.it')) {
      return { platform: 'pinterest', platformName: 'Pinterest' };
    }
    if (host.includes('reddit.com') || host.includes('redd.it')) {
      return { platform: 'reddit', platformName: 'Reddit' };
    }
    if (host.includes('threads.net')) {
      return { platform: 'threads', platformName: 'Threads' };
    }
    if (host.includes('vimeo.com')) {
      return { platform: 'vimeo', platformName: 'Vimeo' };
    }
    return { platform: 'other', platformName: 'Social Video' };
  } catch {
    return { platform: 'other', platformName: 'Web Video' };
  }
}
