// Voice Narration & Interactive Audio Guide System
// Automatically explains each feature in clean Urdu/Hindi with onscreen subtitle display

export interface VoiceGuideMessage {
  title: string;
  text: string;
  spokenAt: number;
}

const VOICE_PREF_KEY = 'fadiking_voice_guide_active';

let voiceEnabled = true;
try {
  const saved = localStorage.getItem(VOICE_PREF_KEY);
  if (saved !== null) {
    voiceEnabled = saved === 'true';
  }
} catch {
  voiceEnabled = true;
}

export function isVoiceGuideActive(): boolean {
  return voiceEnabled;
}

export function setVoiceGuideActive(active: boolean): void {
  voiceEnabled = active;
  try {
    localStorage.setItem(VOICE_PREF_KEY, active ? 'true' : 'false');
  } catch {}
  if (!active && typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  window.dispatchEvent(new CustomEvent('fadiking-voice-toggle', { detail: active }));
}

// Global active voice listener dispatcher
export function speakFeature(title: string, urduExplanation: string, force = false): void {
  if (typeof window === 'undefined') return;

  // Dispatch onscreen toast notification so user can read what is said even if muted
  const payload: VoiceGuideMessage = {
    title,
    text: urduExplanation,
    spokenAt: Date.now(),
  };
  window.dispatchEvent(new CustomEvent('fadiking-voice-speak', { detail: payload }));

  if (!voiceEnabled && !force) {
    return;
  }

  if (!('speechSynthesis' in window)) {
    return;
  }

  try {
    window.speechSynthesis.cancel(); // Stop any previous speech

    const utterance = new SpeechSynthesisUtterance(urduExplanation);
    
    // Attempt to pick an Urdu or Hindi voice, otherwise use natural voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice =
      voices.find((v) => v.lang.toLowerCase().startsWith('ur')) ||
      voices.find((v) => v.lang.toLowerCase().startsWith('hi')) ||
      voices.find((v) => v.name.toLowerCase().includes('india') || v.name.toLowerCase().includes('pakistan')) ||
      voices.find((v) => v.lang.toLowerCase().startsWith('en-in')) ||
      voices.find((v) => v.default) ||
      voices[0];

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.rate = 0.95; // Slightly measured for clear Urdu pronunciation
    utterance.pitch = 1.05;
    utterance.volume = 1.0;

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}
