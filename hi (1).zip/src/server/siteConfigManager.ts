import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export type AnimationThemeType =
  | 'cyber_matrix'
  | 'royal_gold_shimmer'
  | 'cosmic_nebula'
  | 'emerald_grid'
  | 'clean_slate';

export type IconStyleType = '3d' | '2d' | 'animated' | 'colorful_glass';

export interface SiteThemeConfig {
  preset: 'obsidian_gold' | 'midnight_cyan' | 'royal_emerald' | 'graphite_dark' | 'crystal_white_glass' | 'custom';
  name: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  cardBg: string;
  borderColor: string;
  isWatercolor: boolean;
  paperTexture: boolean;
  glowIntensity: 'subtle' | 'vibrant' | 'ultra';
  animationTheme: AnimationThemeType;
  iconStyle: IconStyleType;
  bgType: 'color' | 'image' | 'video';
  bgMediaUrl: string;
  bgOverlayOpacity: number; // 0.1 to 0.95
  bgBlur: number; // 0 to 10px
}

export interface ShowcaseSlide {
  id: string;
  tag: string;
  title: string;
  subtitle: string;
  price?: string;
  mediaType: 'image' | 'video';
  mediaUrl: string;
  buttonText: string;
  buttonAction: 'item_order' | 'whatsapp' | 'external' | 'upgrade_modal';
  buttonUrl?: string;
  showButton?: boolean;
}

export interface LiveScreenNoticeConfig {
  enabled: boolean;
  headline: string;
  details: string;
  badgeText: string;
  updatedAt: string;
  actionUrl?: string;
  screenMode?: 'carousel' | 'video' | 'photo';
  slides?: ShowcaseSlide[];
  buttonText?: string;
}

export interface ItemIconsConfig {
  logoIcon: 'crown' | 'shield' | 'flame' | 'diamond' | 'star' | 'rocket' | 'trophy' | 'zap';
  logoCustomUrl?: string;
  directDownloaderIcon: 'zap' | 'download' | 'rocket' | 'film' | 'sparkles' | 'play';
  batchDownloaderIcon: 'layers' | 'package' | 'list' | 'grid' | 'copy';
  audioStudioIcon: 'music' | 'headphones' | 'mic' | 'disc' | 'radio';
  streamVisualizerIcon: 'activity' | 'cpu' | 'waveform' | 'laser' | 'radar';
  vipBadgeIcon: 'crown' | 'sparkles' | 'gem' | 'award' | 'shield';
  iconStyle: '3d' | '2d' | 'animated' | 'colorful_glass';
}

export interface LayoutConfig {
  containerWidth: '5xl' | '6xl' | '7xl' | 'full';
  dashboardStyle: 'dual_panel' | 'stacked' | 'compact';
  quickActionsPosition: 'top' | 'bottom' | 'hero';
  chatWidgetPosition: 'bottom-right' | 'bottom-left' | 'top-right' | 'embedded_card';
  searchBarPosition: 'top' | 'centered';
  headerStyle: 'royal_gold_vip' | 'classic' | 'minimal';
  borderGlow: boolean;
}

export interface ChatSecurityConfig {
  locked: boolean;
  lockNotice: string;
  requireVerification: boolean;
  vipOnly: boolean;
  botEnabled: boolean;
}

export interface SiteAudioConfig {
  bgMusicEnabled: boolean;
  autoplay: boolean;
  volume: number; // 0 - 100
  selectedTrackId: string;
  customTrackUrl?: string;
  soundFxPack: 'royal' | 'arcade' | 'water' | 'minimal';
  showFloatingPlayer: boolean;
}

export interface SiteFeaturesConfig {
  freeDownloadQuota: number;
  planPricePKR: string;
  whatsappOrdersPhone: string;
  whatsappChannelUrl: string;
  announcementText: string;
  showAnnouncement: boolean;
  requireGateFollow: boolean;
  directDownloaderEnabled: boolean;
  batchDownloaderEnabled: boolean;
  audioStudioEnabled: boolean;
  liveChatEnabled: boolean;
  featuredPlatformsEnabled: boolean;
  downloadHistoryEnabled: boolean;
  faqSectionEnabled: boolean;
  liveScreenNotice: LiveScreenNoticeConfig;
}

export interface FullSiteConfig {
  theme: SiteThemeConfig;
  layout: LayoutConfig;
  chatSecurity: ChatSecurityConfig;
  itemIcons: ItemIconsConfig;
  audio: SiteAudioConfig;
  features: SiteFeaturesConfig;
  lastUpdated: string;
}

const ROOT_DATA_DIR = path.resolve(process.cwd(), 'src/server/data');
const DATA_DIR = fs.existsSync(ROOT_DATA_DIR) ? ROOT_DATA_DIR : path.join(__dirname, 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'siteConfig.json');
const CONFIG_BACKUP_FILE = path.join(DATA_DIR, 'siteConfig.backup.json');
const PUBLIC_BACKUP_FILE = path.resolve(process.cwd(), 'public/siteConfig.backup.json');

export const DEFAULT_CONFIG: FullSiteConfig = {
  theme: {
    preset: 'obsidian_gold',
    name: 'Royal Obsidian Dark & Metallic Gold VIP',
    primaryColor: '#d4af37',
    secondaryColor: '#f39c12',
    accentColor: '#fbbf24',
    backgroundColor: '#0a0a0a',
    cardBg: '#121212/85',
    borderColor: '#d4af37/25',
    isWatercolor: false,
    paperTexture: false,
    glowIntensity: 'vibrant',
    animationTheme: 'royal_gold_shimmer',
    iconStyle: '3d',
    bgType: 'video',
    bgMediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-starfield-in-space-12792-large.mp4',
    bgOverlayOpacity: 0.88,
    bgBlur: 2,
  },
  layout: {
    containerWidth: '6xl',
    dashboardStyle: 'dual_panel',
    quickActionsPosition: 'hero',
    chatWidgetPosition: 'bottom-right',
    searchBarPosition: 'centered',
    headerStyle: 'royal_gold_vip',
    borderGlow: true,
  },
  chatSecurity: {
    locked: false,
    lockNotice: 'Live Chat is temporarily in VIP maintenance. Check back shortly!',
    requireVerification: false,
    vipOnly: false,
    botEnabled: true,
  },
  itemIcons: {
    logoIcon: 'crown',
    directDownloaderIcon: 'zap',
    batchDownloaderIcon: 'layers',
    audioStudioIcon: 'music',
    streamVisualizerIcon: 'activity',
    vipBadgeIcon: 'crown',
    iconStyle: '3d',
  },
  audio: {
    bgMusicEnabled: true,
    autoplay: false,
    volume: 30,
    selectedTrackId: 'royal_lounge',
    customTrackUrl: '',
    soundFxPack: 'royal',
    showFloatingPlayer: true,
  },
  features: {
    freeDownloadQuota: 5,
    planPricePKR: '250 PKR',
    whatsappOrdersPhone: '923708392045',
    whatsappChannelUrl: 'https://whatsapp.com/channel/0029VbEGrIMFHWq1Sx2Nw03w',
    announcementText: '👑 FADI KING VIP — ROYAL 8K ULTRA HDR MEDIA SUITE',
    showAnnouncement: true,
    requireGateFollow: true,
    directDownloaderEnabled: true,
    batchDownloaderEnabled: true,
    audioStudioEnabled: true,
    liveChatEnabled: true,
    featuredPlatformsEnabled: true,
    downloadHistoryEnabled: true,
    faqSectionEnabled: true,
    liveScreenNotice: {
      enabled: true,
      headline: '⚡ FADI KING VIP 8K ULTRA HDR ENGINE ACTIVE — Zero Watermark, 100% Free Full Speed',
      details: 'All social media downloaders ab maximum bitrate par chal rahe hain.',
      badgeText: '👑 ROYAL VIP ENGINE',
      updatedAt: new Date().toISOString(),
      actionUrl: '',
      slides: [
        {
          id: 'live_primary',
          tag: '',
          title: 'Live Showcase',
          subtitle: '',
          mediaType: 'video',
          mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31911-large.mp4',
          buttonText: '',
          buttonAction: 'whatsapp',
          showButton: false,
        },
      ],
    },
  },
  lastUpdated: new Date().toISOString(),
};

function ensureStorage(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(CONFIG_FILE)) {
      if (fs.existsSync(CONFIG_BACKUP_FILE)) {
        fs.copyFileSync(CONFIG_BACKUP_FILE, CONFIG_FILE);
      } else if (fs.existsSync(PUBLIC_BACKUP_FILE)) {
        fs.copyFileSync(PUBLIC_BACKUP_FILE, CONFIG_FILE);
      } else {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG, null, 2), 'utf-8');
      }
    }
  } catch (err) {
    console.error('Error ensuring config storage:', err);
  }
}

export function getSiteConfig(): FullSiteConfig {
  ensureStorage();
  try {
    let raw = '';
    if (fs.existsSync(CONFIG_FILE)) {
      raw = fs.readFileSync(CONFIG_FILE, 'utf-8');
    } else if (fs.existsSync(CONFIG_BACKUP_FILE)) {
      raw = fs.readFileSync(CONFIG_BACKUP_FILE, 'utf-8');
    } else if (fs.existsSync(PUBLIC_BACKUP_FILE)) {
      raw = fs.readFileSync(PUBLIC_BACKUP_FILE, 'utf-8');
    }

    const parsed = raw ? JSON.parse(raw) : {};
    const parsedNotice = (parsed.features && parsed.features.liveScreenNotice) || {};

    const slides =
      Array.isArray(parsedNotice.slides) && parsedNotice.slides.length > 0
        ? parsedNotice.slides
        : DEFAULT_CONFIG.features.liveScreenNotice.slides;

    return {
      ...DEFAULT_CONFIG,
      ...parsed,
      theme: {
        ...DEFAULT_CONFIG.theme,
        ...(parsed.theme || {}),
        bgMediaUrl: parsed.theme?.bgMediaUrl ?? DEFAULT_CONFIG.theme.bgMediaUrl,
        bgType: parsed.theme?.bgType ?? DEFAULT_CONFIG.theme.bgType,
      },
      layout: { ...DEFAULT_CONFIG.layout, ...(parsed.layout || {}) },
      chatSecurity: { ...DEFAULT_CONFIG.chatSecurity, ...(parsed.chatSecurity || {}) },
      itemIcons: { ...DEFAULT_CONFIG.itemIcons, ...(parsed.itemIcons || {}) },
      audio: { ...DEFAULT_CONFIG.audio, ...(parsed.audio || {}) },
      features: {
        ...DEFAULT_CONFIG.features,
        ...(parsed.features || {}),
        liveScreenNotice: {
          ...DEFAULT_CONFIG.features.liveScreenNotice,
          ...parsedNotice,
          slides,
        },
      },
    };
  } catch (err) {
    console.error('Error reading site config:', err);
    return DEFAULT_CONFIG;
  }
}

export function updateSiteConfig(partial: Partial<FullSiteConfig>): FullSiteConfig {
  ensureStorage();
  try {
    const current = getSiteConfig();
    const updated: FullSiteConfig = {
      ...current,
      ...partial,
      theme: partial.theme ? { ...current.theme, ...partial.theme } : current.theme,
      layout: partial.layout ? { ...current.layout, ...partial.layout } : current.layout,
      chatSecurity: partial.chatSecurity ? { ...current.chatSecurity, ...partial.chatSecurity } : current.chatSecurity,
      itemIcons: partial.itemIcons ? { ...current.itemIcons, ...partial.itemIcons } : current.itemIcons,
      audio: partial.audio ? { ...current.audio, ...partial.audio } : current.audio,
      features: partial.features
        ? {
            ...current.features,
            ...partial.features,
            liveScreenNotice: partial.features.liveScreenNotice
              ? {
                  ...current.features.liveScreenNotice,
                  ...partial.features.liveScreenNotice,
                  slides:
                    partial.features.liveScreenNotice.slides !== undefined
                      ? partial.features.liveScreenNotice.slides
                      : current.features.liveScreenNotice.slides,
                }
              : current.features.liveScreenNotice,
          }
        : current.features,
      lastUpdated: new Date().toISOString(),
    };

    const jsonStr = JSON.stringify(updated, null, 2);
    fs.writeFileSync(CONFIG_FILE, jsonStr, 'utf-8');
    try {
      fs.writeFileSync(CONFIG_BACKUP_FILE, jsonStr, 'utf-8');
    } catch {}
    try {
      fs.writeFileSync(PUBLIC_BACKUP_FILE, jsonStr, 'utf-8');
    } catch {}

    return updated;
  } catch (err) {
    console.error('Error writing site config:', err);
    return getSiteConfig();
  }
}
