import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface LicenseRecord {
  id: string;
  email: string;
  code: string;
  createdAt: string;
  status: 'active' | 'revoked';
  plan: 'lifetime_vip';
  price: string;
  redeemedCount: number;
  lastRedeemedAt?: string;
  notes?: string;
}

const DATA_DIR = path.join(__dirname, 'data');
const LICENSES_FILE = path.join(DATA_DIR, 'licenses.json');

export const ADMIN_PASSWORD = 'hifadi1122';
export const UPGRADE_PRICE = '250 PKR';
export const WHATSAPP_PHONE = '923708392045';

function ensureStorage(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(LICENSES_FILE)) {
      const initialData: { licenses: LicenseRecord[] } = {
        licenses: [
          {
            id: 'lic_founder_01',
            email: 'fahdiking4@gmail.com',
            code: 'FK-PRO-ROYAL-KING',
            createdAt: new Date().toISOString(),
            status: 'active',
            plan: 'lifetime_vip',
            price: '250 PKR',
            redeemedCount: 0,
            notes: 'Master Founder License',
          },
        ],
      };
      fs.writeFileSync(LICENSES_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Error ensuring licenses storage directory:', err);
  }
}

function readLicenses(): LicenseRecord[] {
  ensureStorage();
  try {
    const raw = fs.readFileSync(LICENSES_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed.licenses) ? parsed.licenses : [];
  } catch (err) {
    console.error('Error reading licenses file:', err);
    return [];
  }
}

function writeLicenses(licenses: LicenseRecord[]): void {
  ensureStorage();
  try {
    fs.writeFileSync(LICENSES_FILE, JSON.stringify({ licenses }, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing licenses file:', err);
  }
}

/**
 * Generate a unique, cryptographically distinct activation code.
 * Example: FK-PRO-7E4A-91F2
 */
function createLicenseCode(): string {
  const part1 = crypto.randomBytes(2).toString('hex').toUpperCase();
  const part2 = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `FK-PRO-${part1}-${part2}`;
}

export const VALID_ADMIN_PASSWORDS = ['hifadi1122', 'fadihi1122'];

export const AUTHORIZED_ADMIN_EMAILS = [
  'fahdiking1234@gmail.com',
  'fahdiking4@gmail.com',
  'fahdiking1234@gmaul.com',
];

export function isAuthorizedAdminEmail(email?: string): boolean {
  if (!email) return false;
  const cleaned = email.trim().toLowerCase();
  return AUTHORIZED_ADMIN_EMAILS.some((e) => e.toLowerCase() === cleaned);
}

export function verifyAdminAuth(providedPassword?: string, providedEmail?: string): boolean {
  if (!providedPassword) return false;
  const cleanedPass = providedPassword.trim().toLowerCase();
  const passOk = VALID_ADMIN_PASSWORDS.some((p) => p.toLowerCase() === cleanedPass);
  if (!passOk) return false;
  if (providedEmail && !isAuthorizedAdminEmail(providedEmail)) {
    return false;
  }
  return true;
}

export function getAllLicenses(): LicenseRecord[] {
  return readLicenses();
}

/**
 * Generate a new license code bound strictly to a user's email.
 * Ensures duplicate emails are rejected.
 */
export function generateLicenseForEmail(rawEmail: string): {
  success: boolean;
  license?: LicenseRecord;
  error?: string;
} {
  const email = (rawEmail || '').trim().toLowerCase();

  // Basic email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRegex.test(email)) {
    return {
      success: false,
      error: 'Please enter a valid, complete email address (e.g. name@example.com).',
    };
  }

  const licenses = readLicenses();

  // Prevent duplicate license generation for the same email
  const existing = licenses.find((l) => l.email.toLowerCase() === email && l.status === 'active');
  if (existing) {
    return {
      success: false,
      error: `An active license already exists for ${email} with code [${existing.code}]. You cannot generate duplicate codes for the same email.`,
      license: existing,
    };
  }

  let code = createLicenseCode();
  // Ensure code collision safety
  while (licenses.some((l) => l.code === code)) {
    code = createLicenseCode();
  }

  const newLicense: LicenseRecord = {
    id: `lic_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    email,
    code,
    createdAt: new Date().toISOString(),
    status: 'active',
    plan: 'lifetime_vip',
    price: UPGRADE_PRICE,
    redeemedCount: 0,
  };

  licenses.unshift(newLicense);
  writeLicenses(licenses);

  return {
    success: true,
    license: newLicense,
  };
}

/**
 * Validate customer email and activation code to upgrade plan.
 */
export function verifyAndRedeemLicense(
  rawEmail: string,
  rawCode: string
): {
  success: boolean;
  license?: { email: string; code: string; plan: string; price: string };
  error?: string;
} {
  const email = (rawEmail || '').trim().toLowerCase();
  const code = (rawCode || '').trim().toUpperCase();

  if (!email || !code) {
    return {
      success: false,
      error: 'Both email address and activation code are required.',
    };
  }

  const licenses = readLicenses();
  const match = licenses.find(
    (l) => l.email.toLowerCase() === email && l.code.toUpperCase() === code
  );

  if (!match) {
    return {
      success: false,
      error: 'Invalid activation code or email. Please check your spelling or contact FADI KING on WhatsApp.',
    };
  }

  if (match.status !== 'active') {
    return {
      success: false,
      error: 'This activation code has been revoked or expired.',
    };
  }

  // Update record
  match.redeemedCount = (match.redeemedCount || 0) + 1;
  match.lastRedeemedAt = new Date().toISOString();
  writeLicenses(licenses);

  return {
    success: true,
    license: {
      email: match.email,
      code: match.code,
      plan: match.plan,
      price: match.price,
    },
  };
}

/**
 * Revoke or delete a license (admin only)
 */
export function deleteLicense(licenseId: string): boolean {
  const licenses = readLicenses();
  const index = licenses.findIndex((l) => l.id === licenseId);
  if (index === -1) return false;

  licenses.splice(index, 1);
  writeLicenses(licenses);
  return true;
}
