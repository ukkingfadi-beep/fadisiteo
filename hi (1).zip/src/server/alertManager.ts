import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface BroadcastAlert {
  id: string;
  title: string;
  text: string;
  sender: string;
  tag: 'alert' | 'update' | 'offer' | 'notice';
  timestamp: string;
  soundTune?: 'tung_tung' | 'royal_bell' | 'crystal_chime' | 'cyber_alert' | 'success_fanfare';
  popup?: boolean;
}

const DATA_DIR = path.join(__dirname, 'data');
const ALERTS_FILE = path.join(DATA_DIR, 'broadcastAlerts.json');

function ensureStorage(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(ALERTS_FILE)) {
      const initial: BroadcastAlert[] = [
        {
          id: 'alert_initial_welcome',
          title: '📢 Welcome to FADI KING VIP',
          text: 'Superfast 4K Video Downloader & Audio Studio are 100% operational! Join our WhatsApp Channel for live announcements.',
          sender: '👑 FADI KING (Official Admin)',
          tag: 'notice',
          timestamp: new Date().toISOString(),
        },
      ];
      fs.writeFileSync(ALERTS_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Error ensuring broadcast alerts storage:', err);
  }
}

function readAlerts(): BroadcastAlert[] {
  ensureStorage();
  try {
    const raw = fs.readFileSync(ALERTS_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writeAlerts(alerts: BroadcastAlert[]): void {
  ensureStorage();
  try {
    fs.writeFileSync(ALERTS_FILE, JSON.stringify(alerts, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving broadcast alerts:', err);
  }
}

export function getAllAlerts(): BroadcastAlert[] {
  return readAlerts();
}

export function postAlert(
  title: string,
  text: string,
  tag: 'alert' | 'update' | 'offer' | 'notice' = 'alert',
  sender = '👑 FADI KING (Official Admin)',
  soundTune: 'tung_tung' | 'royal_bell' | 'crystal_chime' | 'cyber_alert' | 'success_fanfare' = 'tung_tung',
  popup = false
): BroadcastAlert {
  const alerts = readAlerts();
  const id = `alert_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const newAlert: BroadcastAlert = {
    id,
    title: title.trim() || '📢 Admin Broadcast Alert',
    text: text.trim(),
    sender,
    tag,
    timestamp: new Date().toISOString(),
    soundTune,
    popup,
  };

  alerts.unshift(newAlert);
  // Keep last 50 alerts
  const trimmed = alerts.slice(0, 50);
  writeAlerts(trimmed);
  return newAlert;
}

export function deleteAlert(id: string): boolean {
  const alerts = readAlerts();
  const filtered = alerts.filter((a) => a.id !== id);
  if (filtered.length !== alerts.length) {
    writeAlerts(filtered);
    return true;
  }
  return false;
}

export function clearAllAlerts(): void {
  writeAlerts([]);
}
