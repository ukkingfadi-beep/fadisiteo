import type { VideoFormatOption, VideoInfoResponse } from '../types/downloader';

/**
 * Check if the provided URL is a subreddit directory or feed rather than a single post
 */
export function isSubredditFeedUrl(url: string): boolean {
  try {
    const clean = url.trim().replace(/\/+$/, '');
    // e.g. https://www.reddit.com/r/videos or https://reddit.com/r/funny
    const match = clean.match(/^https?:\/\/(?:www\.|old\.|new\.)?reddit\.com\/r\/[a-zA-Z0-9_-]+$/i);
    return Boolean(match);
  } catch {
    return false;
  }
}

/**
 * Dedicated VIP Extractor for Reddit Posts & Videos
 */
export async function getRedditFallback(rawUrl: string): Promise<VideoInfoResponse | null> {
  const cleanUrl = rawUrl.trim();

  // 1. Guard against subreddit feeds
  if (isSubredditFeedUrl(cleanUrl)) {
    throw new Error(
      'Yeh Subreddit page ka link hai (jaise /r/videos/). Barah-e-karam kisi makhsoos video ya post ka link copy karke yahan paste karein (e.g. reddit.com/r/.../comments/... ya v.redd.it/...)'
    );
  }

  // 2. Try RapidSave resolver (works from cloud IPs, merges video + audio)
  try {
    const rapidEndpoint = `https://rapidsave.com/info?url=${encodeURIComponent(cleanUrl)}`;
    const res = await fetch(rapidEndpoint, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
      signal: AbortSignal.timeout(8000),
    });

    if (res.ok) {
      const html = await res.text();

      // Extract title
      let title = 'Reddit Video';
      const titleMatch = html.match(/<h2>([^<]+)<\/h2>/i) || html.match(/<title>([^<]+)<\/title>/i);
      if (titleMatch && titleMatch[1]) {
        title = titleMatch[1].replace(/\|\s*RapidSave/gi, '').trim();
      }

      // Extract download buttons
      // Pattern 1: <a ... href="(https://sd.rapidsave.com/download.php?[^"]+)" ...>
      // Pattern 2: <a ... href="(https://i.redd.it/[^"]+)" ...>
      let directDownloadUrl: string | null = null;
      let isPhoto = false;

      const sdMatch = html.match(/href=["'](https:\/\/(?:sd|v)\.rapidsave\.com\/download\.php\?[^"']+)["']/i);
      if (sdMatch && sdMatch[1]) {
        directDownloadUrl = sdMatch[1];
      }

      if (!directDownloadUrl) {
        const reddImgMatch = html.match(/href=["'](https:\/\/i\.redd\.it\/[a-zA-Z0-9_\-]+\.(?:png|jpg|jpeg|webp|gif))["']/i);
        if (reddImgMatch && reddImgMatch[1]) {
          directDownloadUrl = reddImgMatch[1];
          isPhoto = true;
        }
      }

      // Extract thumbnail
      let thumb = 'https://www.redditstatic.com/shreddit/assets/favicon/192x192.png';
      const thumbMatch = html.match(/src=["'](https:\/\/[^"']+\.(?:jpg|jpeg|png))["']/i);
      if (thumbMatch && thumbMatch[1] && !thumbMatch[1].includes('favicon')) {
        thumb = thumbMatch[1];
      }

      if (directDownloadUrl) {
        const formats: VideoFormatOption[] = [];

        if (isPhoto) {
          formats.push({
            formatId: 'reddit_orig_image',
            qualityLabel: 'High Quality (Ultra HD Original)',
            resolution: 'HD Photo',
            ext: directDownloadUrl.endsWith('.png') ? 'png' : 'jpg',
            hasVideo: true, // Primary visual media
            hasAudio: false,
            directUrl: directDownloadUrl,
            formatNote: '👑 100% Original Resolution Image',
          });

          formats.push({
            formatId: 'reddit_normal_image',
            qualityLabel: 'Normal Quality (Standard HD Photo)',
            resolution: 'Standard HD',
            ext: 'jpg',
            hasVideo: true,
            hasAudio: false,
            directUrl: directDownloadUrl,
            formatNote: '⚡ Fast Compressed Photo',
          });
        } else {
          formats.push({
            formatId: 'reddit_video_high',
            qualityLabel: 'High Quality (1080p / 720p Full HD)',
            resolution: '1080p HD',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: directDownloadUrl,
            formatNote: '👑 Full Sound + Ultra HD Muxed MP4',
          });

          formats.push({
            formatId: 'reddit_video_normal',
            qualityLabel: 'Normal Quality (Standard HD / Fast)',
            resolution: 'Standard HD',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: directDownloadUrl,
            formatNote: '⚡ Fast Download · Low Data Usage',
          });

          formats.push({
            formatId: 'reddit_audio_mp3',
            qualityLabel: 'Audio Track (MP3 HD)',
            resolution: 'Audio',
            ext: 'mp3',
            hasVideo: false,
            hasAudio: true,
            isAudioOnly: true,
            directUrl: directDownloadUrl,
            formatNote: '🎧 Extracted Audio Sound',
          });
        }

        return {
          id: `reddit_${Date.now()}`,
          title: title || 'Reddit Media',
          originalUrl: cleanUrl,
          platform: 'reddit',
          platformName: 'Reddit VIP',
          thumbnailUrl: thumb,
          author: 'Reddit User',
          formats,
          previewVideoUrl: !isPhoto ? directDownloadUrl : undefined,
          isDirectStreamingAvailable: true,
        };
      }
    }
  } catch (err: any) {
    console.warn('RapidSave Reddit fallback notice:', err?.message || err);
  }

  // 3. Try Jackhammer resolver API
  try {
    const jackhammerEndpoint = `https://jackhammer.pythonanywhere.com/reddit/media/downloader?url=${encodeURIComponent(cleanUrl)}`;
    const jackRes = await fetch(jackhammerEndpoint, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      signal: AbortSignal.timeout(7000),
    });

    if (jackRes.ok) {
      const mediaLink = (await jackRes.text()).trim();
      if (mediaLink && mediaLink.startsWith('http')) {
        const isImg = /\.(png|jpg|jpeg|webp|gif)(\?.*)?$/i.test(mediaLink) || mediaLink.includes('i.redd.it');
        const formats: VideoFormatOption[] = [];

        if (isImg) {
          formats.push({
            formatId: 'reddit_orig_image',
            qualityLabel: 'High Definition Reddit Image',
            resolution: 'HD Photo',
            ext: mediaLink.includes('.png') ? 'png' : 'jpg',
            hasVideo: false,
            hasAudio: false,
            directUrl: mediaLink,
            formatNote: '🖼️ Reddit Original Quality Image',
          });
        } else {
          formats.push({
            formatId: 'reddit_video_hd',
            qualityLabel: 'HD Video (Audio Included)',
            resolution: '720p HD',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: mediaLink,
            formatNote: '⚡ Reddit Direct High-Speed Stream',
          });
        }

        return {
          id: `reddit_${Date.now()}`,
          title: 'Reddit Media',
          originalUrl: cleanUrl,
          platform: 'reddit',
          platformName: 'Reddit VIP',
          thumbnailUrl: isImg ? mediaLink : 'https://www.redditstatic.com/shreddit/assets/favicon/192x192.png',
          author: 'Reddit User',
          formats,
          previewVideoUrl: !isImg ? mediaLink : undefined,
          isDirectStreamingAvailable: true,
        };
      }
    }
  } catch (err: any) {
    console.warn('Jackhammer Reddit notice:', err?.message || err);
  }

  return null;
}
