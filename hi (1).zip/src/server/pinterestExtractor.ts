import type { VideoFormatOption, VideoInfoResponse } from '../types/downloader';

export async function getPinterestFallback(rawUrl: string): Promise<VideoInfoResponse | null> {
  try {
    let targetUrl = rawUrl.trim();

    // 1. Follow HTTP redirect if pin.it short link
    if (targetUrl.includes('pin.it')) {
      try {
        const redirectRes = await fetch(targetUrl, {
          method: 'GET',
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          },
          redirect: 'follow',
          signal: AbortSignal.timeout(7000),
        });
        if (redirectRes.url) {
          targetUrl = redirectRes.url;
        }
      } catch (redirErr) {
        console.warn('Could not resolve pin.it redirect:', redirErr);
      }
    }

    // 2. Fetch Pinterest HTML with real desktop browser headers
    const res = await fetch(targetUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept':
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!res.ok) {
      console.warn(`Pinterest returned HTTP ${res.status}`);
      return null;
    }

    const html = await res.text();

    // 3. Extract title
    let title = 'Pinterest VIP Media';
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    if (titleMatch && titleMatch[1]) {
      title = titleMatch[1]
        .replace(/\|\s*Pinterest/gi, '')
        .replace(/on Pinterest/gi, '')
        .trim();
    }

    // 4. Extract author
    let author = 'Pinterest Creator';
    const authorMatch = html.match(/"username":"([^"]+)"/i) || html.match(/"pinner":\{"username":"([^"]+)"/i);
    if (authorMatch && authorMatch[1]) {
      author = `@${authorMatch[1]}`;
    }

    // 5. Extract Pin ID
    const pinIdMatch = targetUrl.match(/pin\/(\d+)/);
    const pinId = pinIdMatch ? pinIdMatch[1] : `pin_${Date.now()}`;

    // 6. Deep search for Video MP4 (v.pinimg.com or inside __PWS_DATA__)
    let videoUrl: string | null = null;

    // Check __PWS_DATA__ JSON script
    const pwsMatch = html.match(/<script[^>]*id="__PWS_DATA__"[^>]*>(.*?)<\/script>/s);
    if (pwsMatch && pwsMatch[1]) {
      try {
        const pwsJson = JSON.parse(pwsMatch[1]);
        const jsonStr = JSON.stringify(pwsJson);

        // Find 720p or standard video MP4
        const jsonVidMatch =
          jsonStr.match(/https:\\\/\\\/v\.pinimg\.com\\\/videos\\\/[a-zA-Z0-9_\/\-]+\.mp4/i) ||
          jsonStr.match(/https:\/\/v\.pinimg\.com\/videos\/[a-zA-Z0-9_\/\-]+\.mp4/i);

        if (jsonVidMatch) {
          videoUrl = jsonVidMatch[0].replace(/\\\//g, '/');
        }
      } catch {}
    }

    // Regex fallback for any v.pinimg.com video
    if (!videoUrl) {
      const vMatch = html.match(/https:\/\/(?:v|v1)\.pinimg\.com\/videos\/[a-zA-Z0-9_\/\-]+\.(?:mp4|m4v)/i);
      if (vMatch) {
        videoUrl = vMatch[0].replace(/\\u002F/g, '/').replace(/\\/g, '');
      }
    }

    // 7. Extract high-res original thumbnail / image
    let imageUrl: string | null = null;
    const origImgMatch = html.match(/https:\/\/i\.pinimg\.com\/originals\/[a-zA-Z0-9_\/\-]+\.(?:jpg|jpeg|png|webp|gif)/i);
    if (origImgMatch) {
      imageUrl = origImgMatch[0].replace(/\\u002F/g, '/').replace(/\\/g, '');
    } else {
      const generalImgMatch = html.match(/https:\/\/i\.pinimg\.com\/(?:736x|564x|474x)\/[a-zA-Z0-9_\/\-]+\.(?:jpg|jpeg|png|webp|gif)/i);
      if (generalImgMatch) {
        imageUrl = generalImgMatch[0].replace(/\\u002F/g, '/').replace(/\\/g, '');
      }
    }

    // Fallback thumbnail
    const thumb = imageUrl || 'https://assets.pinterest.com/ext/embed.html';

    const formats: VideoFormatOption[] = [];

    // If video pin detected
    if (videoUrl) {
      formats.push({
        formatId: 'pinterest_video_high',
        qualityLabel: 'High Quality (1080p / 720p Full HD)',
        resolution: '1080p / 720p HD',
        ext: 'mp4',
        hasVideo: true,
        hasAudio: true,
        directUrl: videoUrl,
        formatNote: '👑 VIP Ultra HD · Direct High-Speed MP4',
      });

      formats.push({
        formatId: 'pinterest_video_normal',
        qualityLabel: 'Normal Quality (Standard HD / Fast)',
        resolution: 'Standard HD',
        ext: 'mp4',
        hasVideo: true,
        hasAudio: true,
        directUrl: videoUrl,
        formatNote: '⚡ Fast Download · Low Data Usage',
      });

      formats.push({
        formatId: 'pinterest_audio_mp3',
        qualityLabel: 'Audio Track (MP3 320kbps HD)',
        resolution: 'Audio',
        ext: 'mp3',
        hasVideo: false,
        hasAudio: true,
        isAudioOnly: true,
        directUrl: videoUrl,
        formatNote: '🎧 Extracted Background Music',
      });
    }

    // If photo / graphic pin detected
    if (imageUrl) {
      const isPng = imageUrl.endsWith('.png');
      formats.push({
        formatId: 'pinterest_orig_image',
        qualityLabel: `High Quality (Ultra HD Original ${isPng ? 'PNG' : 'JPG'})`,
        resolution: 'Ultra HD',
        ext: isPng ? 'png' : 'jpg',
        hasVideo: !videoUrl, // If no video exists, treat as primary visual media
        hasAudio: false,
        directUrl: imageUrl,
        formatNote: '👑 100% Uncompressed Full Resolution',
      });

      formats.push({
        formatId: 'pinterest_normal_image',
        qualityLabel: 'Normal Quality (Standard HD Photo)',
        resolution: 'Standard HD',
        ext: 'jpg',
        hasVideo: !videoUrl,
        hasAudio: false,
        directUrl: imageUrl,
        formatNote: '⚡ Fast Mobile Resolution',
      });
    }

    if (formats.length === 0) {
      return null;
    }

    return {
      id: `pinterest_${pinId}`,
      title: title || 'Pinterest Media',
      originalUrl: rawUrl,
      platform: 'pinterest',
      platformName: 'Pinterest VIP',
      thumbnailUrl: thumb,
      author,
      formats,
      previewVideoUrl: videoUrl || undefined,
      isDirectStreamingAvailable: true,
    };
  } catch (err: any) {
    console.warn('Pinterest extraction error:', err?.message || err);
    return null;
  }
}
