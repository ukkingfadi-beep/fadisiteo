import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface ChatMessage {
  id: string;
  username: string;
  text: string;
  role: 'admin' | 'vip' | 'user';
  tag?: 'masla' | 'help' | 'general' | 'feedback';
  timestamp: string;
  avatarColor: string;
  avatarUrl?: string;
  photoUrl?: string;
  audioVoiceUrl?: string;
  audioDuration?: number;
}

const DATA_DIR = path.join(__dirname, 'data');
const CHAT_FILE = path.join(DATA_DIR, 'chatMessages.json');

const AVATAR_COLORS = [
  '#f59e0b', // Amber Gold
  '#10b981', // Emerald
  '#06b6d4', // Cyan
  '#8b5cf6', // Purple
  '#ec4899', // Pink
  '#3b82f6', // Blue
  '#f97316', // Orange
];

function getRandomColor(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const idx = Math.abs(hash) % AVATAR_COLORS.length;
  return AVATAR_COLORS[idx];
}

function ensureStorage(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(CHAT_FILE)) {
      const initial: { messages: ChatMessage[] } = {
        messages: [
          {
            id: 'msg_system_welcome',
            username: '👑 FADI KING (Official)',
            text: 'Assalam-o-Alaikum! Welcome to FADI KING Live Support & Chat Board. Yahan aap apna masla likh sakte hain, screenshot photo bhej sakte hain, ya voice note record karke bhej sakte hain!',
            role: 'admin',
            tag: 'help',
            timestamp: new Date().toISOString(),
            avatarColor: '#f59e0b',
          },
        ],
      };
      fs.writeFileSync(CHAT_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Error ensuring chat storage:', err);
  }
}

function readMessages(): ChatMessage[] {
  ensureStorage();
  try {
    const raw = fs.readFileSync(CHAT_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed.messages) ? parsed.messages : [];
  } catch (err) {
    console.error('Error reading chat messages:', err);
    return [];
  }
}

function writeMessages(messages: ChatMessage[]): void {
  ensureStorage();
  try {
    // Keep last 300 messages
    const trimmed = messages.slice(-300);
    fs.writeFileSync(CHAT_FILE, JSON.stringify({ messages: trimmed }, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing chat messages:', err);
  }
}

export function getRecentChat(limit = 100): ChatMessage[] {
  const all = readMessages();
  return all.slice(-limit);
}

export function postChatMessage(
  username: string,
  text: string,
  role: 'admin' | 'vip' | 'user' = 'user',
  tag: 'masla' | 'help' | 'general' | 'feedback' = 'general',
  extra?: {
    avatarUrl?: string;
    photoUrl?: string;
    audioVoiceUrl?: string;
    audioDuration?: number;
  }
): ChatMessage {
  const cleanUser = (username || 'User').trim().substring(0, 30);
  const cleanText = (text || '').trim().substring(0, 1000);

  const newMsg: ChatMessage = {
    id: `msg_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    username: cleanUser,
    text: cleanText,
    role,
    tag,
    timestamp: new Date().toISOString(),
    avatarColor: role === 'admin' ? '#f59e0b' : getRandomColor(cleanUser),
    avatarUrl: extra?.avatarUrl,
    photoUrl: extra?.photoUrl,
    audioVoiceUrl: extra?.audioVoiceUrl,
    audioDuration: extra?.audioDuration,
  };

  const all = readMessages();
  all.push(newMsg);
  writeMessages(all);

  return newMsg;
}

export function clearChatHistory(): void {
  ensureStorage();
  try {
    fs.writeFileSync(CHAT_FILE, JSON.stringify({ messages: [] }, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error clearing chat:', err);
  }
}

export function deleteChatMessage(id: string): boolean {
  ensureStorage();
  try {
    const all = readMessages();
    const filtered = all.filter((m) => m.id !== id);
    if (filtered.length !== all.length) {
      writeMessages(filtered);
      return true;
    }
    return false;
  } catch (err) {
    console.error('Error deleting chat message:', err);
    return false;
  }
}
