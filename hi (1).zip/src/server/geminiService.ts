import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  if (aiInstance) return aiInstance;
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey.trim() && apiKey !== 'MY_GEMINI_API_KEY') {
    try {
      aiInstance = new GoogleGenAI();
      return aiInstance;
    } catch (err) {
      console.warn('Failed to initialize GoogleGenAI client:', err);
    }
  }
  return null;
}

export interface ChatResponsePayload {
  reply: string;
  suggestedTrackId?: string;
  triggerGoodNight?: boolean;
  suggestedActions?: { label: string; action: string; trackId?: string }[];
}

const SYSTEM_PROMPT = `You are "FADI KING AI VIP Bot" — the luxury royal assistant and music curator for the FADI KING 8K Media Engine website.
Your tone is respectful, charismatic, caring, and professional ("Fadi King Style").
You comfortably understand and reply in Urdu, Roman Urdu, Hindi, and English based on the user's language.

Key Knowledge & Abilities:
1. Media Downloads: FADI KING supports TikTok (zero watermark), YouTube (up to 8K Ultra HD & 60fps), Instagram Reels & Stories, Facebook HD, Pinterest, and direct 320kbps MP3 audio conversion.
2. Music & Songs ("Song Wala"): We have built-in audio tracks:
   - "good_night_lofi": FADI KING Good Night Lo-Fi (Dream Sleep Beats)
   - "pakistani_sad_rubab": Pashto & Sufi Sad Rubab Melancholy
   - "pakistani_sad_darbari": Dukhi Raag Darbari Bansuri & Sarangi
   - "pakistani_sad_ghazal": Ghamgheen Ghazal Harmonium & Rubab
   - "pakistani_sad_tanhai": Tanhai Sad Flute Late Night Serenade
   - "pakistani_coke_studio_sad": Coke Studio Soulful Fusion
   - "royal_lounge": Royal Lo-Fi Chill Lounge
   - "deep_focus": Deep Ambient Calm & Peaceful Sleep
   - "midnight_rain": Midnight Rain on Window & Distant Thunder
3. Good Night Mode ("Good Night"):
   - When user says "good night", "shubh ratri", "sleep", "so raha hoon", "neend aa rahi hai", warmly wish them peaceful dreams, invite them to turn on Good Night mode, and recommend a soothing lofi or rain track.
4. VIP Lifetime Access:
   - Lifetime unlimited downloads for only Rs. 250 PKR via official WhatsApp: +923708392045.

Special Tagging in Output:
If recommending a specific song to play right away, append: [PLAY:track_id]
If suggesting or activating Good Night mode, append: [GOOD_NIGHT:true]
Keep replies concise, friendly, and under 3-4 sentences.`;

export async function generateChatbotReply(
  userMessage: string,
  history: { role: 'user' | 'model'; parts: { text: string }[] }[] = []
): Promise<ChatResponsePayload> {
  const msgLower = userMessage.toLowerCase().trim();
  const ai = getAIClient();

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          ...history,
          { role: 'user', parts: [{ text: userMessage }] },
        ],
        config: {
          systemInstruction: SYSTEM_PROMPT,
          temperature: 0.7,
        },
      });

      let rawText = response.text || '';
      let suggestedTrackId: string | undefined;
      let triggerGoodNight = false;

      // Extract [PLAY:track_id]
      const playMatch = rawText.match(/\[PLAY:([a-z0-9_]+)\]/i);
      if (playMatch) {
        suggestedTrackId = playMatch[1];
        rawText = rawText.replace(/\[PLAY:[a-z0-9_]+\]/gi, '').trim();
      }

      // Extract [GOOD_NIGHT:true]
      if (/\[GOOD_NIGHT:true\]/i.test(rawText) || msgLower.includes('good night') || msgLower.includes('shubh ratri')) {
        triggerGoodNight = true;
        rawText = rawText.replace(/\[GOOD_NIGHT:true\]/gi, '').trim();
      }

      const actions = generateQuickActions(msgLower, suggestedTrackId, triggerGoodNight);

      return {
        reply: rawText,
        suggestedTrackId,
        triggerGoodNight,
        suggestedActions: actions,
      };
    } catch (err: any) {
      console.warn('Gemini generateContent fallback:', err?.message || err);
    }
  }

  // High-Intelligence Built-In Fallback Engine (Urdu/Hindi/English)
  return generateIntelligentFallback(userMessage);
}

function generateQuickActions(
  msgLower: string,
  suggestedTrackId?: string,
  isGoodNight?: boolean
) {
  const actions: { label: string; action: string; trackId?: string }[] = [];

  if (isGoodNight || msgLower.includes('night') || msgLower.includes('soye') || msgLower.includes('neend')) {
    actions.push({ label: '🌙 Turn On Good Night Mode', action: 'toggle_good_night' });
    actions.push({ label: '🎵 Play Sleep Lo-Fi Song', action: 'play_track', trackId: 'good_night_lofi' });
    actions.push({ label: '🌧️ Play Midnight Rain', action: 'play_track', trackId: 'midnight_rain' });
    actions.push({ label: '⏱️ Set 30m Sleep Timer', action: 'set_timer_30' });
  } else if (msgLower.includes('sad') || msgLower.includes('dard') || msgLower.includes('dukhi') || msgLower.includes('ghazal')) {
    actions.push({ label: '😢 Play Pashto Sad Rubab', action: 'play_track', trackId: 'pakistani_sad_rubab' });
    actions.push({ label: '🎻 Play Raag Darbari Bansuri', action: 'play_track', trackId: 'pakistani_sad_darbari' });
    actions.push({ label: '💔 Play Tanhai Flute', action: 'play_track', trackId: 'pakistani_sad_tanhai' });
  } else if (msgLower.includes('song') || msgLower.includes('gana') || msgLower.includes('music') || msgLower.includes('lofi')) {
    actions.push({ label: '🎵 Play Royal Lo-Fi Chill', action: 'play_track', trackId: 'royal_lounge' });
    actions.push({ label: '☕ Play Coke Studio Fusion', action: 'play_track', trackId: 'pakistani_coke_studio_sad' });
    actions.push({ label: '🌙 Good Night Beats', action: 'play_track', trackId: 'good_night_lofi' });
  } else {
    actions.push({ label: '🌙 Good Night Mode', action: 'toggle_good_night' });
    actions.push({ label: '🎵 Play Sad Melancholy', action: 'play_track', trackId: 'pakistani_sad_rubab' });
    actions.push({ label: '⚡ How to Download 8K?', action: 'ask_how_download' });
    actions.push({ label: '👑 Buy VIP (250 PKR)', action: 'open_vip' });
  }

  return actions;
}

function generateIntelligentFallback(userMessage: string): ChatResponsePayload {
  const lower = userMessage.toLowerCase().trim();

  // 1. Good Night / Sleep Intent
  if (
    lower.includes('good night') ||
    lower.includes('shubh ratri') ||
    lower.includes('shab bakhair') ||
    lower.includes('so raha') ||
    lower.includes('so rahi') ||
    lower.includes('neend') ||
    lower.includes('sleep') ||
    lower.includes('bedtime')
  ) {
    return {
      reply: '🌙 Shab Bakhair! FADI KING VIP ki taraf se aapko bohot pyari aur pur-sukoon neend naseeb ho. Maine aapke liye Good Night Mode aur soothing lofi beats ready kar diye hain. Aaram se soyein, kal milte hain!',
      suggestedTrackId: 'good_night_lofi',
      triggerGoodNight: true,
      suggestedActions: [
        { label: '🌙 Turn On Good Night Mode', action: 'toggle_good_night' },
        { label: '🎵 Play Sleep Lo-Fi Beats', action: 'play_track', trackId: 'good_night_lofi' },
        { label: '🌧️ Play Rain Ambience', action: 'play_track', trackId: 'midnight_rain' },
        { label: '⏱️ 30m Sleep Timer', action: 'set_timer_30' },
      ],
    };
  }

  // 2. Sad Songs / Dard Bhari Dhun Intent
  if (
    lower.includes('sad') ||
    lower.includes('dard') ||
    lower.includes('dukhi') ||
    lower.includes('gham') ||
    lower.includes('rona') ||
    lower.includes('tanhai') ||
    lower.includes('broken') ||
    lower.includes('dil toota')
  ) {
    return {
      reply: '💔 Dil ko chhu lene wali Pashto Sad Rubab aur Raag Darbari Bansuri haazir hai. Yeh dhun tanhai aur dil ke sukoon ke liye banayi gayi hai. Suniye aur mehsoos kijiye.',
      suggestedTrackId: 'pakistani_sad_rubab',
      suggestedActions: [
        { label: '😢 Play Sad Pashto Rubab', action: 'play_track', trackId: 'pakistani_sad_rubab' },
        { label: '🎻 Play Raag Darbari Melancholy', action: 'play_track', trackId: 'pakistani_sad_darbari' },
        { label: '💔 Play Tanhai Flute', action: 'play_track', trackId: 'pakistani_sad_tanhai' },
      ],
    };
  }

  // 3. Songs / Music / Lofi Intent
  if (
    lower.includes('song') ||
    lower.includes('gana') ||
    lower.includes('music') ||
    lower.includes('dhun') ||
    lower.includes('baja') ||
    lower.includes('lofi') ||
    lower.includes('beat') ||
    lower.includes('play')
  ) {
    return {
      reply: '🎵 FADI KING Royal Audio Studio mein khush-aamdeed! Main aapke liye peaceful Lo-Fi beats ya Pakistani soulful instrumental chala deta hoon. Kaunsa genre pasand karenge?',
      suggestedTrackId: 'royal_lounge',
      suggestedActions: [
        { label: '🎵 Play Royal Lo-Fi Lounge', action: 'play_track', trackId: 'royal_lounge' },
        { label: '☕ Play Coke Studio Fusion', action: 'play_track', trackId: 'pakistani_coke_studio_sad' },
        { label: '🌙 Good Night Sleep Song', action: 'play_track', trackId: 'good_night_lofi' },
      ],
    };
  }

  // 4. Download / Video Help Intent
  if (
    lower.includes('download') ||
    lower.includes('video') ||
    lower.includes('tiktok') ||
    lower.includes('youtube') ||
    lower.includes('instagram') ||
    lower.includes('link') ||
    lower.includes('8k') ||
    lower.includes('4k')
  ) {
    return {
      reply: '⚡ FADI KING se download karna bilkul aasan hai! Kisi bhi TikTok, YouTube, Instagram ya Facebook video ka link copy karein, upar Direct Downloader box mein paste karein aur "Download" dabayein. Zero watermark aur 8K Ultra HD mein save ho jayega!',
      suggestedActions: [
        { label: '⚡ Go to Direct Downloader', action: 'switch_mode_single' },
        { label: '📦 Open Batch URLs (Multi-Link)', action: 'switch_mode_batch' },
        { label: '🎧 Audio & MP3 Studio', action: 'switch_mode_studio' },
      ],
    };
  }

  // 5. VIP / Pricing Intent
  if (
    lower.includes('vip') ||
    lower.includes('price') ||
    lower.includes('pkr') ||
    lower.includes('code') ||
    lower.includes('license') ||
    lower.includes('buy') ||
    lower.includes('kharid')
  ) {
    return {
      reply: '👑 FADI KING Lifetime VIP sirf 250 PKR mein dastiyab hai! Isme aapko unlimited 8K/4K downloads, ad-free experience, batch downloads aur VIP stream relay nodes milte hain. WhatsApp par rabta karein: +923708392045.',
      suggestedActions: [
        { label: '👑 Open VIP Upgrade Modal', action: 'open_vip' },
        { label: '💬 WhatsApp Direct Contact', action: 'open_whatsapp_orders' },
      ],
    };
  }

  // 6. General Greeting
  return {
    reply: '👑 Salam! Main hoon FADI KING VIP Chat Assistant. Main aapki video downloads, 320kbps MP3 audio extraction, relaxing music bajane aur Good Night mode set karne mein madad kar sakta hoon. Aaj main aapki kya khidmat karoon?',
    suggestedActions: [
      { label: '🌙 Good Night Mode', action: 'toggle_good_night' },
      { label: '🎵 Play Relaxing Music', action: 'play_track', trackId: 'good_night_lofi' },
      { label: '😢 Play Sad Rubab Song', action: 'play_track', trackId: 'pakistani_sad_rubab' },
      { label: '⚡ How to Download in 8K', action: 'ask_how_download' },
    ],
  };
}
