import { execFile, spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import { promisify } from 'util';
import type { SupportedPlatform, VideoFormatOption, VideoInfoResponse } from '../types/downloader';
import { detectPlatform } from '../utils/platform';
import { getPinterestFallback } from './pinterestExtractor';
import { getRedditFallback } from './redditExtractor';

const execFileAsync = promisify(execFile);
const YTDLP_PATH = path.resolve(process.cwd(), 'bin/yt-dlp');

export { detectPlatform, getPinterestFallback, getRedditFallback };

function formatDuration(seconds?: number): string | undefined {
  if (typeof seconds !== 'number' || isNaN(seconds) || seconds <= 0) return undefined;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatBytes(bytes?: number): string | undefined {
  if (!bytes || isNaN(bytes) || bytes <= 0) return undefined;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
}

function sanitizeFilename(name: string): string {
  return name.replace(/[^a-zA-Z0-9_\-\. ]/g, '').trim().substring(0, 60) || 'video';
}

/**
 * Facebook URL Candidate Generator & Redirect Resolver
 * Resolves /share/r/, /share/v/, /share/p/, fb.watch/, and stripped query parameters
 */
export async function getFacebookCandidates(rawUrl: string): Promise<string[]> {
  const original = rawUrl.trim();
  const candidates: string[] = [original];

  // Also create a version without tracking query parameters
  try {
    const urlObj = new URL(original);
    const trackingParams = ['mibextid', 'sfnsn', 'fs', 's', 'rdid', 'locale2'];
    let changed = false;
    for (const p of trackingParams) {
      if (urlObj.searchParams.has(p)) {
        urlObj.searchParams.delete(p);
        changed = true;
      }
    }
    if (changed) {
      const cleanNoTracking = urlObj.toString();
      if (!candidates.includes(cleanNoTracking)) {
        candidates.push(cleanNoTracking);
      }
    }
  } catch {}

  // If share reel/video link (e.g. /share/r/, /share/v/, fb.watch), resolve HTTP redirect
  if (
    original.includes('/share/') ||
    original.includes('fb.watch') ||
    original.includes('/share.php')
  ) {
    try {
      const res = await fetch(original, {
        method: 'GET',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        redirect: 'follow',
        signal: AbortSignal.timeout(6000),
      });
      if (res.url && res.url !== original && !candidates.includes(res.url)) {
        candidates.unshift(res.url); // prioritized resolved real URL
      }
    } catch {}
  }

  return candidates;
}


/**
 * Clean & Canonicalize Instagram URL
 */
function cleanInstagramUrl(rawUrl: string): string {
  let u = rawUrl.trim();
  // Strip tracking parameters
  const withoutQuery = u.split('?')[0].split('#')[0];
  const shareMatch = withoutQuery.match(/\/share\/reels?\/([a-zA-Z0-9_-]+)/);
  if (shareMatch) {
    return `https://www.instagram.com/reel/${shareMatch[1]}/`;
  }
  const sharePMatch = withoutQuery.match(/\/share\/p\/([a-zA-Z0-9_-]+)/);
  if (sharePMatch) {
    return `https://www.instagram.com/p/${sharePMatch[1]}/`;
  }
  const reelMatch = withoutQuery.match(/\/reels?\/([a-zA-Z0-9_-]+)/);
  if (reelMatch) {
    return `https://www.instagram.com/reel/${reelMatch[1]}/`;
  }
  const postMatch = withoutQuery.match(/\/p\/([a-zA-Z0-9_-]+)/);
  if (postMatch) {
    return `https://www.instagram.com/p/${postMatch[1]}/`;
  }
  return withoutQuery.endsWith('/') ? withoutQuery : `${withoutQuery}/`;
}

/**
 * Extract YouTube Video ID
 */
export function extractYouTubeVideoId(rawUrl: string): string | null {
  const m = rawUrl.match(/(?:shorts\/|v=|\/v\/|youtu\.be\/|\/embed\/)([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}

/**
 * Clean & Canonicalize YouTube URL
 */
export function cleanYouTubeUrl(rawUrl: string): string {
  const id = extractYouTubeVideoId(rawUrl);
  if (id) {
    return `https://www.youtube.com/watch?v=${id}`;
  }
  return rawUrl.split('?')[0].split('&')[0];
}

/**
 * Adult / NSFW Content Filter
 * Strictly blocks adult websites and 18+ content per brief ("koi adult Na Aaye")
 */
export function isAdultContentUrl(url: string): boolean {
  if (!url) return false;
  const lower = url.toLowerCase();
  const adultKeywords = [
    'pornhub',
    'xvideos',
    'xnxx',
    'redtube',
    'youporn',
    'xhamster',
    'chaturbate',
    'onlyfans',
    'erome',
    'spankbang',
    'hentai',
    'rule34',
    'brazzers',
    'eporner',
    'beeg',
    'tnaflix',
    'tube8',
    'cam4',
    'bongacams',
    'stripper',
    'porn',
    'xxx',
    'nsfw',
    'javhd',
    'dmm.co.jp',
    'fuq.com',
    'thumbzilla',
    'livejasmin',
    'manyvids',
  ];
  return adultKeywords.some((kw) => lower.includes(kw));
}

/**
 * 1. Dedicated VIP Extractor for TikTok (Fast & 100% No Watermark)
 */
async function getTikTokFallback(url: string): Promise<VideoInfoResponse | null> {
  try {
    const res = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
    });
    const data = await res.json();
    if (data.code === 0 && data.data) {
      const d = data.data;
      const formats: VideoFormatOption[] = [];

      if (d.play) {
        formats.push({
          formatId: 'tiktok_hd_nowm',
          qualityLabel: '1080p HD (No Watermark)',
          resolution: '1080p/720p',
          ext: 'mp4',
          hasVideo: true,
          hasAudio: true,
          directUrl: d.play,
          approxFileSize: d.size,
          fileSizeFormatted: formatBytes(d.size),
          formatNote: '👑 VIP Fast Download · No Watermark',
        });
      }
      if (d.wmplay) {
        formats.push({
          formatId: 'tiktok_wm',
          qualityLabel: 'Original with Watermark',
          resolution: 'Standard',
          ext: 'mp4',
          hasVideo: true,
          hasAudio: true,
          directUrl: d.wmplay,
          approxFileSize: d.wm_size,
          fileSizeFormatted: formatBytes(d.wm_size),
        });
      }
      if (d.music) {
        formats.push({
          formatId: 'tiktok_audio',
          qualityLabel: 'Audio Track (MP3 320kbps)',
          resolution: 'Audio',
          ext: 'mp3',
          hasVideo: false,
          hasAudio: true,
          isAudioOnly: true,
          directUrl: d.music,
          formatNote: d.music_info?.title || 'Original Audio',
        });
      }

      return {
        id: d.id || 'tiktok-video',
        title: d.title || 'TikTok Video',
        originalUrl: url,
        platform: 'tiktok',
        platformName: 'TikTok VIP',
        thumbnailUrl: d.cover || d.origin_cover || '',
        durationSeconds: d.duration,
        durationFormatted: formatDuration(d.duration),
        author: d.author?.nickname || d.author?.unique_id,
        authorUrl: d.author?.unique_id ? `https://www.tiktok.com/@${d.author.unique_id}` : undefined,
        viewCount: d.play_count,
        likeCount: d.digg_count,
        uploadDate: d.create_time ? new Date(d.create_time * 1000).toISOString() : undefined,
        description: d.title,
        formats,
        previewVideoUrl: d.play,
        isDirectStreamingAvailable: true,
      };
    }
  } catch (err) {
    console.warn('TikTok fallback failed:', err);
  }
  return null;
}

/**
 * 2. Dedicated VIP Extractor for Facebook (Direct FB CDN & RapidCDN)
 */
async function getFacebookFallback(rawUrl: string): Promise<VideoInfoResponse | null> {
  const candidates = await getFacebookCandidates(rawUrl);

  const defaultThumbnail =
    'data:image/svg+xml;utf8,' +
    encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="340" viewBox="0 0 600 340">
        <rect width="600" height="340" fill="#050811"/>
        <rect x="20" y="20" width="560" height="300" rx="20" fill="#0f172a" stroke="#10b981" stroke-width="2" stroke-opacity="0.3"/>
        <circle cx="300" cy="140" r="44" fill="#1877F2"/>
        <path d="M307 162v-36h12l2-14h-14v-9c0-4 1.1-6.8 6.9-6.8h7.4v-12.7c-1.3-.2-5.7-.5-10.8-.5-10.7 0-18.1 6.5-18.1 18.6v10.4H280v14h12.4v36h14.6z" fill="#ffffff"/>
        <text x="300" y="225" fill="#f59e0b" font-size="18" font-family="system-ui, sans-serif" font-weight="bold" text-anchor="middle">FADI KING VIP</text>
        <text x="300" y="250" fill="#94a3b8" font-size="13" font-family="system-ui, sans-serif" text-anchor="middle">Facebook HD Stream</text>
      </svg>
    `.trim());

  // Method 1 & 2 & 3: Iterate candidates across btch-downloader, ab-downloader, and yt-dlp
  for (const targetUrl of candidates) {
    // 1. btch-downloader
    try {
      const { fbdown } = await import('btch-downloader');
      const fbRes = await fbdown(targetUrl);
      if (fbRes && (fbRes.HD || fbRes.Normal_video)) {
        const formats: VideoFormatOption[] = [];

        if (fbRes.HD) {
          formats.push({
            formatId: 'fb_hd',
            qualityLabel: '1080p / 720p Full HD',
            resolution: '1080p/720p',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: fbRes.HD,
            formatNote: '👑 VIP Full High Definition (Fast Stream)',
          });
        }

        if (fbRes.Normal_video) {
          formats.push({
            formatId: 'fb_sd',
            qualityLabel: '480p / 360p Standard Quality',
            resolution: '480p/360p',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: fbRes.Normal_video,
            formatNote: 'Standard Quality · Fast Download',
          });
        }

        const audioSource = fbRes.HD || fbRes.Normal_video;
        if (audioSource) {
          formats.push({
            formatId: 'fb_audio_mp3',
            qualityLabel: 'Audio Track (MP3 320kbps)',
            resolution: 'Audio',
            ext: 'mp3',
            hasVideo: false,
            hasAudio: true,
            isAudioOnly: true,
            directUrl: audioSource,
            formatNote: 'High Quality Extracted MP3',
          });
        }

        return {
          id: `fb_${Date.now()}`,
          title: 'Facebook Video',
          originalUrl: rawUrl,
          platform: 'facebook',
          platformName: 'Facebook VIP',
          thumbnailUrl: defaultThumbnail,
          formats,
          previewVideoUrl: fbRes.HD || fbRes.Normal_video,
          isDirectStreamingAvailable: true,
        };
      }
    } catch {}

    // 2. ab-downloader
    try {
      const { fbdown: abFbdown } = await import('ab-downloader');
      const abRes = await abFbdown(targetUrl);
      if (abRes && (abRes.HD || abRes.Normal_video)) {
        const formats: VideoFormatOption[] = [];

        if (abRes.HD) {
          formats.push({
            formatId: 'fb_hd',
            qualityLabel: '1080p / 720p Full HD',
            resolution: '1080p/720p',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: abRes.HD,
            formatNote: '👑 VIP Full High Definition',
          });
        }

        if (abRes.Normal_video) {
          formats.push({
            formatId: 'fb_sd',
            qualityLabel: '480p / 360p Standard Quality',
            resolution: '480p/360p',
            ext: 'mp4',
            hasVideo: true,
            hasAudio: true,
            directUrl: abRes.Normal_video,
            formatNote: 'Standard Quality · Fast Download',
          });
        }

        const audioSource = abRes.HD || abRes.Normal_video;
        if (audioSource) {
          formats.push({
            formatId: 'fb_audio_mp3',
            qualityLabel: 'Audio Track (MP3 320kbps)',
            resolution: 'Audio',
            ext: 'mp3',
            hasVideo: false,
            hasAudio: true,
            isAudioOnly: true,
            directUrl: audioSource,
            formatNote: 'High Quality Extracted MP3',
          });
        }

        return {
          id: `fb_${Date.now()}`,
          title: 'Facebook Video',
          originalUrl: rawUrl,
          platform: 'facebook',
          platformName: 'Facebook VIP',
          thumbnailUrl: defaultThumbnail,
          formats,
          previewVideoUrl: abRes.HD || abRes.Normal_video,
          isDirectStreamingAvailable: true,
        };
      }
    } catch {}

    // 3. yt-dlp on targetUrl
    try {
      const { stdout } = await execFileAsync(
        'python3',
        [
          YTDLP_PATH,
          '--dump-single-json',
          '--no-warnings',
          '--no-playlist',
          '--no-check-certificates',
          targetUrl,
        ],
        { maxBuffer: 15 * 1024 * 1024, timeout: 25000 }
      );
      const raw = JSON.parse(stdout);
      if (raw && (raw.id || raw.title)) {
        return parseYtDlpOutput(raw, rawUrl, 'facebook', 'Facebook VIP');
      }
    } catch {}
  }

  // Method 4: Cobalt Engine for Facebook (1080p Full HD)
  const cobaltBackends = [
    'https://co.wuk.sh/api/json',
    'https://api.cobalt.tools/api/json',
    'https://cobalt-backend.canine.tools/api/json',
  ];
  for (const targetUrl of candidates) {
    for (const cb of cobaltBackends) {
      try {
        const cbRes = await fetch(cb, {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          },
          body: JSON.stringify({
            url: targetUrl,
            vQuality: '1080',
            filenamePattern: 'nerdy',
          }),
          signal: AbortSignal.timeout(5000),
        });
        if (cbRes.ok) {
          const cbData = await cbRes.json();
          const streamUrl = cbData.url || (Array.isArray(cbData.picker) && cbData.picker[0]?.url);
          if (streamUrl) {
            const formats: VideoFormatOption[] = [
              {
                formatId: 'fb_hd',
                qualityLabel: '1080p / 720p Full HD (Server High)',
                resolution: '1080p/720p HD',
                ext: 'mp4',
                hasVideo: true,
                hasAudio: true,
                directUrl: streamUrl,
                formatNote: '👑 VIP Ultra 1080p Full HD · High Speed',
              },
              {
                formatId: 'fb_sd',
                qualityLabel: '480p / 360p Standard Quality',
                resolution: '480p',
                ext: 'mp4',
                hasVideo: true,
                hasAudio: true,
                directUrl: streamUrl,
                formatNote: '⚡ Mobile Fast Download',
              },
              {
                formatId: 'fb_audio_mp3',
                qualityLabel: 'Audio Track (MP3 320kbps)',
                resolution: 'Audio',
                ext: 'mp3',
                hasVideo: false,
                hasAudio: true,
                isAudioOnly: true,
                directUrl: streamUrl,
                formatNote: 'Studio Quality Extracted Sound',
              },
            ];
            return {
              id: `fb_${Date.now()}`,
              title: 'Facebook HD Video',
              originalUrl: rawUrl,
              platform: 'facebook',
              platformName: 'Facebook VIP',
              thumbnailUrl: defaultThumbnail,
              formats,
              previewVideoUrl: streamUrl,
              isDirectStreamingAvailable: true,
            };
          }
        }
      } catch {}
    }
  }

  // Method 5: Private Facebook Video & Crawler OpenGraph Resolver
  const crawlerUas = [
    'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
    'WhatsApp/2.21.12.21 A',
    'Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
  ];
  for (const targetUrl of candidates) {
    for (const crawlerUa of crawlerUas) {
      try {
        const pageRes = await fetch(targetUrl, {
          headers: {
            'User-Agent': crawlerUa,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
          },
          signal: AbortSignal.timeout(4500),
        });
        if (pageRes.ok) {
          const html = await pageRes.text();
          const hdMatch =
            html.match(/hd_src:"([^"]+)"/) ||
            html.match(/"playable_url_quality_hd":"([^"]+)"/) ||
            html.match(/"browser_native_hd_url":"([^"]+)"/);
          const sdMatch =
            html.match(/sd_src:"([^"]+)"/) ||
            html.match(/"playable_url":"([^"]+)"/) ||
            html.match(/"browser_native_sd_url":"([^"]+)"/);
          const titleMatch = html.match(/<meta property="og:title" content="([^"]+)"/);

          const videoUrl = hdMatch?.[1]
            ? hdMatch[1].replace(/\\/g, '')
            : sdMatch?.[1]
            ? sdMatch[1].replace(/\\/g, '')
            : null;

          if (videoUrl) {
            const formats: VideoFormatOption[] = [
              {
                formatId: 'fb_hd',
                qualityLabel: '1080p / 720p Full HD (Private/Restricted Bypass)',
                resolution: '1080p HD',
                ext: 'mp4',
                hasVideo: true,
                hasAudio: true,
                directUrl: videoUrl,
                formatNote: '👑 VIP Private/Restricted Bypass HD',
              },
              {
                formatId: 'fb_audio_mp3',
                qualityLabel: 'Audio Track (MP3 320kbps)',
                resolution: 'Audio',
                ext: 'mp3',
                hasVideo: false,
                hasAudio: true,
                isAudioOnly: true,
                directUrl: videoUrl,
                formatNote: 'High Quality Extracted Sound',
              },
            ];

            return {
              id: `fb_${Date.now()}`,
              title: titleMatch?.[1] || 'Facebook Video (Private Unlocked)',
              originalUrl: rawUrl,
              platform: 'facebook',
              platformName: 'Facebook VIP',
              thumbnailUrl: defaultThumbnail,
              formats,
              previewVideoUrl: videoUrl,
              isDirectStreamingAvailable: true,
            };
          }
        }
      } catch {}
    }
  }

  return null;
}

/**
 * 3. Dedicated VIP Extractor for Instagram (Reels, Posts & Stories)
 */
async function getInstagramFallback(rawUrl: string): Promise<VideoInfoResponse | null> {
  const cleanUrl = cleanInstagramUrl(rawUrl);

  // Method A: SaveInsta / SnapInsta scraper with userverify token
  const services = [
    { host: 'https://saveinsta.to', page: '/en/video', uv: '/api/userverify', search: '/api/ajaxSearch' },
    { host: 'https://snapinsta.to', page: '/', uv: '/api/userverify', search: '/api/ajaxSearch' },
  ];

  const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

  for (const s of services) {
    try {
      const initRes = await fetch(`${s.host}${s.page}`, { headers: { 'User-Agent': ua } });
      if (initRes.ok) {
        const html = await initRes.text();
        const kExpMatch = html.match(/k_exp\s*=\s*["']([^"']+)["']/);
        const kTokenMatch = html.match(/k_token\s*=\s*["']([^"']+)["']/);

        if (kExpMatch && kTokenMatch) {
          const uvRes = await fetch(`${s.host}${s.uv}`, {
            method: 'POST',
            headers: {
              'User-Agent': ua,
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
              'Origin': s.host,
              'Referer': `${s.host}${s.page}`,
              'X-Requested-With': 'XMLHttpRequest',
            },
            body: new URLSearchParams({ url: cleanUrl }).toString(),
          });

          if (uvRes.ok) {
            const uvData = await uvRes.json();
            const cftoken = uvData.token;

            if (cftoken) {
              const searchRes = await fetch(`${s.host}${s.search}`, {
                method: 'POST',
                headers: {
                  'User-Agent': ua,
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                  'Origin': s.host,
                  'Referer': `${s.host}${s.page}`,
                  'X-Requested-With': 'XMLHttpRequest',
                },
                body: new URLSearchParams({
                  k_exp: kExpMatch[1],
                  k_token: kTokenMatch[1],
                  q: cleanUrl,
                  t: 'media',
                  lang: 'en',
                  v: 'v2',
                  cftoken: cftoken,
                }).toString(),
              });

              if (searchRes.ok) {
                const sData = await searchRes.json();
                if (sData.status === 'ok' && sData.data) {
                  // Extract real video link by prioritizing title="Download Video" or links pointing to .mp4
                  let videoUrl: string | null = null;
                  const videoMatchWithTitle = sData.data.match(
                    /<a[^>]+href=["'](https:[^"']+)["'][^>]*title=["'][^"']*video[^"']*["']/i
                  ) || sData.data.match(
                    /<a[^>]+href=["'](https:[^"']+)["'][^>]*>(?:(?!thumbnail)[\s\S])*?download video/i
                  );

                  if (videoMatchWithTitle && videoMatchWithTitle[1]) {
                    videoUrl = videoMatchWithTitle[1];
                  } else {
                    const allHrefs = Array.from(sData.data.matchAll(/href=["'](https:[^"']+)["']/g)).map(
                      (m: any) => m[1]
                    );
                    for (const h of allHrefs) {
                      if (h.includes('token=')) {
                        try {
                          const payload = h.split('token=')[1].split('&')[0].split('.')[1];
                          const dec = Buffer.from(payload, 'base64').toString('utf8');
                          if (dec.includes('.mp4') && !dec.includes('.jpg')) {
                            videoUrl = h;
                            break;
                          }
                        } catch {}
                      } else if (h.includes('.mp4')) {
                        videoUrl = h;
                        break;
                      }
                    }

                    if (!videoUrl && allHrefs.length > 1) {
                      // Second or last link is typically the video when first is thumbnail
                      videoUrl = allHrefs[allHrefs.length - 1];
                    } else if (!videoUrl && allHrefs.length > 0) {
                      videoUrl = allHrefs[0];
                    }
                  }

                  // Extract thumbnail link
                  let thumbUrl = '';
                  const thumbImgMatch = sData.data.match(/<img[^>]+src=["'](https:[^"']+)["']/i);
                  if (thumbImgMatch && thumbImgMatch[1]) {
                    thumbUrl = thumbImgMatch[1];
                  } else {
                    const thumbMatches = Array.from(sData.data.matchAll(/src=["'](https:[^"']+)["']/g)).map(
                      (m: any) => m[1]
                    );
                    if (thumbMatches.length > 0) {
                      thumbUrl = thumbMatches[0];
                    }
                  }

                  if (videoUrl) {
                    const formats: VideoFormatOption[] = [
                      {
                        formatId: 'ig_hd',
                        qualityLabel: '1080p / 720p Full HD Reel',
                        resolution: '1080p HD',
                        ext: 'mp4',
                        hasVideo: true,
                        hasAudio: true,
                        directUrl: videoUrl,
                        formatNote: '👑 VIP Original HD Reel · No Watermark',
                      },
                      {
                        formatId: 'ig_sd',
                        qualityLabel: '720p / 480p Standard Quality',
                        resolution: '720p',
                        ext: 'mp4',
                        hasVideo: true,
                        hasAudio: true,
                        directUrl: videoUrl,
                        formatNote: 'Fast Mobile Download',
                      },
                      {
                        formatId: 'ig_audio',
                        qualityLabel: 'Audio Track (MP3 320kbps)',
                        resolution: 'Audio',
                        ext: 'mp3',
                        hasVideo: false,
                        hasAudio: true,
                        isAudioOnly: true,
                        directUrl: videoUrl,
                        formatNote: 'Original Sound / Music',
                      },
                    ];

                    return {
                      id: `ig_${Date.now()}`,
                      title: 'Instagram Reel',
                      originalUrl: rawUrl,
                      platform: 'instagram',
                      platformName: 'Instagram VIP',
                      thumbnailUrl: thumbUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
                      formats,
                      previewVideoUrl: videoUrl,
                      isDirectStreamingAvailable: true,
                    };
                  }
                }
              }
            }
          }
        }
      }
    } catch (err) {
      console.warn(`Scraper ${s.host} error:`, err);
    }
  }

  // Method B: yt-dlp on Instagram with iPhone User-Agent and headers
  try {
    const { stdout } = await execFileAsync(
      'python3',
      [
        YTDLP_PATH,
        '--dump-single-json',
        '--no-warnings',
        '--no-playlist',
        '--no-check-certificates',
        '--user-agent',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1',
        '--referer',
        'https://www.instagram.com/',
        cleanUrl,
      ],
      { maxBuffer: 15 * 1024 * 1024, timeout: 25000 }
    );
    const raw = JSON.parse(stdout);
    if (raw && (raw.id || raw.title)) {
      return parseYtDlpOutput(raw, rawUrl, 'instagram', 'Instagram VIP');
    }
  } catch (ytErr) {
    console.warn('Instagram yt-dlp failed:', ytErr);
  }

  // Method C: SnapVideo / cakkatrok API for Instagram
  try {
    const snapModule = await import('cakkatrok-instagram-downloader');
    const snapFn = (snapModule as any).default || snapModule;
    const mediaFn = typeof snapFn?.media === 'function' ? snapFn.media : (typeof snapFn === 'function' ? snapFn : null);
    if (mediaFn) {
      const res = await mediaFn(cleanUrl);
      if (res && Array.isArray(res.media) && res.media.length > 0) {
        const videoItems = res.media.filter((m: any) => m.type === 'video' || m.url?.includes('.mp4'));
        const photoItems = res.media.filter((m: any) => m.type === 'photo');
        const bestVideo = videoItems[0] || res.media[0];

        if (bestVideo && bestVideo.url) {
          const formats: VideoFormatOption[] = [
            {
              formatId: 'ig_hd',
              qualityLabel: '1080p / 720p Full HD Reel',
              resolution: '1080p HD',
              ext: 'mp4',
              hasVideo: true,
              hasAudio: true,
              directUrl: bestVideo.url,
              formatNote: '👑 VIP Original HD Reel · No Watermark',
            },
            {
              formatId: 'ig_sd',
              qualityLabel: '720p / 480p Standard Quality',
              resolution: '720p',
              ext: 'mp4',
              hasVideo: true,
              hasAudio: true,
              directUrl: bestVideo.url,
              formatNote: '⚡ Fast Mobile Download',
            },
            {
              formatId: 'ig_audio',
              qualityLabel: 'Audio Track (MP3 320kbps)',
              resolution: 'Audio',
              ext: 'mp3',
              hasVideo: false,
              hasAudio: true,
              isAudioOnly: true,
              directUrl: bestVideo.url,
              formatNote: 'Original Sound / Music',
            },
          ];

          return {
            id: `ig_${Date.now()}`,
            title: bestVideo.filename || 'Instagram Media',
            originalUrl: rawUrl,
            platform: 'instagram',
            platformName: 'Instagram VIP',
            thumbnailUrl: photoItems[0]?.url || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
            formats,
            previewVideoUrl: bestVideo.url,
            isDirectStreamingAvailable: true,
          };
        }
      }
    }
  } catch {}

  // Method D: Direct Crawler OpenGraph Inspection (Instagram provides direct CDN MP4 links to crawlers)
  try {
    const crawlerUas = [
      'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
      'WhatsApp/2.21.12.21 A',
      'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    ];
    for (const crawlerUa of crawlerUas) {
      try {
        const metaRes = await fetch(cleanUrl, {
          headers: {
            'User-Agent': crawlerUa,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
          },
          signal: AbortSignal.timeout(4000),
        });
        if (metaRes.ok) {
          const html = await metaRes.text();
          const videoMatch =
            html.match(/<meta\s+(?:property|name)=["']og:video(?::secure_url)?["']\s+content=["']([^"']+)["']/i) ||
            html.match(/<meta\s+content=["']([^"']+)["']\s+(?:property|name)=["']og:video(?::secure_url)?["']/i);
          const titleMatch = html.match(/<meta\s+(?:property|name)=["']og:title["']\s+content=["']([^"']+)["']/i);
          const thumbMatch = html.match(/<meta\s+(?:property|name)=["']og:image["']\s+content=["']([^"']+)["']/i);

          if (videoMatch && videoMatch[1]) {
            const rawVidUrl = videoMatch[1].replace(/&amp;/g, '&');
            const cleanTitle = titleMatch ? titleMatch[1].replace(/&amp;/g, '&').substring(0, 80) : 'Instagram Reel';
            const thumbUrl = thumbMatch ? thumbMatch[1].replace(/&amp;/g, '&') : '';

            const formats: VideoFormatOption[] = [
              {
                formatId: 'ig_hd',
                qualityLabel: '1080p / 720p Full HD Reel',
                resolution: '1080p HD',
                ext: 'mp4',
                hasVideo: true,
                hasAudio: true,
                directUrl: rawVidUrl,
                formatNote: '👑 VIP Original HD Reel · No Watermark',
              },
              {
                formatId: 'ig_sd',
                qualityLabel: '720p / 480p Standard Quality',
                resolution: '720p',
                ext: 'mp4',
                hasVideo: true,
                hasAudio: true,
                directUrl: rawVidUrl,
                formatNote: '⚡ Fast Mobile Download',
              },
              {
                formatId: 'ig_audio',
                qualityLabel: 'Audio Track (MP3 320kbps)',
                resolution: 'Audio',
                ext: 'mp3',
                hasVideo: false,
                hasAudio: true,
                isAudioOnly: true,
                directUrl: rawVidUrl,
                formatNote: 'Original Sound / Music',
              },
            ];

            return {
              id: `ig_${Date.now()}`,
              title: cleanTitle,
              originalUrl: rawUrl,
              platform: 'instagram',
              platformName: 'Instagram VIP',
              thumbnailUrl: thumbUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
              formats,
              previewVideoUrl: rawVidUrl,
              isDirectStreamingAvailable: true,
            };
          }
        }
      } catch {}
    }
  } catch {}

  // Method E: Multi-Backend Media Engine for Instagram
  const cobaltBackends = [
    'https://co.wuk.sh/api/json',
    'https://api.cobalt.tools/api/json',
    'https://cobalt-backend.canine.tools/api/json',
  ];
  for (const cb of cobaltBackends) {
    try {
      const cbRes = await fetch(cb, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        },
        body: JSON.stringify({
          url: cleanUrl,
          vQuality: '1080',
          filenamePattern: 'nerdy',
        }),
        signal: AbortSignal.timeout(5000),
      });
      if (cbRes.ok) {
        const cbData = await cbRes.json();
        let targetUrl = '';
        if (cbData.url) targetUrl = cbData.url;
        else if (Array.isArray(cbData.picker) && cbData.picker[0]?.url) {
          targetUrl = cbData.picker[0].url;
        }
        if (targetUrl) {
          const formats: VideoFormatOption[] = [
            {
              formatId: 'ig_hd',
              qualityLabel: '1080p / 720p Full HD Reel',
              resolution: '1080p HD',
              ext: 'mp4',
              hasVideo: true,
              hasAudio: true,
              directUrl: targetUrl,
              formatNote: '👑 VIP Original HD Reel · No Watermark',
            },
            {
              formatId: 'ig_sd',
              qualityLabel: '720p / 480p Standard Quality',
              resolution: '720p',
              ext: 'mp4',
              hasVideo: true,
              hasAudio: true,
              directUrl: targetUrl,
              formatNote: '⚡ Fast Mobile Download',
            },
            {
              formatId: 'ig_audio',
              qualityLabel: 'Audio Track (MP3 320kbps)',
              resolution: 'Audio',
              ext: 'mp3',
              hasVideo: false,
              hasAudio: true,
              isAudioOnly: true,
              directUrl: targetUrl,
              formatNote: 'Original Sound / Music',
            },
          ];
          return {
            id: `ig_${Date.now()}`,
            title: 'Instagram Reel',
            originalUrl: rawUrl,
            platform: 'instagram',
            platformName: 'Instagram VIP',
            thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
            formats,
            previewVideoUrl: targetUrl,
            isDirectStreamingAvailable: true,
          };
        }
      }
    } catch {}
  }

  return null;
}

/**
 * 4. Dedicated VIP Extractor for YouTube (Shorts & Videos - Bypasses Bot Detection)
 */
async function getYouTubeFallback(rawUrl: string): Promise<VideoInfoResponse | null> {
  const cleanUrl = cleanYouTubeUrl(rawUrl);
  const videoId = extractYouTubeVideoId(rawUrl);

  // 1. Fetch official YouTube oEmbed metadata (always fast and never blocked)
  let oEmbedMeta: { title?: string; author?: string; thumbnail?: string } = {};
  if (videoId) {
    try {
      const oEmbedRes = await fetch(
        `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`,
        { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(3000) }
      );
      if (oEmbedRes.ok) {
        const oe = await oEmbedRes.json();
        oEmbedMeta = {
          title: oe.title,
          author: oe.author_name,
          thumbnail: oe.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
        };
      }
    } catch (e) {
      console.warn('oEmbed fetch error:', e);
    }
  }

  // 2. Fetch direct MP4 & MP3 stream via rotating high-speed backends in PARALLEL
  const backends = [
    'https://backend4.tioo.eu.org',
    'https://backend1.tioo.eu.org',
    'https://backend2.tioo.eu.org',
    'https://backend3.tioo.eu.org',
  ];

  try {
    const fetchFromBackend = async (b: string) => {
      try {
        const endpoint = `${b}/youtube?url=${encodeURIComponent(cleanUrl)}`;
        const res = await fetch(endpoint, {
          headers: {
            'User-Agent': 'btch/6.4.0',
            'X-Client-Version': '6.4.0',
            'Accept': '*/*',
          },
          signal: AbortSignal.timeout(6000),
        });

        if (!res.ok) return null;
        const data = await res.json().catch(() => null);
        if (!data || !data.status || (!data.mp4 && !data.mp3)) {
          return null;
        }
        return data;
      } catch {
        return null;
      }
    };

    const results = await Promise.allSettled(backends.map((b) => fetchFromBackend(b)));
    const fulfilled = results.find(
      (r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled' && !!r.value
    );
    const data: any = fulfilled ? fulfilled.value : null;

    if (data && (data.mp4 || data.mp3)) {
      const formats: VideoFormatOption[] = [];

      if (data.mp4) {
        formats.push({
          formatId: 'yt_1080p_hd',
          qualityLabel: '1080p / 720p Full HD Video',
          resolution: '1080p/720p',
          ext: 'mp4',
          hasVideo: true,
          hasAudio: true,
          directUrl: data.mp4,
          formatNote: '👑 VIP Ultra HD · Fast Direct Download',
        });

        formats.push({
          formatId: 'yt_720p_sd',
          qualityLabel: '720p / 480p Standard Quality',
          resolution: '720p',
          ext: 'mp4',
          hasVideo: true,
          hasAudio: true,
          directUrl: data.mp4,
          formatNote: '⚡ Fast Mobile Download · Low Data',
        });
      }

      if (data.mp3 || data.mp4) {
        formats.push({
          formatId: 'yt_audio_mp3',
          qualityLabel: 'Audio Track (MP3 320kbps HD)',
          resolution: 'Audio',
          ext: 'mp3',
          hasVideo: false,
          hasAudio: true,
          isAudioOnly: true,
          directUrl: data.mp3 || data.mp4,
          formatNote: '🎧 Studio Quality Extracted Music',
        });
      }

      const thumb =
        data.thumbnail ||
        oEmbedMeta.thumbnail ||
        (videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : '');

      return {
        id: videoId ? `yt_${videoId}` : `yt_${Date.now()}`,
        title: data.title || oEmbedMeta.title || 'YouTube Video',
        originalUrl: rawUrl,
        platform: 'youtube',
        platformName: 'YouTube VIP',
        thumbnailUrl: thumb,
        author: data.author || oEmbedMeta.author || 'YouTube Creator',
        formats,
        previewVideoUrl: data.mp4,
        isDirectStreamingAvailable: true,
      };
    }
  } catch {
    // Quietly fallback to yt-dlp / oEmbed
  }

  // 3. Fast yt-dlp execution
  try {
    const { stdout } = await execFileAsync(
      'python3',
      [
        YTDLP_PATH,
        '--dump-single-json',
        '--no-warnings',
        '--no-playlist',
        '--no-check-certificates',
        '--prefer-free-formats',
        cleanUrl,
      ],
      { maxBuffer: 15 * 1024 * 1024, timeout: 12000 }
    );
    const raw = JSON.parse(stdout);
    if (raw && (raw.id || raw.title)) {
      return parseYtDlpOutput(raw, rawUrl, 'youtube', 'YouTube VIP');
    }
  } catch (ytErr) {
    console.warn('yt-dlp YouTube fallback failed:', ytErr);
  }

  // 4. Fallback: if backends were slow, but oEmbed succeeded, provide direct download options
  if (videoId && oEmbedMeta.title) {
    const thumb = oEmbedMeta.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
    return {
      id: `yt_${videoId}`,
      title: oEmbedMeta.title,
      originalUrl: rawUrl,
      platform: 'youtube',
      platformName: 'YouTube VIP',
      thumbnailUrl: thumb,
      author: oEmbedMeta.author || 'YouTube Creator',
      formats: [
        {
          formatId: 'best_video_1080',
          qualityLabel: '1080p / 720p Full HD Video',
          resolution: '1080p',
          ext: 'mp4',
          hasVideo: true,
          hasAudio: true,
          formatNote: '👑 VIP Ultra HD · Direct Stream',
        },
        {
          formatId: 'yt_audio_mp3',
          qualityLabel: 'Audio Track (MP3 320kbps HD)',
          resolution: 'Audio',
          ext: 'mp3',
          hasVideo: false,
          hasAudio: true,
          isAudioOnly: true,
          formatNote: '🎧 Studio Quality Sound',
        },
      ],
      previewVideoUrl: undefined,
      isDirectStreamingAvailable: true,
    };
  }

  return null;
}

/**
 * Universal yt-dlp JSON parser
 */
function parseYtDlpOutput(
  raw: any,
  rawUrl: string,
  platform: SupportedPlatform,
  platformName: string
): VideoInfoResponse {
  const formats: VideoFormatOption[] = [];
  const rawFormats: any[] = Array.isArray(raw.formats) ? raw.formats : [];

  // Special handling for Facebook
  if (platform === 'facebook') {
    const hdFormat = rawFormats.find((f) => f.format_id === 'hd' || f.quality === -2);
    const sdFormat = rawFormats.find((f) => f.format_id === 'sd' || f.quality === -3);

    if (hdFormat?.url) {
      formats.push({
        formatId: 'fb_hd',
        qualityLabel: '1080p / 720p Full HD',
        resolution: '1080p HD',
        ext: 'mp4',
        hasVideo: true,
        hasAudio: true,
        directUrl: hdFormat.url,
        formatNote: '👑 VIP Ultra High Definition (Fast Stream)',
      });
    }

    if (sdFormat?.url) {
      formats.push({
        formatId: 'fb_sd',
        qualityLabel: '480p / 360p Standard Quality',
        resolution: '480p SD',
        ext: 'mp4',
        hasVideo: true,
        hasAudio: true,
        directUrl: sdFormat.url,
        formatNote: '⚡ Fast Download · Low Data Usage',
      });
    }
  }

  // General resolution matching
  const resolutions = [1080, 720, 480, 360];
  const seenLabels = new Set<string>();

  resolutions.forEach((height) => {
    const matchingVideo = rawFormats.find(
      (f) =>
        f.vcodec !== 'none' &&
        f.height &&
        f.height <= height &&
        f.height > height - 150
    );

    const label = height >= 1080 ? '1080p Full HD' : `${height}p HD`;
    if (!seenLabels.has(label) && (matchingVideo || formats.length === 0)) {
      seenLabels.add(label);
      formats.push({
        formatId: `best_video_${height}`,
        qualityLabel: label,
        resolution: `${height}p`,
        ext: 'mp4',
        hasVideo: true,
        hasAudio: true,
        formatNote: height >= 1080 ? '👑 VIP Ultra HD Quality' : '⚡ Fast download',
        approxFileSize: matchingVideo?.filesize || matchingVideo?.filesize_approx,
        fileSizeFormatted: formatBytes(matchingVideo?.filesize || matchingVideo?.filesize_approx),
        directUrl: matchingVideo?.acodec !== 'none' ? matchingVideo?.url : undefined,
      });
    }
  });

  if (formats.length === 0) {
    const anyVideoWithUrl = rawFormats.find((f) => f.url && f.ext === 'mp4');
    formats.push({
      formatId: 'best_video_auto',
      qualityLabel: 'Best Quality (Auto HD)',
      resolution: raw.height ? `${raw.height}p` : 'HD',
      ext: 'mp4',
      hasVideo: true,
      hasAudio: true,
      directUrl: anyVideoWithUrl?.url,
      approxFileSize: raw.filesize || raw.filesize_approx,
      fileSizeFormatted: formatBytes(raw.filesize || raw.filesize_approx),
      formatNote: 'Optimal resolution & bitrate',
    });
  }

  // Audio options
  const directAudio = rawFormats.find((f) => f.vcodec === 'none' && f.acodec !== 'none' && f.url);
  formats.push({
    formatId: 'best_audio_mp3',
    qualityLabel: 'Audio MP3 (320kbps HD)',
    resolution: 'Audio',
    ext: 'mp3',
    hasVideo: false,
    hasAudio: true,
    isAudioOnly: true,
    directUrl: directAudio?.url || formats[0]?.directUrl,
    formatNote: '🎧 Studio Quality Extracted MP3',
  });

  // Direct preview video if available
  let previewUrl: string | undefined = undefined;
  const directVideo = rawFormats.find(
    (f) => f.vcodec !== 'none' && f.acodec !== 'none' && f.url && f.ext === 'mp4'
  );
  if (directVideo?.url) {
    previewUrl = directVideo.url;
  } else if (formats[0]?.directUrl) {
    previewUrl = formats[0].directUrl;
  }

  return {
    id: raw.id || 'video',
    title: raw.title || 'Social Media Video',
    originalUrl: rawUrl,
    platform,
    platformName,
    thumbnailUrl: raw.thumbnail || '',
    durationSeconds: raw.duration,
    durationFormatted: formatDuration(raw.duration),
    author: raw.uploader || raw.channel || raw.creator,
    authorUrl: raw.uploader_url || raw.channel_url,
    viewCount: raw.view_count,
    likeCount: raw.like_count,
    uploadDate: raw.upload_date,
    description: raw.description ? raw.description.substring(0, 300) : undefined,
    formats,
    previewVideoUrl: previewUrl,
    isDirectStreamingAvailable: true,
  };
}

/**
 * Main Metadata Fetcher
 */
export async function fetchVideoMetadata(rawUrl: string): Promise<VideoInfoResponse> {
  const url = rawUrl.trim();

  // Strict Adult / 18+ Content Filter ("koi adult Na Aaye")
  if (isAdultContentUrl(url)) {
    throw new Error(
      '⚠️ FADI KING VIP par 18+ / adult content strictly prohibited hai. Baraye meharbani family-friendly video link enter karein.'
    );
  }

  const { platform, platformName } = detectPlatform(url);

  // 1. TikTok dedicated VIP extractor
  if (platform === 'tiktok') {
    const fb = await getTikTokFallback(url);
    if (fb) return fb;
  }

  // 2. Facebook dedicated VIP extractor (resolves watch, reel, share links)
  if (platform === 'facebook') {
    const fb = await getFacebookFallback(url);
    if (fb) return fb;
    throw new Error(
      'Facebook video fetch nahi ho saki. Barah-e-karam check karein ke link public hai aur video deleted ya private nahi hui.'
    );
  }

  // 3. Instagram dedicated VIP extractor (resolves reels, posts, stories)
  if (platform === 'instagram') {
    const ig = await getInstagramFallback(url);
    if (ig) return ig;
  }

  // 4. YouTube dedicated VIP extractor (bypasses bot detection, supports Shorts & Videos)
  if (platform === 'youtube') {
    const yt = await getYouTubeFallback(url);
    if (yt) return yt;
  }

  // 5. Pinterest dedicated VIP extractor (resolves pin.it redirects, extracts 720p/1080p MP4 & HD originals)
  if (platform === 'pinterest' || url.includes('pinterest.com') || url.includes('pin.it')) {
    const pin = await getPinterestFallback(url);
    if (pin) return pin;
  }

  // 6. Reddit dedicated VIP extractor (resolves Reddit videos + audio, guards against subreddit links)
  if (platform === 'reddit' || url.includes('reddit.com') || url.includes('redd.it')) {
    const rd = await getRedditFallback(url);
    if (rd) return rd;
  }

  // 7. Primary yt-dlp extractor for Twitter/X, and other platforms
  try {
    const { stdout } = await execFileAsync(
      'python3',
      [
        YTDLP_PATH,
        '--dump-single-json',
        '--no-warnings',
        '--no-playlist',
        '--no-check-certificates',
        '--prefer-free-formats',
        url,
      ],
      { maxBuffer: 15 * 1024 * 1024, timeout: 35000 }
    );

    const raw = JSON.parse(stdout);
    return parseYtDlpOutput(raw, url, platform, platformName);
  } catch (error: any) {
    console.warn('Extraction fallback notice:', error?.message || error);

    // Provide friendly specific error message
    const platStr = platform as string;
    if (platStr === 'reddit' || url.includes('reddit.com') || url.includes('redd.it')) {
      if (error?.message && error.message.includes('Subreddit page ka link')) {
        throw error;
      }
      throw new Error(
        'Reddit video fetch nahi ho saki. Barah-e-karam check karein ke post ka direct link paste kiya hai (e.g. reddit.com/r/.../comments/...)'
      );
    }
    if (platStr === 'pinterest' || url.includes('pinterest.com') || url.includes('pin.it')) {
      throw new Error(
        'Pinterest video ya image fetch nahi ho saki. Barah-e-karam check karein ke Pin public hai aur link sahi hai.'
      );
    }
    if (platStr === 'instagram') {
      throw new Error(
        'Instagram video fetch nahi ho saki. Barah-e-karam check karein ke post/reel public hai aur link sahi hai.'
      );
    }
    if (platStr === 'facebook') {
      throw new Error(
        'Facebook video fetch nahi ho saki. Barah-e-karam check karein ke video public hai (Friends-only nahi).'
      );
    }
    if (platStr === 'youtube') {
      throw new Error(
        'YouTube video fetch nahi ho saki. Barah-e-karam check karein ke video public hai aur link sahi hai.'
      );
    }

    throw new Error(
      error?.message?.includes('Private video')
        ? 'Yeh video private ya restricted hai.'
        : 'Video fetch nahi ho saki. Barah-e-karam check karein ke link public aur valid hai.'
    );
  }
}

/**
 * Main Video & Audio Download Streamer
 */
export function executeDownloadStream(
  url: string,
  formatId: string,
  onFileReady: (filePath: string, filename: string, cleanup: () => void) => void,
  onError: (err: any) => void
) {
  const isAudio = formatId.includes('audio');
  const tempId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const ext = isAudio ? (formatId.includes('m4a') ? 'm4a' : 'mp3') : 'mp4';
  const tempPath = path.join(os.tmpdir(), `${tempId}.${ext}`);

  const args: string[] = [
    YTDLP_PATH,
    '--no-warnings',
    '--no-playlist',
    '--no-check-certificates',
  ];

  const isFb = url.includes('facebook.com') || url.includes('fb.watch');
  const isIg = url.includes('instagram.com');
  const isPin = url.includes('pinterest.com') || url.includes('pin.it');
  const isReddit = url.includes('reddit.com') || url.includes('redd.it');

  // Handle platforms with direct CDN URLs (FB, Pinterest, Reddit)
  if (isFb || isPin || isReddit) {
    (async () => {
      try {
        let metaData: VideoInfoResponse | null = null;
        let referer = 'https://www.google.com/';

        if (isFb) {
          metaData = await getFacebookFallback(url);
          referer = 'https://www.facebook.com/';
        } else if (isPin) {
          metaData = await getPinterestFallback(url);
          referer = 'https://www.pinterest.com/';
        } else if (isReddit) {
          metaData = await getRedditFallback(url);
          referer = 'https://www.reddit.com/';
        }

        const targetFormat =
          metaData?.formats.find((f) => f.formatId === formatId) ||
          (isAudio
            ? metaData?.formats.find((f) => f.isAudioOnly)
            : metaData?.formats.find((f) => f.hasVideo || f.ext === 'png' || f.ext === 'jpg'));

        if (targetFormat?.directUrl) {
          const upstream = await fetch(targetFormat.directUrl, {
            headers: {
              'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              Referer: referer,
            },
          });

          if (upstream.ok && upstream.body) {
            const actualExt = targetFormat.ext || ext;
            const customTempPath = path.join(os.tmpdir(), `${tempId}.${actualExt}`);
            const fileStream = fs.createWriteStream(customTempPath);
            await pipeline(Readable.fromWeb(upstream.body as any), fileStream);

            if (fs.existsSync(customTempPath) && fs.statSync(customTempPath).size > 200) {
              const filename = `FADI_KING_${sanitizeFilename(url.replace(/https?:\/\//, ''))}_${formatId}.${actualExt}`;
              const cleanup = () => {
                try {
                  if (fs.existsSync(customTempPath)) fs.unlinkSync(customTempPath);
                } catch (e) {
                  console.error('Failed to cleanup temp file:', e);
                }
              };
              return onFileReady(customTempPath, filename, cleanup);
            }
          }
        }
      } catch (err) {
        console.warn('Direct stream fallback notice:', err);
      }

      runYtDlpSpawn();
    })();
    return;
  }

  function runYtDlpSpawn() {
    if (isAudio) {
      if (ext === 'mp3') {
        args.push('-x', '--audio-format', 'mp3', '--audio-quality', '0');
      } else {
        args.push('-f', 'bestaudio[ext=m4a]/bestaudio');
      }
    } else if (isFb) {
      if (formatId === 'fb_sd') {
        args.push('-f', 'sd/bestvideo[height<=480]+bestaudio/best', '--merge-output-format', 'mp4');
      } else {
        args.push('-f', 'hd/bestvideo+bestaudio/sd/best[ext=mp4]/best', '--merge-output-format', 'mp4');
      }
    } else if (isIg) {
      args.push('-f', 'best[ext=mp4]/best');
    } else {
      const match = formatId.match(/best_video_(\d+)/);
      const height = match ? parseInt(match[1], 10) : 1080;
      args.push(
        '-f',
        `bestvideo[height<=${height}][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=${height}]+bestaudio/best[height<=${height}]/best`,
        '--merge-output-format',
        'mp4'
      );
    }

    args.push('-o', tempPath, url);

    const proc = spawn('python3', args);

    proc.on('error', (err) => {
      onError(err);
    });

    proc.on('close', async (code) => {
      if (code !== 0) {
        if (!fs.existsSync(tempPath) || fs.statSync(tempPath).size < 1024) {
          return onError(new Error(`Process finished with code ${code}`));
        }
      }

      if (!fs.existsSync(tempPath)) {
        return onError(new Error('Downloaded media file not found'));
      }

      const filename = `FADI_KING_${sanitizeFilename(url.replace(/https?:\/\//, ''))}_${formatId}.${ext}`;
      const cleanup = () => {
        try {
          if (fs.existsSync(tempPath)) {
            fs.unlinkSync(tempPath);
          }
        } catch (e) {
          console.error('Failed to cleanup temp file:', e);
        }
      };

      onFileReady(tempPath, filename, cleanup);
    });
  }

  runYtDlpSpawn();
}
