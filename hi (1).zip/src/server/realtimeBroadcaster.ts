import { Response } from 'express';

// Server-Sent Events (SSE) Client Registry for instantaneous live updates
interface SseClient {
  id: string;
  res: Response;
}

const clients = new Map<string, SseClient>();

export function registerClient(id: string, res: Response) {
  clients.set(id, { id, res });
  broadcastPresence();
}

export function removeClient(id: string) {
  clients.delete(id);
  broadcastPresence();
}

export function broadcastEvent(event: string, data: any) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const [id, client] of clients.entries()) {
    try {
      client.res.write(payload);
    } catch (err) {
      clients.delete(id);
    }
  }
}

export function getOnlineCount(): number {
  return Math.max(1, clients.size);
}

function broadcastPresence() {
  broadcastEvent('presence:update', {
    onlineUsers: getOnlineCount(),
    timestamp: new Date().toISOString(),
  });
}
