import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface RegisteredMember {
  username: string;
  avatarUrl?: string;
  isLifetimeVip: boolean;
  vipEmail?: string;
  isBlocked: boolean;
  joinedAt: string;
  lastActiveAt: string;
  messageCount: number;
  deviceIds?: string[];
  lastIp?: string;
}

const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'usersRegistry.json');
const BLOCKED_FILE = path.join(DATA_DIR, 'blockedUsers.json');

// In-memory active presence tracker
const activePresence = new Map<string, { lastSeen: number; avatarUrl?: string; deviceId?: string; ip?: string }>();

function ensureStorage(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(USERS_FILE)) {
      const initial: RegisteredMember[] = [
        {
          username: '👑 FADI KING (Official)',
          isLifetimeVip: true,
          vipEmail: 'official@fadiking.com',
          isBlocked: false,
          joinedAt: new Date().toISOString(),
          lastActiveAt: new Date().toISOString(),
          messageCount: 1,
          deviceIds: ['admin_device_001'],
        },
      ];
      fs.writeFileSync(USERS_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    }
    if (!fs.existsSync(BLOCKED_FILE)) {
      fs.writeFileSync(BLOCKED_FILE, JSON.stringify([], null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Error ensuring user manager storage:', err);
  }
}

function readUsers(): RegisteredMember[] {
  ensureStorage();
  try {
    const raw = fs.readFileSync(USERS_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writeUsers(users: RegisteredMember[]): void {
  ensureStorage();
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving users registry:', err);
  }
}

function readBlocked(): string[] {
  ensureStorage();
  try {
    const raw = fs.readFileSync(BLOCKED_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writeBlocked(blocked: string[]): void {
  ensureStorage();
  try {
    fs.writeFileSync(BLOCKED_FILE, JSON.stringify(blocked, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving blocked list:', err);
  }
}

/**
 * Robust check: blocks by username, deviceId fingerprint, or IP
 * Completely prevents users from creating a new name to evade block!
 */
export function isUserBlocked(username?: string, deviceId?: string, ip?: string): boolean {
  const blocked = readBlocked().map((b) => b.trim().toLowerCase());
  if (username && blocked.includes(username.trim().toLowerCase())) return true;
  if (deviceId && blocked.includes(`device:${deviceId.trim().toLowerCase()}`)) return true;
  if (ip && blocked.includes(`ip:${ip.trim()}`)) return true;

  // Check if this device was ever linked to any blocked member
  if (deviceId) {
    const users = readUsers();
    const matchedBlocked = users.find(
      (u) =>
        u.isBlocked &&
        u.deviceIds &&
        u.deviceIds.some((d) => d.toLowerCase() === deviceId.trim().toLowerCase())
    );
    if (matchedBlocked) return true;
  }

  return false;
}

export function getBlockedUsernames(): string[] {
  const raw = readBlocked();
  return raw
    .filter((b) => !b.startsWith('device:') && !b.startsWith('ip:'))
    .map((b) => b.trim());
}

export function blockUser(username: string): boolean {
  if (!username) return false;
  const clean = username.trim();
  const blocked = readBlocked();

  if (!blocked.some((b) => b.toLowerCase() === clean.toLowerCase())) {
    blocked.push(clean);
  }

  // Also bind & block their device IDs and IP so they cannot rename themselves
  const users = readUsers();
  const user = users.find((u) => u.username.toLowerCase() === clean.toLowerCase());
  if (user) {
    user.isBlocked = true;
    if (user.deviceIds) {
      user.deviceIds.forEach((d) => {
        const key = `device:${d.toLowerCase()}`;
        if (!blocked.includes(key)) blocked.push(key);
      });
    }
    if (user.lastIp) {
      const key = `ip:${user.lastIp}`;
      if (!blocked.includes(key)) blocked.push(key);
    }
    writeUsers(users);
  }

  // Check active presence in-memory for their deviceId and IP
  const inMemory = activePresence.get(clean.toLowerCase());
  if (inMemory?.deviceId) {
    const key = `device:${inMemory.deviceId.toLowerCase()}`;
    if (!blocked.includes(key)) blocked.push(key);
  }
  if (inMemory?.ip) {
    const key = `ip:${inMemory.ip}`;
    if (!blocked.includes(key)) blocked.push(key);
  }

  writeBlocked(blocked);
  return true;
}

export function unblockUser(username: string): boolean {
  if (!username) return false;
  const clean = username.trim().toLowerCase();
  let blocked = readBlocked();

  // Find user to gather all deviceIds and lastIp to remove
  const users = readUsers();
  const matchingUsers = users.filter((u) => u.username.toLowerCase() === clean);
  const deviceKeysToRemove = new Set<string>();
  const ipKeysToRemove = new Set<string>();

  matchingUsers.forEach((u) => {
    u.isBlocked = false;
    if (u.deviceIds) {
      u.deviceIds.forEach((d) => deviceKeysToRemove.add(`device:${d.toLowerCase()}`));
    }
    if (u.lastIp) {
      ipKeysToRemove.add(`ip:${u.lastIp.toLowerCase()}`);
    }
  });

  // Also check activePresence
  const inMemory = activePresence.get(clean);
  if (inMemory?.deviceId) {
    deviceKeysToRemove.add(`device:${inMemory.deviceId.toLowerCase()}`);
  }
  if (inMemory?.ip) {
    ipKeysToRemove.add(`ip:${inMemory.ip.toLowerCase()}`);
  }

  // Filter out the username, all associated device keys, and all associated IP keys
  blocked = blocked.filter((b) => {
    const bLower = b.toLowerCase();
    if (bLower === clean) return false;
    if (deviceKeysToRemove.has(bLower)) return false;
    if (ipKeysToRemove.has(bLower)) return false;
    return true;
  });

  writeBlocked(blocked);
  writeUsers(users);
  return true;
}

export function recordUserPresence(
  username: string,
  avatarUrl?: string,
  isVip?: boolean,
  vipEmail?: string,
  deviceId?: string,
  ip?: string
) {
  if (!username) return;
  const clean = username.trim();

  activePresence.set(clean.toLowerCase(), {
    lastSeen: Date.now(),
    avatarUrl,
    deviceId,
    ip,
  });

  const users = readUsers();
  let member = users.find((u) => u.username.toLowerCase() === clean.toLowerCase());
  if (!member) {
    member = {
      username: clean,
      avatarUrl,
      isLifetimeVip: isVip || false,
      vipEmail,
      isBlocked: isUserBlocked(clean, deviceId, ip),
      joinedAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      messageCount: 0,
      deviceIds: deviceId ? [deviceId] : [],
      lastIp: ip,
    };
    users.push(member);
  } else {
    member.lastActiveAt = new Date().toISOString();
    if (avatarUrl) member.avatarUrl = avatarUrl;
    if (isVip !== undefined) member.isLifetimeVip = isVip;
    if (vipEmail) member.vipEmail = vipEmail;
    if (deviceId) {
      member.deviceIds = Array.from(new Set([...(member.deviceIds || []), deviceId]));
    }
    if (ip) member.lastIp = ip;
    member.isBlocked = isUserBlocked(clean, deviceId, ip);
  }
  writeUsers(users);
}

export function incrementUserMessageCount(username: string) {
  if (!username) return;
  const clean = username.trim();
  const users = readUsers();
  const member = users.find((u) => u.username.toLowerCase() === clean.toLowerCase());
  if (member) {
    member.messageCount = (member.messageCount || 0) + 1;
    member.lastActiveAt = new Date().toISOString();
    writeUsers(users);
  }
}

export function getAllMembers(): RegisteredMember[] {
  const users = readUsers();
  return users.map((u) => ({
    ...u,
    isBlocked: isUserBlocked(u.username, u.deviceIds?.[0], u.lastIp),
  }));
}

export function getActiveChatUsers(): { username: string; avatarUrl?: string }[] {
  const now = Date.now();
  const cutoff = now - 5 * 60 * 1000; // seen within last 5 minutes

  const active: { username: string; avatarUrl?: string }[] = [];
  for (const [key, val] of activePresence.entries()) {
    if (val.lastSeen >= cutoff) {
      active.push({
        username: key,
        avatarUrl: val.avatarUrl,
      });
    }
  }

  if (active.length === 0) {
    active.push({ username: 'FADI KING (Official)' });
  }

  return active;
}
