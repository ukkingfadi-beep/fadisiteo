import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { UrlInput } from './components/UrlInput';
import { VideoResultCard } from './components/VideoResultCard';
import { BatchDownloader } from './components/BatchDownloader';
import { AudioStudio } from './components/AudioStudio';
import { SpecialMediaVisualizer } from './components/SpecialMediaVisualizer';
import { LiveChatBoard } from './components/LiveChatBoard';
import { SupportedPlatforms } from './components/SupportedPlatforms';
import { DownloadHistory } from './components/DownloadHistory';
import { HowItWorks } from './components/HowItWorks';
import { FaqSection } from './components/FaqSection';
import { LiquidWaveLoader } from './components/LiquidWaveLoader';
import { WhatsAppJoinModal } from './components/WhatsAppJoinModal';
import { UpgradePlanModal } from './components/UpgradePlanModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { FloatingMusicWidget } from './components/FloatingMusicWidget';
import { LiveScreenDisplay } from './components/LiveScreenDisplay';
import { AnimatedThemeCanvas } from './components/AnimatedThemeCanvas';
import { NotificationBellModal, BroadcastAlert } from './components/NotificationBellModal';
import { VoiceGuideOverlay } from './components/VoiceGuideOverlay';
import { speakFeature } from './utils/voiceGuide';
import {
  getLocalConfig,
  fetchServerConfig,
  SiteConfigState,
  saveLocalConfig,
  syncCustomAssetsToServer,
  THEME_PRESETS,
  ThemePreset,
  DEFAULT_SHOWCASE_SLIDES,
} from './utils/themeAndConfigManager';
import type {
  VideoInfoResponse,
  VideoFormatOption,
  DownloadHistoryItem,
} from './types/downloader';
import type { Language } from './utils/translations';
import { translations, WHATSAPP_CHANNEL_LINK } from './utils/translations';
import {
  Crown,
  Sparkles,
  Zap,
  MessageCircle,
  Bot,
  ShieldCheck,
  CheckCircle2,
  Server,
  Layers,
  ArrowRight,
  Music2,
  AlertTriangle,
  Flame,
  ArrowDownToLine,
  Rocket,
  Film,
  Play,
  Package,
  ListOrdered,
  LayoutGrid,
  Copy,
  Headphones,
  Mic,
  Disc,
  Radio,
  Gem,
  Trophy,
  Star,
} from 'lucide-react';
import {
  playClickSound,
  playSuccessChime,
  playBellTungTungSound,
  playAlertTune,
  getSoundEnabled,
  setSoundEnabled,
} from './utils/sound';
import {
  getQuotaState,
  MAX_FREE_DOWNLOADS,
  UPGRADE_PRICE_PKR,
  QuotaState,
} from './utils/quotaManager';

const STORAGE_KEY = 'fadiking_download_history';
const CHANNEL_STORAGE_KEY = 'fadiking_whatsapp_unlocked';

export function App() {
  const [lang, setLang] = useState<Language>('en');
  const [activeMode, setActiveMode] = useState<'single' | 'batch' | 'studio'>('single');
  const [activeNode, setActiveNode] = useState<'sg' | 'de' | 'jp'>('sg');
  const [currentUrl, setCurrentUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [videoInfo, setVideoInfo] = useState<VideoInfoResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [history, setHistory] = useState<DownloadHistoryItem[]>([]);
  const [soundEnabled, setSoundState] = useState<boolean>(true);
  const [showInitialLoader, setShowInitialLoader] = useState<boolean>(true);

  // VIP Access Gate (Channel gate removed per user brief)
  const [hasUnlockedGate, setHasUnlockedGate] = useState<boolean>(true);
  const [showGateModal, setShowGateModal] = useState<boolean>(false);
  const [showWhatsappModal, setShowWhatsappModal] = useState<boolean>(false);
  const [pendingFormat, setPendingFormat] = useState<VideoFormatOption | null>(null);

  // Live Community Chat Board
  const [showChatBoard, setShowChatBoard] = useState<boolean>(false);

  // Master Theme, Layout, and Feature Configurations
  const [siteConfig, setSiteConfig] = useState<SiteConfigState>(() => {
    const cfg = getLocalConfig();
    return {
      ...cfg,
      theme: {
        ...THEME_PRESETS.obsidian_gold,
        ...(cfg?.theme || {}),
      },
    };
  });
  const [onlineUsers, setOnlineUsers] = useState<number>(6);

  // Real-time Broadcast Alerts & Bell Notification States
  const [alerts, setAlerts] = useState<BroadcastAlert[]>([]);
  const [showAlertModal, setShowAlertModal] = useState<boolean>(false);
  const [unreadAlertCount, setUnreadAlertCount] = useState<number>(0);
  const [isBellRinging, setIsBellRinging] = useState<boolean>(false);

  // Lifetime Upgrade Plan & Quota States
  const [showUpgradeModal, setShowUpgradeModal] = useState<boolean>(false);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [isLimitReached, setIsLimitReached] = useState<boolean>(false);
  const [quota, setQuota] = useState<QuotaState>({
    remaining: MAX_FREE_DOWNLOADS,
    total: MAX_FREE_DOWNLOADS,
    isLifetime: false,
  });

  const t = translations[lang];

  // The server config is the authoritative master state.
  // Server values take precedence and synchronize local storage.
  const mergeSafeConfig = (incoming: any, prev: SiteConfigState): SiteConfigState => {
    if (!incoming) return prev;
    const effectiveBgUrl = incoming.theme?.bgMediaUrl !== undefined ? incoming.theme.bgMediaUrl : (prev.theme?.bgMediaUrl || '');
    const effectiveBgType = incoming.theme?.bgType || (effectiveBgUrl ? 'video' : 'color');
    const effectiveSlides =
      Array.isArray(incoming.features?.liveScreenNotice?.slides) && incoming.features.liveScreenNotice.slides.length > 0
        ? incoming.features.liveScreenNotice.slides
        : (prev.features?.liveScreenNotice?.slides || DEFAULT_SHOWCASE_SLIDES);

    const merged: SiteConfigState = {
      ...prev,
      ...incoming,
      theme: {
        ...prev.theme,
        ...(incoming.theme || {}),
        bgMediaUrl: effectiveBgUrl,
        bgType: effectiveBgType,
        bgOverlayOpacity: incoming.theme?.bgOverlayOpacity ?? prev.theme?.bgOverlayOpacity ?? 0.40,
      },
      features: {
        ...prev.features,
        ...(incoming.features || {}),
        requireGateFollow: false,
        liveScreenNotice: {
          ...prev.features.liveScreenNotice,
          ...(incoming.features?.liveScreenNotice || {}),
          slides: effectiveSlides,
        },
      },
    };

    if (typeof window !== 'undefined') {
      try {
        if (effectiveBgUrl) {
          localStorage.setItem('fadiking_bg_media_url', effectiveBgUrl);
          localStorage.setItem('fadiking_bg_type', effectiveBgType);
        } else {
          localStorage.removeItem('fadiking_bg_media_url');
          localStorage.removeItem('fadiking_bg_type');
        }
        localStorage.setItem('fadiking_saved_slides', JSON.stringify(effectiveSlides));
        localStorage.setItem('fadiking_site_config_v2', JSON.stringify(merged));
      } catch {}
    }

    return merged;
  };

  // Initial load of broadcast alerts & server config (Bypasses all cache)
  useEffect(() => {
    fetchServerConfig()
      .then((cfg) => {
        if (cfg) {
          setSiteConfig((prev) => mergeSafeConfig(cfg, prev));
        }
      })
      .catch(() => {});

    fetch(`/api/alerts?_t=${Date.now()}`, {
      cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache' }
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.alerts && Array.isArray(data.alerts)) {
          setAlerts(data.alerts);
          try {
            const readIdsRaw = localStorage.getItem('fadiking_read_alert_ids');
            const readIds: string[] = readIdsRaw ? JSON.parse(readIdsRaw) : [];
            const unread = data.alerts.filter((a: BroadcastAlert) => !readIds.includes(a.id)).length;
            setUnreadAlertCount(unread);
          } catch {}
        }
      })
      .catch(() => {});
  }, []);

  // Real-time synchronization via Server-Sent Events (SSE)
  useEffect(() => {
    let es: EventSource | null = null;
    try {
      es = new EventSource('/api/events');

      es.addEventListener('init', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          if (data.config) {
            setSiteConfig((prev) => mergeSafeConfig(data.config, prev));
          }
          if (data.onlineUsers) setOnlineUsers(data.onlineUsers);
          if (data.recentAlerts && Array.isArray(data.recentAlerts)) {
            setAlerts(data.recentAlerts);
            try {
              const readIdsRaw = localStorage.getItem('fadiking_read_alert_ids');
              const readIds: string[] = readIdsRaw ? JSON.parse(readIdsRaw) : [];
              const unread = data.recentAlerts.filter((a: BroadcastAlert) => !readIds.includes(a.id)).length;
              setUnreadAlertCount(unread);
            } catch {}
          }
        } catch {}
      });

      es.addEventListener('config:update', (e: MessageEvent) => {
        try {
          const updated = JSON.parse(e.data);
          if (updated) {
            setSiteConfig((prev) => mergeSafeConfig(updated, prev));
          }
        } catch {}
      });

      es.addEventListener('cache:purge', (e: MessageEvent) => {
        try {
          if (typeof window !== 'undefined') {
            localStorage.removeItem('fadiking_bg_media_url');
            localStorage.removeItem('fadiking_bg_type');
            localStorage.removeItem('fadiking_saved_slides');
            localStorage.removeItem('fadiking_site_config_v2');
          }
          fetchServerConfig().then((cfg) => {
            if (cfg) {
              setSiteConfig((prev) => mergeSafeConfig(cfg, prev));
            }
          });
        } catch {}
      });

      es.addEventListener('stats:online', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          if (data.online) setOnlineUsers(data.online);
        } catch {}
      });

      es.addEventListener('alert:broadcast', (e: MessageEvent) => {
        try {
          const newAlert: BroadcastAlert = JSON.parse(e.data);
          if (newAlert) {
            setAlerts((prev) => [newAlert, ...prev]);
            setUnreadAlertCount((prev) => prev + 1);
            setIsBellRinging(true);
            playBellTungTungSound();
            playAlertTune((newAlert as any).sound || 'bell');
            if (newAlert.popup) {
              setShowAlertModal(true);
            }
            setTimeout(() => setIsBellRinging(false), 6000);
          }
        } catch {}
      });

      es.addEventListener('alert:delete', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          if (data.alertId) {
            setAlerts((prev) => prev.filter((a) => a.id !== data.alertId));
          }
        } catch {}
      });

      es.addEventListener('alert:clear', () => {
        setAlerts([]);
        setUnreadAlertCount(0);
      });
    } catch (err) {
      console.warn('SSE live sync connection error:', err);
    }

    const handleBeforeUnload = () => {
      try {
        if (navigator.sendBeacon) {
          navigator.sendBeacon('/api/leave');
        }
      } catch {}
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      if (es) es.close();
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  // Load history, sound, channel unlock status, and quota
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem(STORAGE_KEY);
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
      const savedChannel = localStorage.getItem(CHANNEL_STORAGE_KEY);
      if (savedChannel === 'true') {
        setHasUnlockedGate(true);
      }
      setSoundState(getSoundEnabled());
    } catch (e) {
      console.warn('Failed to load storage data:', e);
    }

    const syncQuota = () => {
      setQuota(getQuotaState());
    };
    syncQuota();
    window.addEventListener('fadiking-quota-updated', syncQuota);
    return () => window.removeEventListener('fadiking-quota-updated', syncQuota);
  }, []);

  const handleGateUnlocked = () => {
    setHasUnlockedGate(true);
    setShowGateModal(false);
    try {
      localStorage.setItem(CHANNEL_STORAGE_KEY, 'true');
    } catch {}
  };

  const saveHistory = (newHistory: DownloadHistoryItem[]) => {
    setHistory(newHistory);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newHistory.slice(0, 20)));
    } catch (e) {
      console.warn('Failed to save history:', e);
    }
  };

  const handleClearHistory = () => {
    saveHistory([]);
  };

  const handleAnalyze = async (urlToFetch: string) => {
    if (!urlToFetch || !urlToFetch.trim().startsWith('http')) {
      setErrorMessage(t.errorInvalidUrl);
      return;
    }

    const lower = urlToFetch.toLowerCase();
    const adultKeywords = [
      'pornhub', 'xvideos', 'xnxx', 'redtube', 'youporn', 'xhamster',
      'chaturbate', 'onlyfans', 'erome', 'spankbang', 'hentai', 'rule34',
      'brazzers', 'eporner', 'beeg', 'tnaflix', 'tube8', 'cam4', 'bongacams',
      'porn', 'xxx', 'nsfw', 'javhd', 'manyvids'
    ];
    if (adultKeywords.some((kw) => lower.includes(kw))) {
      setErrorMessage('⚠️ FADI KING VIP par 18+ / adult content strictly prohibited hai. Baraye meharbani family-friendly video link enter karein.');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setCurrentUrl(urlToFetch);

    try {
      const response = await fetch('/api/info', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: urlToFetch.trim() }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || t.errorFetchFailed);
      }

      const data: VideoInfoResponse = await response.json();
      setVideoInfo(data);
      playSuccessChime();
    } catch (err: any) {
      console.warn('Fetch notice:', err?.message || err);
      setErrorMessage(err.message || t.errorFetchFailed);
      setVideoInfo(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadStarted = (info: VideoInfoResponse, format: VideoFormatOption) => {
    const newItem: DownloadHistoryItem = {
      id: `${info.id}_${Date.now()}`,
      title: info.title,
      platform: info.platform,
      thumbnailUrl: info.thumbnailUrl,
      downloadedAt: Date.now(),
      url: info.originalUrl,
      quality: format.qualityLabel,
      type: format.isAudioOnly ? 'audio' : 'video',
    };

    const updated = [newItem, ...history.filter((h) => h.url !== info.originalUrl)].slice(0, 15);
    saveHistory(updated);
  };

  const handleRequireWhatsappJoin = (format: VideoFormatOption) => {
    // Channel requirement removed per user request: Direct instant VIP download!
    if (videoInfo) {
      const cleanTitle = (videoInfo.title || 'video').replace(/[^a-zA-Z0-9_\-\. ]/g, '').trim().substring(0, 50);
      const filename = `FADI_KING_${cleanTitle}_${format.qualityLabel.replace(/[\s\/\\]+/g, '_')}.${format.ext}`;

      let downloadLink = '';
      if (format.directUrl) {
        downloadLink = `/api/proxy-stream?url=${encodeURIComponent(format.directUrl)}&filename=${encodeURIComponent(filename)}`;
      } else {
        downloadLink = `/api/download?url=${encodeURIComponent(videoInfo.originalUrl)}&formatId=${encodeURIComponent(format.formatId)}`;
      }

      const a = document.createElement('a');
      a.href = downloadLink;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try {
          document.body.removeChild(a);
        } catch {}
      }, 2000);

      handleDownloadStarted(videoInfo, format);
      playSuccessChime();
    }
  };

  const handleWhatsappVerified = () => {
    setHasUnlockedGate(true);
    localStorage.setItem(CHANNEL_STORAGE_KEY, 'true');
    setShowWhatsappModal(false);

    if (pendingFormat && videoInfo) {
      setTimeout(() => {
        const format = pendingFormat;
        const cleanTitle = (videoInfo.title || 'video').replace(/[^a-zA-Z0-9_\-\. ]/g, '').trim().substring(0, 50);
        const filename = `FADI_KING_${cleanTitle}_${format.qualityLabel.replace(/[\s\/\\]+/g, '_')}.${format.ext}`;

        let downloadLink = '';
        if (format.directUrl) {
          downloadLink = `/api/proxy-stream?url=${encodeURIComponent(format.directUrl)}&filename=${encodeURIComponent(filename)}`;
        } else {
          downloadLink = `/api/download?url=${encodeURIComponent(videoInfo.originalUrl)}&formatId=${encodeURIComponent(format.formatId)}`;
        }

        const a = document.createElement('a');
        a.href = downloadLink;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => document.body.removeChild(a), 2000);

        handleDownloadStarted(videoInfo, format);
      }, 400);
    }
  };

  const handleReDownload = (item: DownloadHistoryItem) => {
    setCurrentUrl(item.url);
    handleAnalyze(item.url);
    window.scrollTo({ top: 160, behavior: 'smooth' });
  };

  const handleRequireUpgrade = () => {
    setIsLimitReached(true);
    setShowUpgradeModal(true);
    playClickSound();
  };



  return (
    <div className="min-h-screen flex flex-col relative overflow-x-clip transition-colors duration-500 selection:bg-white selection:text-slate-950 text-slate-100">
      {/* Liquid Wave Circle Loader with FADI KING branding (Matching Reference Video) */}
      {showInitialLoader && (
        <LiquidWaveLoader
          brandName="FADI KING"
          onComplete={() => setShowInitialLoader(false)}
        />
      )}

      {/* Dynamic Animated Theme Canvas & Luxury Bronze Particles */}
      <AnimatedThemeCanvas theme={siteConfig.theme} />

      {/* Top Futuristic Live Showcase Screen (Photo/Video Carousel with BUY NOW button) */}
      <LiveScreenDisplay
        notice={siteConfig.features.liveScreenNotice}
        onlineCount={onlineUsers}
        onOpenUpgradeModal={() => {
          setIsLimitReached(false);
          setShowUpgradeModal(true);
        }}
        whatsappUrl={siteConfig.features.whatsappChannelUrl}
        whatsappPhone={siteConfig.features.whatsappOrdersPhone || '923000000000'}
      />

      {/* Royal Espresso Brown & Metallic Gold Header */}
      <Header
        lang={lang}
        onLanguageChange={setLang}
        onNavigateSection={(sectionId) => {
          const el = document.getElementById(sectionId);
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        activeMode={activeMode}
        onModeChange={setActiveMode}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          const next = !soundEnabled;
          setSoundState(next);
          setSoundEnabled(next);
        }}
        onOpenGateModal={() => setShowGateModal(true)}
        onOpenUpgrade={() => {
          setIsLimitReached(false);
          setShowUpgradeModal(true);
        }}
        onOpenAdmin={() => setShowAdminModal(true)}
        onOpenChat={() => setShowChatBoard(true)}
        onlineCount={onlineUsers}
        quotaRemaining={quota.remaining}
        isLifetime={quota.isLifetime}
        isWhiteGlass={siteConfig.theme.preset === 'crystal_white_glass'}
        onToggleGlassTheme={() => {
          const newTheme: ThemePreset =
            siteConfig.theme.preset === 'crystal_white_glass' ? 'obsidian_gold' : 'crystal_white_glass';
          const updated = {
            ...siteConfig,
            theme: { ...THEME_PRESETS[newTheme], preset: newTheme },
          };
          setSiteConfig(updated);
          saveLocalConfig(updated);
        }}
        unreadAlertCount={unreadAlertCount}
        isBellRinging={isBellRinging}
        onOpenAlerts={() => setShowAlertModal(true)}
        itemIcons={siteConfig.itemIcons}
      />

      {/* Main Content Area - Compact & Viewport-Optimized for High Visibility */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 pt-1.5 pb-20 relative z-10 flex flex-col items-center">
        {/* VIP Quota & Lifetime Status Strip in Frosted Acrylic Glass */}
        <div className="w-full max-w-4xl mb-3">
          <div className="bg-neutral-900/60 backdrop-blur-2xl border border-white/10 rounded-2xl p-2.5 sm:p-3 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-2.5">
            <div 
              onClick={() => {
                speakFeature(
                  'VIP Status & Quota',
                  quota.isLifetime
                    ? 'Mera kaam aapko VIP lifetime unlimited downloads dena hai.'
                    : `Mera kaam aapki free downloads limit track karna hai. Aapke paas ${quota.remaining} free downloads baqi hain.`
                );
              }}
              className="flex items-center gap-2.5 cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-white text-slate-950 flex items-center justify-center font-black shadow-md shrink-0">
                {siteConfig.itemIcons?.vipBadgeIcon === 'gem' ? (
                  <Gem className="w-4 h-4" />
                ) : siteConfig.itemIcons?.vipBadgeIcon === 'award' ? (
                  <Trophy className="w-4 h-4" />
                ) : siteConfig.itemIcons?.vipBadgeIcon === 'shield' ? (
                  <ShieldCheck className="w-4 h-4" />
                ) : (
                  <Crown className="w-4 h-4" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xs sm:text-sm text-white tracking-wide">
                    {quota.isLifetime ? '👑 VIP LIFETIME UNLIMITED' : '👑 FREE VIP TIER'}
                  </span>
                  <span className="px-1.5 py-0.5 text-[9px] font-black rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    8K READY
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {quota.isLifetime
                    ? 'Unlimited High-Speed 8K & 4K Downloads Active'
                    : `${quota.remaining} of ${quota.total} Free High-Speed Downloads Left`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              {!quota.isLifetime ? (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    speakFeature(
                      'Lifetime Upgrade Button',
                      `Mera kaam lifetime VIP upgrade unlock karna hai. Sirf Rs. ${UPGRADE_PRICE_PKR} mein unlimited 8K access milta hai.`
                    );
                    setIsLimitReached(false);
                    setShowUpgradeModal(true);
                  }}
                  className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Sparkles className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
                  <span>UPGRADE (Rs. {UPGRADE_PRICE_PKR})</span>
                </button>
              ) : (
                <div className="px-3 py-1 rounded-xl bg-white/10 border border-white/20 text-white font-extrabold text-xs flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 fill-white text-white" />
                  <span>VIP MEMBER</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Hero Section - Compact Viewport Architecture */}
        <section className="text-center w-full max-w-4xl mt-1 mb-3.5 px-2">
          <div 
            onClick={() => {
              speakFeature(
                'Media Engine Badge',
                'Mera kaam Royal 8K Ultra High Definition media extraction engine chalana hai.'
              );
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-white text-[11px] font-bold shadow-sm mb-2 cursor-pointer hover:border-white/30"
          >
            <Crown className="w-3.5 h-3.5 text-white" />
            <span className="tracking-wide">FADI KING VIP · 8K MEDIA ENGINE</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white mb-1.5 leading-tight">
            Download Any Video & Audio in{' '}
            <span className="bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent drop-shadow-md">
              8K Ultra HD
            </span>
          </h1>

          <p className="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto mb-3 leading-relaxed">
            Fastest multi-platform media engine for TikTok, YouTube, Instagram Reels, Facebook & Twitter. Zero watermark & studio 320kbps MP3 audio extraction.
          </p>

          {/* Mode Tabs with Dynamic Item Icons & Voice Guide (Matching Image 2 Category Pills) */}
          <div className="inline-flex p-1 rounded-full bg-neutral-900/65 border border-white/15 backdrop-blur-3xl shadow-lg gap-1">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                speakFeature(
                  'Direct Downloader Tab',
                  'Mera kaam kisi bhi single video ka link lekar usko 8K Ultra HD mein download karna hai.'
                );
                setActiveMode('single');
              }}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeMode === 'single'
                  ? 'bg-white text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {siteConfig.itemIcons?.directDownloaderIcon === 'download' ? (
                <ArrowDownToLine className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.directDownloaderIcon === 'rocket' ? (
                <Rocket className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.directDownloaderIcon === 'film' ? (
                <Film className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.directDownloaderIcon === 'sparkles' ? (
                <Sparkles className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.directDownloaderIcon === 'play' ? (
                <Play className="w-3.5 h-3.5" />
              ) : (
                <Zap className="w-3.5 h-3.5" />
              )}
              <span>Direct Downloader</span>
            </button>

            <button
              type="button"
              onClick={() => {
                playClickSound();
                speakFeature(
                  'Batch URLs Tab',
                  'Mera kaam ek sath 10 videos ke link queue mein download karna hai.'
                );
                setActiveMode('batch');
              }}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeMode === 'batch'
                  ? 'bg-white text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {siteConfig.itemIcons?.batchDownloaderIcon === 'package' ? (
                <Package className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.batchDownloaderIcon === 'list' ? (
                <ListOrdered className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.batchDownloaderIcon === 'grid' ? (
                <LayoutGrid className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.batchDownloaderIcon === 'copy' ? (
                <Copy className="w-3.5 h-3.5" />
              ) : (
                <Layers className="w-3.5 h-3.5" />
              )}
              <span>Batch URLs</span>
            </button>

            <button
              type="button"
              onClick={() => {
                playClickSound();
                speakFeature(
                  'Audio & MP3 Studio Tab',
                  'Mera kaam kisi bhi video mein se crystal-clear 320kbps MP3 sound extract karna hai.'
                );
                setActiveMode('studio');
              }}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeMode === 'studio'
                  ? 'bg-white text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {siteConfig.itemIcons?.audioStudioIcon === 'headphones' ? (
                <Headphones className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.audioStudioIcon === 'mic' ? (
                <Mic className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.audioStudioIcon === 'disc' ? (
                <Disc className="w-3.5 h-3.5" />
              ) : siteConfig.itemIcons?.audioStudioIcon === 'radio' ? (
                <Radio className="w-3.5 h-3.5" />
              ) : (
                <Music2 className="w-3.5 h-3.5" />
              )}
              <span>Audio & MP3 Studio</span>
            </button>
          </div>
        </section>

        {/* 1. Downloader Suite (Single Link, Batch, or Audio Studio) */}
        {activeMode === 'single' && (
          <div className="w-full max-w-4xl flex flex-col items-center">
            <UrlInput
              lang={lang}
              onAnalyze={handleAnalyze}
              isLoading={isLoading}
              initialUrl={currentUrl}
              activeMode={activeMode}
              onModeChange={setActiveMode}
              activeNode={activeNode}
              onNodeChange={setActiveNode}
            />

            {/* Error Message */}
            {errorMessage && (
              <div className="w-full mt-4 p-4 rounded-2xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-sm flex items-center justify-between gap-3 shadow-lg backdrop-blur-md animate-in fade-in">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setErrorMessage(null)}
                  className="text-xs font-bold text-rose-300 hover:text-white px-2 py-1 rounded bg-rose-900/40 cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            )}

            {/* Video Result Card */}
            {videoInfo && (
              <div className="w-full mt-6">
                <VideoResultCard
                  info={videoInfo}
                  lang={lang}
                  onDownloadStarted={handleDownloadStarted}
                  hasJoinedWhatsapp={hasUnlockedGate}
                  onRequireWhatsappJoin={handleRequireWhatsappJoin}
                  onOpenStudio={() => setActiveMode('studio')}
                  onRequireUpgrade={handleRequireUpgrade}
                />
              </div>
            )}
          </div>
        )}

        {activeMode === 'batch' && (
          <div className="w-full max-w-4xl">
            <BatchDownloader
              lang={lang}
              onDownloadStarted={handleDownloadStarted}
              hasJoinedWhatsapp={hasUnlockedGate}
              onRequireWhatsappJoin={handleRequireWhatsappJoin}
              onRequireUpgrade={handleRequireUpgrade}
            />
          </div>
        )}

        {activeMode === 'studio' && (
          <div className="w-full max-w-4xl">
            <AudioStudio
              lang={lang}
              videoInfo={videoInfo}
              onDownloadStarted={handleDownloadStarted}
              hasJoinedWhatsapp={hasUnlockedGate}
              onRequireWhatsappJoin={handleRequireWhatsappJoin}
              onRequireUpgrade={handleRequireUpgrade}
            />
          </div>
        )}

        {/* 2. Special VIP Animation & Stream Visualizer Directly Below Downloader */}
        <SpecialMediaVisualizer
          isAnalyzing={isLoading}
          hasVideoInfo={!!videoInfo}
          videoTitle={videoInfo?.title}
          platform={videoInfo?.platform}
        />

        {/* Supported Platforms */}
        <SupportedPlatforms
          lang={lang}
          onSelectPlatform={(sampleUrl) => {
            playClickSound();
            setCurrentUrl(sampleUrl);
            setActiveMode('single');
            handleAnalyze(sampleUrl);
            window.scrollTo({ top: 160, behavior: 'smooth' });
          }}
        />

        {/* 6. Download History */}
        <DownloadHistory
          history={history}
          lang={lang}
          onClearHistory={handleClearHistory}
          onReDownload={handleReDownload}
        />

        {/* 7. How It Works */}
        <HowItWorks lang={lang} />

        {/* 8. FAQ Section */}
        <FaqSection lang={lang} />
      </main>

      {/* Floating Compact VIP Chatbot Trigger Button with Visible 'Live Chat' Header Badge */}
      <div className="fixed bottom-5 right-4 sm:right-6 z-40">
        <button
          type="button"
          onClick={() => {
            playClickSound();
            setShowChatBoard(true);
          }}
          className="relative group flex flex-col items-center cursor-pointer focus:outline-none transition-all duration-300 hover:scale-105 active:scale-95"
          title="FADI KING VIP Live Chat"
          aria-label="Open VIP Live Chat"
        >
          {/* Top Tag: "LIVE CHAT" positioned directly above the icon */}
          <div className="mb-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 text-slate-950 text-[9px] font-black uppercase tracking-wider shadow-lg shadow-amber-500/25 flex items-center gap-1 border border-white/40 ring-1 ring-amber-600/30 select-none">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 animate-pulse inline-block" />
            <span className="leading-none drop-shadow-xs">Live Chat</span>
          </div>

          {/* Main Button Body: Luxury Compact 48px Glassmorphic Obsidian Gold */}
          <div className="relative">
            {/* Outer Pulsing Golden Aura */}
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-amber-500/40 via-yellow-400/30 to-amber-600/40 blur-sm group-hover:blur-md transition-all duration-300 animate-pulse" />

            <div className="relative w-12 h-12 rounded-full bg-gradient-to-b from-[#1f150c] via-[#120a04] to-[#070402] border border-amber-400/60 group-hover:border-amber-300 shadow-xl shadow-amber-950/80 flex items-center justify-center overflow-hidden">
              {/* Subtle Metallic Shimmer Reflection */}
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-400/15 via-transparent to-yellow-200/20 pointer-events-none" />

              {/* VIP Crown + Bot Graphic Composition */}
              <div className="relative flex flex-col items-center justify-center -space-y-0.5">
                <Crown className="w-3.5 h-3.5 text-amber-300 fill-amber-400/30 drop-shadow-[0_1px_2px_rgba(251,191,36,0.5)] transition-transform group-hover:-translate-y-0.5" />
                <Bot className="w-4 h-4 text-amber-100 group-hover:text-white transition-colors" />
              </div>

              {/* Glowing Active Online Status Dot */}
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 ring-1 ring-black" />
              </span>

              {/* Micro VIP Gold Ribbon Pill at bottom */}
              <span className="absolute bottom-0 inset-x-0 bg-gradient-to-r from-amber-600 via-amber-400 to-amber-600 text-[7px] font-black uppercase text-slate-950 tracking-tighter text-center py-[1px] leading-none shadow-sm">
                VIP
              </span>
            </div>
          </div>
        </button>
      </div>

      {/* Full Modal Live Chat Board (When launched from header or notification) */}
      {showChatBoard && (
        <LiveChatBoard
          key="modal-chat"
          isOpen={true}
          onClose={() => setShowChatBoard(false)}
          isEmbedded={false}
          onlineCount={onlineUsers}
          isLifetimeVip={quota.isLifetime}
          securityConfig={siteConfig.chatSecurity}
        />
      )}

      {/* WhatsApp Verification Modal */}
      <WhatsAppJoinModal
        isOpen={showWhatsappModal}
        onClose={() => setShowWhatsappModal(false)}
        onVerified={handleWhatsappVerified}
        lang={lang}
        targetVideoTitle={videoInfo?.title}
      />

      {/* Lifetime Upgrade Plan Modal */}
      <UpgradePlanModal
        isOpen={showUpgradeModal}
        onClose={() => {
          setShowUpgradeModal(false);
          setIsLimitReached(false);
        }}
        lang={lang}
        onOpenAdmin={() => setShowAdminModal(true)}
        isLimitReached={isLimitReached}
      />

      {/* Admin Panel Modal (Master Control Center) */}
      {showAdminModal && (
        <AdminPanelModal
          isOpen={showAdminModal}
          onClose={() => setShowAdminModal(false)}
          lang={lang}
          currentConfig={siteConfig}
          onConfigUpdated={(cfg) => setSiteConfig(cfg)}
        />
      )}

      {/* Official Announcements & Alert Notification Bell Modal */}
      <NotificationBellModal
        isOpen={showAlertModal}
        onClose={() => setShowAlertModal(false)}
        alerts={alerts}
        onMarkAllRead={() => {
          setUnreadAlertCount(0);
          setIsBellRinging(false);
          try {
            const allIds = alerts.map((a) => a.id);
            localStorage.setItem('fadiking_read_alert_ids', JSON.stringify(allIds));
          } catch {}
        }}
        isAdmin={showAdminModal}
        onClearAll={() => {
          fetch('/api/admin/clear-alerts', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-admin-password': localStorage.getItem('fadiking_admin_password') || '',
            },
          })
            .then(() => {
              setAlerts([]);
              setUnreadAlertCount(0);
            })
            .catch(() => {});
        }}
      />

      {/* Floating Hobby Song & Background Music Widget */}
      <FloatingMusicWidget
        config={siteConfig}
        onOpenAdmin={() => setShowAdminModal(true)}
      />

      {/* Royal Mocha Espresso Brown & Gold Footer */}
      <footer className="border-t border-[#d4af37]/25 bg-[#100804]/95 py-10 text-center text-xs text-amber-200/70 mt-auto relative z-10 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#fef08a] via-[#d4af37] to-[#c68642] p-0.5 shadow-md shadow-amber-500/20 flex items-center justify-center text-slate-950 font-black">
              <Crown className="w-4 h-4 text-slate-950" />
            </div>
            <div className="text-left">
              <p className="font-extrabold text-amber-100 text-sm tracking-wide">FADI KING VIP</p>
              <p className="text-[11px] text-amber-200/60">Universal 8K Media Engine & MP3 Studio</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setShowChatBoard(true);
              }}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Live Chat
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                document.getElementById('supported-platforms')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Platforms
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              FAQ
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setShowAdminModal(true);
              }}
              className="text-[#fef08a] hover:text-white font-bold transition-colors cursor-pointer"
            >
              Admin Master
            </button>
          </div>

          <div className="text-amber-200/70 text-[11px] md:text-right">
            <p>© {new Date().getFullYear()} FADI KING. High Performance 8K, Zero Watermark, 100% Free.</p>
            <p className="text-[10px] text-amber-200/50 mt-1">
              Encrypted SSL · Anti-Bot Bypass · 30+ Platforms Supported
            </p>
          </div>
        </div>
      </footer>

      {/* Voice Guide Audio & Subtitle Explainer Overlay */}
      <VoiceGuideOverlay />
    </div>
  );
}

export default App;
