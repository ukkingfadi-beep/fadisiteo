declare module 'cakkatrok-instagram-downloader';
declare module 'btch-downloader';
declare module 'ab-downloader';
declare module 'ultra-igdl';
declare module 'instagram-url-direct';
