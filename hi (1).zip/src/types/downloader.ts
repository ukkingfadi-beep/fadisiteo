export type SupportedPlatform =
  | 'youtube'
  | 'instagram'
  | 'tiktok'
  | 'facebook'
  | 'twitter'
  | 'pinterest'
  | 'reddit'
  | 'threads'
  | 'vimeo'
  | 'other';

export interface VideoFormatOption {
  formatId: string;
  qualityLabel: string;
  resolution?: string;
  ext: string;
  fileSizeFormatted?: string;
  approxFileSize?: number;
  hasVideo: boolean;
  hasAudio: boolean;
  isAudioOnly?: boolean;
  fps?: number;
  directUrl?: string;
  formatNote?: string;
}

export interface VideoInfoResponse {
  id: string;
  title: string;
  originalUrl: string;
  platform: SupportedPlatform;
  platformName: string;
  thumbnailUrl: string;
  durationSeconds?: number;
  durationFormatted?: string;
  author?: string;
  authorUrl?: string;
  viewCount?: number;
  likeCount?: number;
  uploadDate?: string;
  description?: string;
  formats: VideoFormatOption[];
  previewVideoUrl?: string;
  isDirectStreamingAvailable: boolean;
}

export interface DownloadHistoryItem {
  id: string;
  title: string;
  platform: SupportedPlatform;
  thumbnailUrl: string;
  downloadedAt: number;
  url: string;
  quality: string;
  type: 'video' | 'audio';
}
