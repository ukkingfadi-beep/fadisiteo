import React from 'react';
import {
  Youtube,
  Instagram,
  Facebook,
  Twitter,
  Film,
  Crown,
  CheckCircle2,
} from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';

interface SupportedPlatformsProps {
  lang: Language;
  onSelectPlatform: (sampleUrl: string) => void;
}

export const SupportedPlatforms: React.FC<SupportedPlatformsProps> = ({
  lang,
  onSelectPlatform,
}) => {
  const t = translations[lang];

  const platforms = [
    {
      name: 'TikTok VIP',
      desc: 'Bina Kisi Watermark Ke HD MP4',
      badge: '👑 No Watermark',
      icon: (
        <span className="w-6 h-6 flex items-center justify-center font-black text-xs bg-cyan-950 text-cyan-300 rounded border border-cyan-500/40">
          TT
        </span>
      ),
      sample: 'https://www.tiktok.com/@scout2015/video/6718335390845095173',
      features: ['No Watermark HD', '0.2s Fastest Download', 'Original Audio MP3'],
    },
    {
      name: 'Facebook Watch & Reels',
      desc: 'Watch Videos, Reels & Live Clips',
      badge: '👑 1080p Full HD',
      icon: <Facebook className="w-6 h-6 text-blue-400" />,
      sample: 'https://www.facebook.com/watch/?v=10153231379946729',
      features: ['Facebook Reels in HD', 'Direct Fast Streaming', 'Extracted MP3 Track'],
    },
    {
      name: 'Instagram VIP',
      desc: 'Reels, Posts & Carousel Clips',
      badge: '👑 Original Quality',
      icon: <Instagram className="w-6 h-6 text-pink-400" />,
      sample: 'https://www.instagram.com/reel/C8qX-oGOMr2/',
      features: ['Reels in Full 1080p', 'Stories & Video Posts', 'High-Res Audio'],
    },
    {
      name: 'YouTube Shorts & Videos',
      desc: 'Shorts, Long Videos & High-Res Audio',
      badge: '👑 4K / 1080p',
      icon: <Youtube className="w-6 h-6 text-red-500" />,
      sample: 'https://www.youtube.com/shorts/dQw4w9WgXcQ',
      features: ['YouTube Shorts in 1080p', 'Full HD Video Formats', 'MP3 320kbps Music'],
    },
    {
      name: 'X (Twitter)',
      desc: 'High Framerate Video Tweets & GIFs',
      badge: '⚡ Direct MP4',
      icon: <Twitter className="w-6 h-6 text-sky-400" />,
      sample: 'https://twitter.com/NASA/status/1769408221852655883',
      features: ['Video Tweets in 1080p', 'GIFs to MP4', 'Instant Direct Stream'],
    },
    {
      name: 'Pinterest & Reddit',
      desc: 'Idea Pins, Memes & Reddit Videos',
      badge: '✨ Audio Merged',
      icon: <Film className="w-6 h-6 text-amber-400" />,
      sample: 'https://www.pinterest.com/pin/68749740523/',
      features: ['Reddit Audio+Video Combined', 'Pinterest HD Pins', 'Fast Video Download'],
    },
  ];

  return (
    <section id="supported" className="w-full max-w-5xl mx-auto mt-6 px-4">
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs font-bold text-white uppercase tracking-wider mb-2">
          <Crown className="w-3.5 h-3.5 text-white" />
          <span>VIP Compatibility</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mb-1">
          {t.supportedHeader}
        </h2>
        <p className="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto">{t.supportedSub}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {platforms.map((p) => (
          <div
            key={p.name}
            className="group p-5 rounded-3xl bg-neutral-900/60 backdrop-blur-3xl hover:bg-neutral-900/75 border border-white/10 hover:border-white/25 transition-all shadow-xl flex flex-col justify-between relative overflow-hidden"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center text-white shadow-sm">
                  {p.icon}
                </div>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white/10 text-slate-200 border border-white/15 shadow-sm">
                  {p.badge}
                </span>
              </div>
              <h3 className="text-base font-bold text-white mb-1">
                {p.name}
              </h3>
              <p className="text-xs text-slate-400 mb-3">{p.desc}</p>
              <ul className="space-y-1.5 mb-4">
                {p.features.map((feat) => (
                  <li key={feat} className="flex items-center gap-2 text-xs text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={() => onSelectPlatform(p.sample)}
              className="w-full py-2 px-3 rounded-full bg-white hover:bg-slate-100 text-slate-950 text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 shadow-md"
            >
              <span>Test Sample Link</span>
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};
