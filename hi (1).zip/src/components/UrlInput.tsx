import React, { useState, useEffect } from 'react';
import {
  Search,
  Clipboard,
  X,
  ArrowRight,
  Loader2,
  Sparkles,
  Youtube,
  Instagram,
  Facebook,
  Twitter,
  Crown,
  Zap,
  Server,
  Layers,
  ListOrdered,
  Music2,
} from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';
import { detectPlatform } from '../utils/platform';
import type { SupportedPlatform } from '../types/downloader';
import { playClickSound } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

interface UrlInputProps {
  lang: Language;
  onAnalyze: (url: string) => void;
  isLoading: boolean;
  initialUrl?: string;
  activeMode: 'single' | 'batch' | 'studio';
  onModeChange: (mode: 'single' | 'batch' | 'studio') => void;
  activeNode: 'sg' | 'de' | 'jp';
  onNodeChange: (node: 'sg' | 'de' | 'jp') => void;
}

const SAMPLE_URLS = [
  {
    name: 'Facebook Watch',
    url: 'https://www.facebook.com/watch/?v=10153231379946729',
    platform: 'facebook' as SupportedPlatform,
    icon: <Facebook className="w-3.5 h-3.5 text-blue-400" />,
  },
  {
    name: 'TikTok (No WM)',
    url: 'https://www.tiktok.com/@scout2015/video/6718335390845095173',
    platform: 'tiktok' as SupportedPlatform,
    icon: <span className="text-[10px] font-black text-cyan-400">TT</span>,
  },
  {
    name: 'YouTube Short',
    url: 'https://www.youtube.com/shorts/dQw4w9WgXcQ',
    platform: 'youtube' as SupportedPlatform,
    icon: <Youtube className="w-3.5 h-3.5 text-red-400" />,
  },
  {
    name: 'YouTube HD',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    platform: 'youtube' as SupportedPlatform,
    icon: <Sparkles className="w-3.5 h-3.5 text-amber-400" />,
  },
  {
    name: 'Pinterest HD',
    url: 'https://www.pinterest.com/pin/68749740523/',
    platform: 'pinterest' as SupportedPlatform,
    icon: <span className="text-[10px] font-black text-rose-400">PIN</span>,
  },
];

export const UrlInput: React.FC<UrlInputProps> = ({
  lang,
  onAnalyze,
  isLoading,
  initialUrl = '',
  activeMode,
  onModeChange,
  activeNode,
  onNodeChange,
}) => {
  const [url, setUrl] = useState(initialUrl);
  const [detected, setDetected] = useState<SupportedPlatform>('other');
  const [loadingStep, setLoadingStep] = useState(0);
  const t = translations[lang];

  useEffect(() => {
    if (isLoading) {
      setLoadingStep(0);
      const t1 = setTimeout(() => setLoadingStep(1), 700);
      const t2 = setTimeout(() => setLoadingStep(2), 1500);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    } else {
      setLoadingStep(0);
    }
  }, [isLoading]);

  useEffect(() => {
    if (initialUrl && initialUrl !== url) {
      setUrl(initialUrl);
    }
  }, [initialUrl]);

  useEffect(() => {
    const nextPlatform = url.trim() ? detectPlatform(url.trim()).platform : 'other';
    setDetected((prev) => (prev === nextPlatform ? prev : nextPlatform));
  }, [url]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!url.trim() || isLoading) return;
    playClickSound();
    speakFeature(
      'Download Button',
      'Mera kaam video analyze karke direct 8K aur MP3 download links provide karna hai.'
    );
    onAnalyze(url.trim());
  };

  const handlePaste = async () => {
    playClickSound();
    speakFeature(
      'Clipboard Paste',
      'Mera kaam copied link yahan paste karna hai.'
    );
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          setUrl(text.trim());
          const detectedInfo = detectPlatform(text.trim());
          setDetected(detectedInfo.platform);
          onAnalyze(text.trim());
        }
      }
    } catch {
      // Manual paste fallback
    }
  };

  const handleSampleClick = (sampleUrl: string) => {
    playClickSound();
    speakFeature(
      'Sample Link',
      'Mera kaam fast testing ke liye video link load karna hai.'
    );
    setUrl(sampleUrl);
    onAnalyze(sampleUrl);
  };

  const getPlatformIcon = (plat: SupportedPlatform) => {
    switch (plat) {
      case 'youtube':
        return <Youtube className="w-4 h-4 text-red-400" />;
      case 'instagram':
        return <Instagram className="w-4 h-4 text-pink-400" />;
      case 'facebook':
        return <Facebook className="w-4 h-4 text-blue-400" />;
      case 'tiktok':
        return <span className="font-black text-xs text-cyan-400">TT</span>;
      case 'twitter':
        return <Twitter className="w-4 h-4 text-sky-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-2 sm:mt-4">
      {/* Node selector without duplicate button row */}
      <div className="flex items-center justify-between gap-4 mb-3 px-1">
        <div className="flex items-center gap-2 text-xs text-amber-300/90 font-bold">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Direct Extraction Engine</span>
        </div>

        {/* Server Relay Node selector */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Server className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-mono text-[11px]">{t.serverNodeLabel}</span>
          <select
            value={activeNode}
            onChange={(e) => {
              playClickSound();
              onNodeChange(e.target.value as any);
            }}
            className="bg-black/80 border border-[#d4af37]/30 text-amber-200 text-xs rounded-xl px-2.5 py-1 outline-none focus:border-amber-400 cursor-pointer"
          >
            <option value="sg">{t.serverNodes.sg}</option>
            <option value="de">{t.serverNodes.de}</option>
            <option value="jp">{t.serverNodes.jp}</option>
          </select>
        </div>
      </div>

      {/* Main Search / URL Input Box - Frosted Glass Pill matching Image 2 */}
      {activeMode === 'single' && (
        <form
          onSubmit={handleSubmit}
          className="relative group bg-neutral-900/65 border border-white/15 hover:border-white/30 focus-within:border-white/50 rounded-full p-2 sm:p-2.5 transition-all shadow-2xl backdrop-blur-3xl"
        >
          <div className="flex items-center gap-2 sm:gap-3 pl-3">
            {/* Platform detection indicator */}
            <div className="w-8 h-8 rounded-full bg-white/10 border border-white/15 flex items-center justify-center shrink-0 text-white">
              {getPlatformIcon(detected)}
            </div>

            {/* Input field */}
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onClick={() => {
                if (!url) {
                  speakFeature(
                    'Link Input Box',
                    'Mera kaam yahan aapka video link lena hai. Kisi bhi TikTok, YouTube, Instagram ya Facebook video ka link yahan paste karein.'
                  );
                }
              }}
              placeholder="Paste any video or audio link here (e.g. YouTube, TikTok, Insta)..."
              className="w-full bg-transparent text-white text-xs sm:text-sm font-medium placeholder-slate-400 outline-none pr-2 py-2.5 selection:bg-white selection:text-slate-950"
              disabled={isLoading}
            />

            {/* Clear Button */}
            {url && (
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setUrl('');
                }}
                className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
                title={t.clearBtn}
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {/* Paste Button */}
            <button
              type="button"
              onClick={handlePaste}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10 cursor-pointer shrink-0 shadow-sm"
            >
              <Clipboard className="w-3.5 h-3.5 text-white" />
              <span>{t.pasteBtn}</span>
            </button>

            {/* Clean White Action Button */}
            <button
              type="submit"
              disabled={isLoading || !url.trim()}
              className={`px-5 sm:px-7 py-2.5 rounded-full font-black text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
                isLoading || !url.trim()
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-white hover:bg-slate-100 text-slate-950 shadow-xl hover:scale-105 active:scale-95'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span className="hidden sm:inline">{t.analyzing}</span>
                </>
              ) : (
                <>
                  <span>Download</span>
                  <ArrowRight className="w-4 h-4 stroke-[3]" />
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* High-Precision Loading Perfection Indicator */}
      {activeMode === 'single' && isLoading && (
        <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-slate-900/95 via-[#0b1424]/95 to-slate-900/95 border border-amber-500/40 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between gap-3 mb-2.5">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider">
                {loadingStep === 0 && 'Connecting Dedicated Relay Node...'}
                {loadingStep === 1 && 'Extracting High-Definition 1080p/4K Stream...'}
                {loadingStep === 2 && 'Generating Direct High-Speed Download Links...'}
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-bold">
              {loadingStep === 0 ? '35%' : loadingStep === 1 ? '75%' : '98%'}
            </span>
          </div>

          {/* Glowing Animated Progress Track */}
          <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800 relative">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-700 ease-out shadow-sm"
              style={{
                width: loadingStep === 0 ? '35%' : loadingStep === 1 ? '75%' : '98%',
              }}
            />
          </div>

          <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              <span>Node: {activeNode.toUpperCase()} Supercharged Server</span>
            </span>
            <span className="text-amber-400/90 font-medium">Bypassing watermark & encryption...</span>
          </div>
        </div>
      )}

      {/* Quick Try Samples (Zero-Pill, clean unboxed metadata per Constitution) */}
      {activeMode === 'single' && (
        <div className="mt-4 flex flex-wrap items-center justify-center sm:justify-start gap-x-4 gap-y-2 text-xs text-slate-400">
          <span className="font-semibold text-slate-400 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            {t.quickTry}
          </span>
          {SAMPLE_URLS.map((sample, idx) => (
            <React.Fragment key={sample.name}>
              <button
                type="button"
                onClick={() => handleSampleClick(sample.url)}
                className="hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1.5 font-medium underline underline-offset-4 decoration-slate-700 hover:decoration-amber-400"
              >
                {sample.icon}
                <span>{sample.name}</span>
              </button>
              {idx < SAMPLE_URLS.length - 1 && (
                <span className="text-slate-700 hidden sm:inline" aria-hidden="true">
                  ·
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
      )}
    </div>
  );
};
