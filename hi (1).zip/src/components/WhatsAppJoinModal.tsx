import React, { useState } from 'react';
import { X, CheckCircle, ExternalLink, ShieldCheck, ArrowRight, MessageCircle, Crown, Sparkles } from 'lucide-react';
import type { Language } from '../utils/translations';
import { WHATSAPP_CHANNEL_LINK } from '../utils/translations';
import { playClickSound, playSuccessChime } from '../utils/sound';

interface WhatsAppJoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerified: () => void;
  lang: Language;
  targetVideoTitle?: string;
}

export const WhatsAppJoinModal: React.FC<WhatsAppJoinModalProps> = ({
  isOpen,
  onClose,
  onVerified,
  lang,
  targetVideoTitle,
}) => {
  const [hasClickedJoin, setHasClickedJoin] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  const handleJoinClick = () => {
    playClickSound();
    window.open(WHATSAPP_CHANNEL_LINK, '_blank', 'noopener,noreferrer');
    setHasClickedJoin(true);
  };

  const handleConfirmJoined = () => {
    playClickSound();
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      playSuccessChime();
      onVerified();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md p-6 sm:p-8 bg-slate-900 border-2 border-amber-500/40 rounded-3xl vip-card-shadow text-center overflow-hidden">
        {/* Golden top gradient line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-yellow-300 to-emerald-400" />

        {/* Close button */}
        <button
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Crown & WhatsApp Icon */}
        <div className="relative w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center shadow-xl shadow-amber-500/25 text-slate-950 font-black">
          <MessageCircle className="w-9 h-9 fill-slate-950 text-slate-950" />
          <span className="absolute -top-2 -right-2 p-1 rounded-full bg-amber-400 text-slate-950 shadow">
            <Crown className="w-4 h-4 fill-slate-950" />
          </span>
        </div>

        {/* Title */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-[11px] font-black text-amber-400 uppercase tracking-wider mb-2">
          <Sparkles className="w-3 h-3" />
          VIP Download Verification
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-white mb-2 tracking-tight">
          {lang === 'ur'
            ? 'Pehle WhatsApp Channel Follow Karein'
            : lang === 'hi'
            ? 'पहले WhatsApp चैनल फॉलो करें'
            : lang === 'ar'
            ? 'يرجى متابعة قناة الواتساب أولاً'
            : 'Follow WhatsApp Channel First'}
        </h3>

        <p className="text-xs sm:text-sm text-slate-300 mb-5 px-1 leading-relaxed">
          {lang === 'ur' ? (
            <>
              Video download unlock karne ke liye pehle hamara official{' '}
              <strong className="text-amber-400">FADI KING VIP</strong> WhatsApp channel follow karein. Follow karte hi aapki download bina kisi rukawat shuru ho jayegi!
            </>
          ) : lang === 'hi' ? (
            <>
              डाउनलोड अनलॉक करने के लिए पहले हमारा आधिकारिक{' '}
              <strong className="text-amber-400">FADI KING VIP</strong> WhatsApp चैनल फॉलो करें।
            </>
          ) : (
            <>
              To unlock full high-speed video & audio downloads, follow the official{' '}
              <strong className="text-amber-400">FADI KING VIP</strong> WhatsApp channel.
            </>
          )}
        </p>

        {targetVideoTitle && (
          <div className="mb-5 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-400 truncate text-left">
            <span className="text-amber-400 font-bold">Selected Media: </span>
            <span className="text-slate-200 font-medium">{targetVideoTitle}</span>
          </div>
        )}

        {/* Step 1: Follow WhatsApp Channel */}
        <div className="space-y-3">
          <button
            onClick={handleJoinClick}
            className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:from-emerald-400 hover:to-green-400 text-slate-950 font-black text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-xl shadow-emerald-500/25 active:scale-[0.98] transition-all cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 fill-slate-950" />
            <span>
              {lang === 'ur'
                ? '1. WhatsApp Channel Follow Karein'
                : lang === 'hi'
                ? '1. WhatsApp चैनल फॉलो करें'
                : lang === 'ar'
                ? '1. متابعة قناة الواتساب'
                : '1. Follow WhatsApp Channel'}
            </span>
            <ExternalLink className="w-4 h-4 ml-1" />
          </button>

          {/* Step 2: Confirm Followed */}
          <button
            onClick={handleConfirmJoined}
            disabled={isVerifying}
            className={`w-full py-3 px-5 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 border transition-all cursor-pointer ${
              hasClickedJoin
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black border-amber-400 shadow-lg shadow-amber-500/20 active:scale-95'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700/60'
            }`}
          >
            {isVerifying ? (
              <span className="flex items-center gap-2 text-slate-950">
                <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                <span>Unlocking download...</span>
              </span>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>
                  {lang === 'ur'
                    ? '2. Maine Channel Follow Kar Liya (Start Download)'
                    : lang === 'hi'
                    ? '2. मैंने चैनल फॉलो कर लिया (डाउनलोड शुरू करें)'
                    : lang === 'ar'
                    ? '2. لقد تابعت القناة (بدء التنزيل)'
                    : '2. I Followed the Channel (Start Download)'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        <div className="mt-5 flex items-center justify-center gap-2 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>FADI KING Official WhatsApp Channel · 100% Free VIP Access</span>
        </div>
      </div>
    </div>
  );
};
