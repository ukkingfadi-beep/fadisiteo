import React, { useState, useEffect } from 'react';
import {
  Crown,
  Lock,
  Unlock,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Radio,
} from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations, WHATSAPP_CHANNEL_LINK } from '../utils/translations';
import { playClickSound, playUnlockSound, playSuccessChime } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

interface LoadingGateProps {
  lang: Language;
  onUnlocked: () => void;
  onOpenChannelDirect: () => void;
}

export const LoadingGate: React.FC<LoadingGateProps> = ({
  lang,
  onUnlocked,
  onOpenChannelDirect,
}) => {
  const [hasFollowed, setHasFollowed] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isEntering, setIsEntering] = useState(false);
  const [progress, setProgress] = useState(15);

  const t = translations[lang].gate;

  useEffect(() => {
    // Welcome voice announcement
    const voiceTimer = setTimeout(() => {
      speakFeature(
        'Loading Gate Welcome',
        'Assalam-o-Alaikum! Fadi King VIP Portal mein aapka swagat hai. Mera kaam kisi bhi social media se high quality video aur MP3 audio download karna hai.'
      );
    }, 800);

    // Simulated smooth progress bar animation
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) return prev;
        return prev + Math.floor(Math.random() * 15) + 5;
      });
    }, 400);
    return () => {
      clearTimeout(voiceTimer);
      clearInterval(timer);
    };
  }, []);

  const handleOpenChannel = () => {
    playClickSound();
    speakFeature(
      'WhatsApp VIP Channel',
      'Mera kaam official WhatsApp channel open karwana aur website ko unlock karna hai.'
    );
    window.open(WHATSAPP_CHANNEL_LINK, '_blank', 'noopener,noreferrer');
    // Enable follow verification
    setTimeout(() => {
      setHasFollowed(true);
      playSuccessChime();
    }, 1200);
  };

  const handleConfirmFollow = () => {
    setIsVerifying(true);
    playClickSound();
    speakFeature(
      'Follow Verification',
      'Mera kaam VIP verification check karna aur access unlock karna hai.'
    );
    setTimeout(() => {
      setHasFollowed(true);
      setIsVerifying(false);
      setProgress(100);
      playSuccessChime();
    }, 600);
  };

  const handleEnterSuite = () => {
    if (!hasFollowed) return;
    playUnlockSound();
    speakFeature(
      'Enter Website',
      'Mera kaam website ke main dashboard par le jana hai jahan aap video link paste karke download kar sakte hain.'
    );
    setIsEntering(true);
    setTimeout(() => {
      onUnlocked();
    }, 450);
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#050811] text-slate-100 transition-opacity duration-500 overflow-y-auto ${
        isEntering ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
      }`}
    >
      {/* Background ambient lighting meshes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-amber-500/15 via-emerald-500/10 to-transparent blur-3xl animate-pulse" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-emerald-600/10 blur-3xl" />
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-amber-600/10 blur-3xl" />
        {/* Subtle royal geometric grid */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      <div className="relative w-full max-w-lg mx-auto my-auto bg-slate-900/80 border border-amber-500/30 rounded-3xl p-6 sm:p-9 shadow-2xl shadow-amber-950/40 backdrop-blur-2xl">
        {/* Top gold accent line */}
        <div className="absolute top-0 left-8 right-8 h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent" />

        {/* Brand Royal Header & Emblem */}
        <div className="text-center mb-7">
          <div className="inline-flex items-center justify-center relative mb-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400/20 via-slate-800 to-emerald-500/20 border border-amber-400/40 flex items-center justify-center shadow-lg shadow-amber-500/20 relative group">
              <Crown className="w-10 h-10 text-amber-400 animate-bounce duration-1000" />
              <div className="absolute -inset-1 rounded-2xl bg-amber-400/20 blur-md -z-10 group-hover:bg-amber-400/30 transition-all" />
            </div>
            <span className="absolute -bottom-2 px-2.5 py-0.5 rounded-full bg-slate-950 border border-amber-400/50 text-[10px] font-black tracking-widest text-amber-300 uppercase">
              VIP ROYAL
            </span>
          </div>

          {/* Animated Brand Name: FADI KING */}
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-emerald-300">
            FADI KING
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-medium tracking-wide">
            {t.tagline}
          </p>

          {/* Verification Status Pill */}
          <div className="mt-4 inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-xs text-slate-300">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>{t.badge}</span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1.5 font-mono">
            <span>{hasFollowed ? '100% UNLOCKED' : 'AUTHORIZATION REQUIRED'}</span>
            <span>{hasFollowed ? '100%' : `${progress}%`}</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                hasFollowed
                  ? 'bg-gradient-to-r from-emerald-400 to-amber-400 w-full'
                  : 'bg-gradient-to-r from-amber-500 to-emerald-400'
              }`}
              style={{ width: hasFollowed ? '100%' : `${progress}%` }}
            />
          </div>
        </div>

        {/* Instruction Card */}
        <div className="bg-slate-950/70 border border-slate-800/90 rounded-2xl p-4 sm:p-5 mb-6 text-sm text-slate-300 leading-relaxed">
          <p className="text-xs sm:text-sm font-medium text-slate-200 text-center">
            {t.instructions}
          </p>

          <div className="mt-4 space-y-3">
            {/* Step 1: Follow WhatsApp Channel */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/90 border border-emerald-500/20 hover:border-emerald-500/40 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  1
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">
                    {t.step1Title}
                  </div>
                  <div className="text-[11px] text-emerald-400">
                    @FADI KING Official Channel
                  </div>
                </div>
              </div>
              <button
                onClick={handleOpenChannel}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>{t.step1Btn}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Step 2: Confirm Follow */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/90 border border-amber-500/20 hover:border-amber-500/40 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                  2
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">
                    {t.step2Title}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {hasFollowed ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 inline" />
                        {t.step2Verified}
                      </span>
                    ) : (
                      'Click after following the channel'
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={handleConfirmFollow}
                disabled={isVerifying}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  hasFollowed
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                }`}
              >
                {hasFollowed ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Verified</span>
                  </>
                ) : (
                  <span>{isVerifying ? 'Checking...' : t.step2Btn}</span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Grand Unlock CTA Button */}
        <div className="space-y-3">
          <button
            onClick={handleEnterSuite}
            disabled={!hasFollowed}
            className={`w-full py-4 px-6 rounded-2xl font-black text-sm tracking-wide transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
              hasFollowed
                ? 'bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-500 text-slate-950 shadow-xl shadow-amber-500/30 hover:shadow-emerald-500/40 hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-slate-800/80 text-slate-500 border border-slate-700/50 cursor-not-allowed opacity-75'
            }`}
          >
            {hasFollowed ? (
              <>
                <Unlock className="w-4 h-4 text-slate-950" />
                <span>{t.unlockBtn}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <Lock className="w-4 h-4 text-slate-500" />
                <span>{t.unlockBtn}</span>
              </>
            )}
          </button>

          {!hasFollowed && (
            <p className="text-[11px] text-center text-slate-400">
              {t.unlockLockedNote}
            </p>
          )}

          {hasFollowed && (
            <p className="text-[11px] text-center text-emerald-400/90 font-medium flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              VIP Access Unlocked · Enjoy Unlimited High-Speed Downloads
            </p>
          )}
        </div>

        {/* Footer info & Direct bypass for existing followers */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            100% Free & Safe
          </span>
          <button
            onClick={() => {
              setHasFollowed(true);
              handleConfirmFollow();
            }}
            className="text-slate-400 hover:text-amber-400 underline underline-offset-2 transition-colors cursor-pointer"
          >
            Already following?
          </button>
        </div>
      </div>
    </div>
  );
};
