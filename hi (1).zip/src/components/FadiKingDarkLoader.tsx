import React, { useState, useEffect, useRef } from 'react';
import { Crown, Sparkles, ShieldCheck, Zap } from 'lucide-react';
import { playSuccessChime } from '../utils/sound';

interface FadiKingDarkLoaderProps {
  brandName?: string;
  onComplete: () => void;
  isTabChange?: boolean;
  tabLabel?: string;
}

export const FadiKingDarkLoader: React.FC<FadiKingDarkLoaderProps> = ({
  brandName = 'FADI KING',
  onComplete,
  isTabChange = false,
  tabLabel = 'LOADING MODULE...',
}) => {
  const [percent, setPercent] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [statusText, setStatusText] = useState(
    isTabChange ? `SWITCHING TO ${tabLabel.toUpperCase()}...` : 'INITIALIZING 8K MEDIA PIPELINE...'
  );
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    // Ultra-smooth cinematic masculine loading
    // Fast 400ms for tab changes, 1300ms for initial full boot
    const duration = isTabChange ? 380 : 1300;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, Math.floor((elapsed / duration) * 100));
      setPercent(progress);

      if (!isTabChange) {
        if (progress < 25) {
          setStatusText('CONNECTING TO 8K VIP RELAY NODES...');
        } else if (progress < 55) {
          setStatusText('INITIALIZING ULTRA 320KBPS AUDIO ENGINE...');
        } else if (progress < 85) {
          setStatusText('CALIBRATING HIGH-SPEED MEDIA EXTRACTOR...');
        } else {
          setStatusText('WELCOME TO FADI KING ROYAL SUITE');
        }
      } else {
        if (progress < 50) {
          setStatusText(`LOADING ${tabLabel.toUpperCase()}...`);
        } else {
          setStatusText('MODULE READY');
        }
      }

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsFadingOut(true);
          if (!isTabChange) {
            try {
              playSuccessChime();
            } catch {}
          }
          setTimeout(() => {
            onCompleteRef.current?.();
          }, isTabChange ? 150 : 250);
        }, isTabChange ? 60 : 120);
      }
    }, isTabChange ? 15 : 20);

    return () => clearInterval(interval);
  }, [isTabChange, tabLabel]);

  // Tab change micro-loader variant (Clean, lightweight, non-intrusive)
  if (isTabChange) {
    return (
      <div
        className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md text-white transition-opacity duration-200 select-none ${
          isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
      >
        <div className="relative flex flex-col items-center p-6 rounded-3xl bg-[#070b14]/90 border border-amber-500/30 shadow-[0_0_50px_rgba(0,0,0,0.9)] max-w-xs w-full text-center">
          {/* Glowing Animated Ring with Crown */}
          <div className="relative mb-3 flex items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-neutral-900 to-black border border-amber-400/50 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.3)]">
              <Crown className="w-6 h-6 text-amber-400 animate-pulse" />
            </div>
            <div
              className="absolute -inset-1.5 rounded-2xl border border-amber-400/30 border-dashed animate-spin"
              style={{ animationDuration: '6s' }}
            />
          </div>

          <p className="text-[10px] font-black tracking-[0.25em] uppercase text-amber-400 mb-1">
            FADI KING VIP
          </p>
          <p className="text-xs font-bold text-slate-200 mb-3">{statusText}</p>

          {/* Micro Progress Bar */}
          <div className="w-full h-1.5 rounded-full bg-neutral-900 border border-white/10 overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300 transition-all duration-75 ease-out shadow-[0_0_10px_rgba(245,158,11,0.8)]"
              style={{ width: `${percent}%` }}
            />
          </div>

          <div className="flex items-center justify-between w-full mt-2 text-[10px] font-mono text-neutral-400">
            <span>Loading Module</span>
            <span className="text-amber-400 font-bold">{percent}%</span>
          </div>
        </div>
      </div>
    );
  }

  // Full Initial Masculine Dark Mode Loading Page (Matching Video Reference)
  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#03060c] text-white transition-opacity duration-500 select-none overflow-hidden ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        backgroundColor: '#03060c',
        fontFamily: '"Montserrat", "Cinzel", "Segoe UI", sans-serif',
      }}
    >
      {/* Dynamic Background Glowing Blobs matching Video 2 */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-amber-600/15 via-yellow-600/10 to-cyan-600/10 rounded-full blur-[110px] pointer-events-none animate-pulse" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-gradient-to-br from-amber-400/20 via-white/5 to-transparent rounded-full blur-[80px] pointer-events-none" />

      {/* Futuristic Carbon Grid Scanlines */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.2) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="relative z-10 flex flex-col items-center justify-center px-6 w-full max-w-md text-center">
        {/* VIP Sovereign Emblem */}
        <div className="mb-5 relative flex items-center justify-center">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-neutral-900 via-[#0c121e] to-black border-2 border-amber-400/60 flex items-center justify-center shadow-[0_0_45px_rgba(245,158,11,0.35)] relative overflow-hidden group">
            {/* Shimmer line over icon */}
            <div className="absolute inset-0 bg-gradient-to-tr from-amber-400/20 via-transparent to-transparent pointer-events-none" />
            <Crown className="w-10 h-10 text-amber-400 drop-shadow-[0_2px_12px_rgba(251,191,36,0.7)] animate-pulse" />
          </div>

          {/* Kinetic Spinning Rings */}
          <div
            className="absolute -inset-2.5 rounded-3xl border border-amber-500/25 border-dashed animate-spin"
            style={{ animationDuration: '12s' }}
          />
          <div
            className="absolute -inset-4 rounded-full border border-cyan-500/15 border-dotted animate-spin"
            style={{ animationDuration: '20s', animationDirection: 'reverse' }}
          />
        </div>

        {/* FADI KING Masculine Bold Typography */}
        <div className="relative mb-2">
          <h1
            className="text-4xl sm:text-5xl font-black tracking-[0.28em] uppercase text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-yellow-500 drop-shadow-[0_4px_25px_rgba(245,158,11,0.4)]"
            style={{
              letterSpacing: '0.28em',
              textShadow: '0 0 30px rgba(245, 158, 11, 0.45)',
            }}
          >
            {brandName}
          </h1>
          <div className="flex items-center justify-center gap-3 mt-2">
            <span className="h-[1px] w-8 bg-gradient-to-r from-transparent to-amber-500/60" />
            <p className="text-[11px] font-bold tracking-[0.45em] uppercase text-amber-300/90 flex items-center gap-1.5">
              <span>ROYAL 8K MEDIA ENGINE</span>
            </p>
            <span className="h-[1px] w-8 bg-gradient-to-l from-transparent to-amber-500/60" />
          </div>
        </div>

        {/* Dynamic Percentage Counter */}
        <div className="my-7 relative flex items-baseline justify-center">
          <span className="text-6xl sm:text-7xl font-black font-mono tracking-tighter text-white drop-shadow-[0_0_25px_rgba(255,255,255,0.45)]">
            {percent}
          </span>
          <span className="text-2xl sm:text-3xl font-extrabold font-mono text-amber-400 ml-1">
            %
          </span>
        </div>

        {/* Dynamic Progress Bar with Scanning Beam */}
        <div className="w-full max-w-xs sm:max-w-sm">
          <div className="relative w-full h-2.5 rounded-full bg-neutral-950 border border-white/10 p-0.5 overflow-hidden shadow-[inset_0_2px_4px_rgba(0,0,0,0.9)]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300 transition-all duration-100 ease-out relative shadow-[0_0_16px_rgba(251,191,36,0.9)]"
              style={{ width: `${percent}%` }}
            >
              {/* Shimmer laser sweep */}
              <div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/80 to-transparent animate-shimmer"
                style={{ backgroundSize: '200% 100%' }}
              />
            </div>
          </div>

          {/* Status Subtitle below progress bar */}
          <div className="flex items-center justify-between mt-3 text-[10px] font-mono tracking-wider text-neutral-400 px-1">
            <span className="text-amber-400/95 flex items-center gap-1.5 truncate max-w-[220px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block shrink-0" />
              <span className="truncate">{statusText}</span>
            </span>
            <span className="text-neutral-500 font-bold shrink-0">{percent}/100</span>
          </div>
        </div>

        {/* Skip button for instant entry */}
        <button
          type="button"
          onClick={() => {
            setIsFadingOut(true);
            setTimeout(onComplete, 200);
          }}
          className="mt-8 px-4 py-1.5 rounded-full text-[10px] font-mono tracking-widest uppercase text-neutral-500 hover:text-amber-300 hover:border-amber-500/40 border border-white/5 transition-all cursor-pointer bg-neutral-900/40 backdrop-blur-md active:scale-95"
        >
          Skip Intro →
        </button>
      </div>
    </div>
  );
};
