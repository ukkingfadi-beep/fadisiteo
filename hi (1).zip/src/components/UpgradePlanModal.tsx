import React, { useState } from 'react';
import {
  Crown,
  CheckCircle2,
  X,
  MessageCircle,
  KeyRound,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  Lock,
} from 'lucide-react';
import { Language, translations } from '../utils/translations';
import {
  activateLifetimeLicense,
  getWhatsAppPurchaseUrl,
  UPGRADE_PRICE_PKR,
  WHATSAPP_ORDERS_PHONE,
} from '../utils/quotaManager';
import { playSound } from '../utils/sound';

interface UpgradePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onOpenAdmin: () => void;
  isLimitReached?: boolean;
  userEmailPrefill?: string;
}

export const UpgradePlanModal: React.FC<UpgradePlanModalProps> = ({
  isOpen,
  onClose,
  lang,
  onOpenAdmin,
  isLimitReached = false,
  userEmailPrefill = '',
}) => {
  const t = translations[lang];
  const p = t.plan;

  const [email, setEmail] = useState(userEmailPrefill);
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleWhatsAppBuy = () => {
    playSound('click');
    const url = getWhatsAppPurchaseUrl(email);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !code.trim()) {
      setError('Please provide both your email address and activation code.');
      return;
    }

    setLoading(true);
    setError(null);
    playSound('click');

    const result = await activateLifetimeLicense(email, code);
    setLoading(false);

    if (result.success) {
      setSuccess(true);
      playSound('unlock');
      setTimeout(() => {
        onClose();
      }, 2200);
    } else {
      setError(result.error || 'Failed to verify activation code.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-hidden">
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-neutral-900/95 border border-white/15 rounded-3xl shadow-2xl text-slate-100 backdrop-blur-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={() => {
            playSound('click');
            onClose();
          }}
          className="absolute top-4 right-4 z-20 p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6">

        {/* Header Emblem */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-white text-slate-950 shadow-xl mb-3">
            <Crown className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white mb-1">
            {p.modalTitle}
          </h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto">
            {p.modalSubtitle}
          </p>
        </div>

        {/* Quota limit warning alert if triggered by exhausting 5 downloads */}
        {isLimitReached && (
          <div className="mb-6 p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-200/90 leading-relaxed">
              <strong className="block font-semibold text-amber-300 mb-0.5">
                {p.limitReachedTitle}
              </strong>
              {p.limitReachedDesc}
            </div>
          </div>
        )}

        {/* Pricing Card */}
        <div className="mb-6 p-4 rounded-2xl bg-neutral-950/70 border border-white/15 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-400 font-semibold mb-0.5">
              {p.lifetimeAccess}
            </div>
            <div className="text-2xl font-black text-white font-mono tracking-tight">
              {UPGRADE_PRICE_PKR}
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-400 block">WhatsApp Direct:</span>
            <span className="text-xs font-mono text-emerald-300 font-semibold">
              +{WHATSAPP_ORDERS_PHONE}
            </span>
          </div>
        </div>

        {/* Plan Perks */}
        <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
          {p.perks.map((perk, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{perk}</span>
            </div>
          ))}
        </div>

        {/* Action Zone: WhatsApp Purchase Button */}
        <div className="mb-6">
          <button
            onClick={handleWhatsAppBuy}
            className="w-full flex items-center justify-center gap-2.5 py-3.5 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-semibold rounded-xl shadow-lg shadow-emerald-950/50 transition-all transform active:scale-[0.99]"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span>{p.whatsappBuyBtn}</span>
          </button>
          <p className="text-[11px] text-center text-slate-400 mt-2">
            Clicking opens WhatsApp with pre-filled order message. Pay 250 PKR to get your instant activation code.
          </p>
        </div>

        {/* Divider */}
        <div className="relative my-6 flex items-center justify-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800"></div>
          </div>
          <span className="relative bg-[#0a0f0d] px-3 text-xs uppercase tracking-wider text-slate-500 font-semibold">
            {p.redeemTitle}
          </span>
        </div>

        {/* Code Redemption Form */}
        {success ? (
          <div className="p-4 bg-emerald-500/10 border border-emerald-500/40 rounded-xl text-center animate-in fade-in">
            <Sparkles className="w-8 h-8 text-amber-400 mx-auto mb-2" />
            <h3 className="text-base font-bold text-emerald-300 mb-1">
              VIP Lifetime Unlocked!
            </h3>
            <p className="text-xs text-slate-300">{p.activateSuccess}</p>
          </div>
        ) : (
          <form onSubmit={handleActivate} className="space-y-3.5">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {p.emailLabel}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={p.emailPlaceholder}
                className="w-full px-3.5 py-2.5 bg-black/50 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/30 rounded-lg text-sm text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {p.codeLabel}
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder={p.codePlaceholder}
                  className="w-full pl-3.5 pr-10 py-2.5 bg-black/50 border border-slate-700 focus:border-amber-500 focus:ring-1 focus:ring-amber-500/30 rounded-lg text-sm text-white placeholder-slate-500 font-mono tracking-wider outline-none transition-colors"
                />
                <KeyRound className="absolute right-3 top-3 w-4 h-4 text-slate-500 pointer-events-none" />
              </div>
            </div>

            {error && (
              <div className="p-2.5 bg-red-950/40 border border-red-500/30 rounded-lg text-xs text-red-300">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              {loading ? (
                <span>{p.activating}</span>
              ) : (
                <>
                  <span>{p.activateBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

          {/* Footer Admin Portal Link */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
            <span>Official FADI KING System</span>
            <button
              onClick={() => {
                playSound('click');
                onClose();
                onOpenAdmin();
              }}
              className="flex items-center gap-1.5 text-slate-400 hover:text-amber-400 transition-colors"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{p.adminPortalLink}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
