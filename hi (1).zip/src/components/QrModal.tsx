import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { X, Smartphone, Download, Copy, Check } from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';

interface QrModalProps {
  isOpen: boolean;
  onClose: () => void;
  downloadUrl: string;
  title: string;
  lang: Language;
}

export const QrModal: React.FC<QrModalProps> = ({
  isOpen,
  onClose,
  downloadUrl,
  title,
  lang,
}) => {
  const [qrSrc, setQrSrc] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const t = translations[lang];

  useEffect(() => {
    if (isOpen && downloadUrl) {
      QRCode.toDataURL(downloadUrl, {
        width: 280,
        margin: 2,
        color: {
          dark: '#020617',
          light: '#ffffff',
        },
      })
        .then((url) => setQrSrc(url))
        .catch((err) => console.error('QR generation failed:', err));
    }
  }, [isOpen, downloadUrl]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(downloadUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm p-6 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl text-center">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
          <Smartphone className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-white mb-1">{t.scanQrTitle}</h3>
        <p className="text-xs text-slate-400 mb-4 px-2">{t.scanQrDesc}</p>

        {/* QR Code Canvas */}
        <div className="p-3 bg-white rounded-xl inline-block shadow-inner mx-auto mb-4">
          {qrSrc ? (
            <img src={qrSrc} alt="Download QR Code" className="w-56 h-56 mx-auto block" />
          ) : (
            <div className="w-56 h-56 flex items-center justify-center text-slate-800 font-mono text-sm">
              Generating QR...
            </div>
          )}
        </div>

        <p className="text-xs font-medium text-slate-300 truncate mb-3 px-2">
          {title}
        </p>

        <div className="flex gap-2 justify-center">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied!' : t.copyLink}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
