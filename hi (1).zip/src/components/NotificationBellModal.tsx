import React from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  Sparkles,
  Gift,
  Info,
  CheckCheck,
  Crown,
  Clock,
  Trash2,
} from 'lucide-react';
import { playClickSound } from '../utils/sound';

export interface BroadcastAlert {
  id: string;
  title: string;
  text: string;
  sender: string;
  tag: 'alert' | 'update' | 'offer' | 'notice';
  timestamp: string;
  soundTune?: 'tung_tung' | 'royal_bell' | 'crystal_chime' | 'cyber_alert' | 'success_fanfare';
  popup?: boolean;
}

interface NotificationBellModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: BroadcastAlert[];
  onMarkAllRead: () => void;
  isAdmin?: boolean;
  onClearAll?: () => void;
}

export const NotificationBellModal: React.FC<NotificationBellModalProps> = ({
  isOpen,
  onClose,
  alerts,
  onMarkAllRead,
  isAdmin = false,
  onClearAll,
}) => {
  if (!isOpen) return null;

  const getTagBadge = (tag: string) => {
    switch (tag) {
      case 'alert':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            <span>Alert</span>
          </span>
        );
      case 'update':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <Sparkles className="w-3 h-3 text-emerald-400" />
            <span>New Update</span>
          </span>
        );
      case 'offer':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <Gift className="w-3 h-3 text-amber-400" />
            <span>VIP Offer</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
            <Info className="w-3 h-3 text-blue-400" />
            <span>Notice</span>
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#080d1a] border border-amber-500/35 rounded-3xl shadow-2xl flex flex-col text-slate-100 max-h-[85vh] overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 bg-gradient-to-r from-slate-900 via-[#0b1224] to-slate-900 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 p-0.5 shadow-md shadow-amber-500/20 shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center text-amber-400">
                <Bell className="w-5 h-5 fill-amber-400/20" />
              </div>
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <span>Official Announcements & Alerts</span>
                <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 text-[10px] font-mono font-bold">
                  {alerts.length}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Admin Panel ki taraf se bheje gaye tamam notices aur alerts
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alerts List Feed */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 scroll-smooth">
          {alerts.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center text-slate-500 space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600">
                <Bell className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-400">No new announcements</p>
              <p className="text-xs text-slate-600 max-w-xs">
                Jab bhi Admin panel se naya notice ya alert aayega, yahan ghanti baj kar show hoga.
              </p>
            </div>
          ) : (
            alerts.map((item) => (
              <div
                key={item.id}
                className="p-3.5 bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800 hover:border-amber-500/30 rounded-2xl shadow-md transition-all space-y-2"
              >
                {/* Meta Bar */}
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      <Crown className="w-3 h-3 text-amber-400" />
                      <span>{item.sender || 'Admin Official'}</span>
                    </span>
                    {getTagBadge(item.tag)}
                  </div>

                  <span className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3" />
                    <span>
                      {new Date(item.timestamp).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                      })}{' '}
                      at{' '}
                      {new Date(item.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </span>
                </div>

                {/* Title */}
                {item.title && (
                  <h4 className="text-sm font-bold text-white leading-snug">
                    {item.title}
                  </h4>
                )}

                {/* Message Body */}
                <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {item.text}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <button
            onClick={() => {
              playClickSound();
              onMarkAllRead();
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold border border-slate-800 cursor-pointer transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Mark All Read</span>
          </button>

          <div className="flex items-center gap-2">
            {isAdmin && onClearAll && (
              <button
                onClick={() => {
                  playClickSound();
                  if (confirm('Admin: Clear all alert notifications for everyone?')) {
                    onClearAll();
                  }
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-500/30 text-xs font-semibold cursor-pointer"
                title="Admin Clear All Alerts"
              >
                <Trash2 className="w-3 h-3 text-red-400" />
                <span className="hidden sm:inline">Clear All</span>
              </button>
            )}

            <button
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer active:scale-95"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
