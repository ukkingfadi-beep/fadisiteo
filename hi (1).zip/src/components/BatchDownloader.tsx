import React, { useState } from 'react';
import {
  ListOrdered,
  Play,
  Download,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';
import type { VideoInfoResponse, VideoFormatOption } from '../types/downloader';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';
import { playClickSound, playSuccessChime } from '../utils/sound';
import { canDownload, consumeDownload } from '../utils/quotaManager';

interface BatchItem {
  id: string;
  url: string;
  status: 'idle' | 'fetching' | 'success' | 'error';
  info?: VideoInfoResponse;
  error?: string;
  copied?: boolean;
}

interface BatchDownloaderProps {
  lang: Language;
  onDownloadStarted: (info: VideoInfoResponse, format: VideoFormatOption) => void;
  hasJoinedWhatsapp: boolean;
  onRequireWhatsappJoin: (pendingFormat: VideoFormatOption) => void;
  onRequireUpgrade?: () => void;
}

export const BatchDownloader: React.FC<BatchDownloaderProps> = ({
  lang,
  onDownloadStarted,
  hasJoinedWhatsapp,
  onRequireWhatsappJoin,
  onRequireUpgrade,
}) => {
  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState<BatchItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const t = translations[lang];

  const handleStartBatch = async () => {
    playClickSound();
    const lines = inputText
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.startsWith('http'));

    if (lines.length === 0) return;

    const newItems: BatchItem[] = lines.map((url, i) => ({
      id: `batch_${Date.now()}_${i}`,
      url,
      status: 'idle',
    }));

    setItems(newItems);
    setIsProcessing(true);

    // Process items in parallel batches
    for (let i = 0; i < newItems.length; i++) {
      const item = newItems[i];
      setItems((prev) =>
        prev.map((it) => (it.id === item.id ? { ...it, status: 'fetching' } : it))
      );

      try {
        const res = await fetch('/api/info', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: item.url }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to fetch video');
        }

        const data: VideoInfoResponse = await res.json();
        setItems((prev) =>
          prev.map((it) =>
            it.id === item.id ? { ...it, status: 'success', info: data } : it
          )
        );
        playSuccessChime();
      } catch (err: any) {
        setItems((prev) =>
          prev.map((it) =>
            it.id === item.id
              ? { ...it, status: 'error', error: err.message || 'Fetch failed' }
              : it
          )
        );
      }
    }

    setIsProcessing(false);
  };

  const handleClear = () => {
    playClickSound();
    setInputText('');
    setItems([]);
  };

  const handleCopyLink = (itemId: string, link: string) => {
    playClickSound();
    navigator.clipboard.writeText(link);
    setItems((prev) =>
      prev.map((it) => (it.id === itemId ? { ...it, copied: true } : it))
    );
    setTimeout(() => {
      setItems((prev) =>
        prev.map((it) => (it.id === itemId ? { ...it, copied: false } : it))
      );
    }, 2000);
  };

  const handleDownload = (info: VideoInfoResponse, format: VideoFormatOption) => {
    if (!hasJoinedWhatsapp) {
      onRequireWhatsappJoin(format);
      return;
    }

    if (!canDownload()) {
      if (onRequireUpgrade) {
        onRequireUpgrade();
      }
      return;
    }

    consumeDownload();

    playClickSound();
    onDownloadStarted(info, format);

    const cleanTitle = (info.title || 'video')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .substring(0, 50);
    const filename = `FADI_KING_${cleanTitle}_${format.qualityLabel.replace(/[\s\/\\]+/g, '_')}.${format.ext}`;

    const downloadLink = format.directUrl
      ? `/api/proxy-stream?url=${encodeURIComponent(format.directUrl)}&filename=${encodeURIComponent(filename)}`
      : `/api/download?url=${encodeURIComponent(info.originalUrl)}&formatId=${encodeURIComponent(format.formatId)}`;

    const a = document.createElement('a');
    a.href = downloadLink;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => document.body.removeChild(a), 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-8 bg-slate-900/90 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
      {/* Decorative top ambient glow */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-amber-400 to-emerald-500" />

      <div className="flex items-center justify-between pb-5 border-b border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <ListOrdered className="w-6 h-6 text-emerald-400" />
            <span>{t.batchQueueTitle}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">{t.batchQueueSub}</p>
        </div>
        <button
          onClick={handleClear}
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
          title={t.batchClear}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Input Textarea */}
      <div className="mt-5">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={t.batchPlaceholder}
          rows={4}
          className="w-full p-4 rounded-2xl bg-slate-950/80 border border-slate-800 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-white font-mono text-xs sm:text-sm placeholder-slate-500 resize-y outline-none transition-all leading-relaxed"
        />

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs text-slate-400">
            {inputText.split('\n').filter((l) => l.trim().startsWith('http')).length} URLs detected
          </span>

          <button
            onClick={handleStartBatch}
            disabled={isProcessing || !inputText.trim()}
            className={`px-6 py-3 rounded-xl font-black text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer ${
              isProcessing || !inputText.trim()
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-emerald-500 to-amber-500 hover:from-emerald-400 hover:to-amber-400 text-slate-950 shadow-lg shadow-emerald-500/20 active:scale-95'
            }`}
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing Queue...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{t.batchFetchAll}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Queue Items */}
      {items.length > 0 && (
        <div className="mt-8 space-y-4">
          <h3 className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase">
            Active Queue Items ({items.length})
          </h3>

          <div className="space-y-3">
            {items.map((item, idx) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </div>

                  {item.info?.thumbnailUrl && (
                    <img
                      src={item.info.thumbnailUrl}
                      alt={item.info.title}
                      className="w-12 h-12 object-cover rounded-xl border border-slate-700 shrink-0"
                    />
                  )}

                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm font-bold text-white truncate max-w-md">
                      {item.info?.title || item.url}
                    </p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                      <span className="capitalize text-emerald-400 font-medium">
                        {item.info?.platform || 'Detecting...'}
                      </span>
                      {item.info?.durationFormatted && (
                        <>
                          <span>·</span>
                          <span>{item.info.durationFormatted}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {item.status === 'fetching' && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Fetching...</span>
                    </div>
                  )}

                  {item.status === 'error' && (
                    <div className="flex items-center gap-1.5 text-xs text-red-400 font-medium px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{item.error || 'Failed'}</span>
                    </div>
                  )}

                  {item.status === 'success' && item.info && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopyLink(item.id, item.url)}
                        className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                        title="Copy Link"
                      >
                        {item.copied ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {item.info.formats.slice(0, 2).map((fmt) => (
                        <button
                          key={fmt.formatId}
                          onClick={() => handleDownload(item.info!, fmt)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{fmt.qualityLabel.split(' ')[0]}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
