import React, { useState } from 'react';
import {
  History,
  Trash2,
  Download,
  ExternalLink,
  Film,
  Search,
  FileDown,
  Sparkles,
} from 'lucide-react';
import type { DownloadHistoryItem } from '../types/downloader';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';
import { playClickSound } from '../utils/sound';

interface DownloadHistoryProps {
  history: DownloadHistoryItem[];
  lang: Language;
  onClearHistory: () => void;
  onReDownload: (item: DownloadHistoryItem) => void;
}

export const DownloadHistory: React.FC<DownloadHistoryProps> = ({
  history,
  lang,
  onClearHistory,
  onReDownload,
}) => {
  const [search, setSearch] = useState('');
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const t = translations[lang];

  if (history.length === 0) return null;

  const platforms = Array.from(new Set(history.map((h) => h.platform)));

  const filteredHistory = history.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.url.toLowerCase().includes(search.toLowerCase());
    const matchesPlatform =
      platformFilter === 'all' || item.platform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  const handleExportJson = () => {
    playClickSound();
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(history, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `FADI_KING_Media_Vault_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => document.body.removeChild(a), 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-12 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-7 backdrop-blur-2xl shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <History className="w-5 h-5 text-amber-400" />
          <h3 className="text-lg font-black text-white">{t.downloadHistory}</h3>
          <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-slate-800 text-amber-300 border border-slate-700">
            {history.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Export JSON Button */}
          <button
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
            title={t.exportHistory}
          >
            <FileDown className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.exportHistory}</span>
          </button>

          {/* Clear History Button */}
          <button
            onClick={() => {
              playClickSound();
              onClearHistory();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{t.clearHistory}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved videos..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400 transition-colors"
          />
        </div>

        {/* Platform filter tabs */}
        <div className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              playClickSound();
              setPlatformFilter('all');
            }}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              platformFilter === 'all'
                ? 'bg-amber-400 text-slate-950 font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.filterAll}
          </button>
          {platforms.map((p) => (
            <button
              key={p}
              onClick={() => {
                playClickSound();
                setPlatformFilter(p);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer whitespace-nowrap ${
                platformFilter === p
                  ? 'bg-amber-400 text-slate-950 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of History items */}
      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredHistory.map((item) => (
          <div
            key={item.id + item.downloadedAt}
            className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/40 transition-colors group"
          >
            <div className="w-14 h-14 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shrink-0 relative">
              {item.thumbnailUrl ? (
                <img
                  src={item.thumbnailUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-600">
                  <Film className="w-6 h-6" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                <span className="text-emerald-400 font-semibold capitalize">
                  {item.platform}
                </span>
                <span>·</span>
                <span>{item.quality}</span>
                <span>·</span>
                <span className="font-mono text-slate-500">
                  {new Date(item.downloadedAt).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                playClickSound();
                onReDownload(item);
              }}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-amber-400 border border-slate-800 hover:border-amber-400 transition-all cursor-pointer shrink-0"
              title="Download Again"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
