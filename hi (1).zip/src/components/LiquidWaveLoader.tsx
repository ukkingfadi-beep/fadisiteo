import React, { useState, useEffect, useRef } from 'react';

interface LiquidWaveLoaderProps {
  onComplete: () => void;
  brandName?: string;
}

export const LiquidWaveLoader: React.FC<LiquidWaveLoaderProps> = ({
  onComplete,
  brandName = 'FADI KING',
}) => {
  const [percent, setPercent] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [statusText, setStatusText] = useState('CONNECTING TO 8K VIP ENGINE...');
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    const startTime = Date.now();
    const duration = 1200; // Fast 1.2s sleek cinematic loading

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, Math.floor((elapsed / duration) * 100));

      setPercent(progress);

      if (progress < 30) {
        setStatusText('CONNECTING TO 8K VIP ENGINE...');
      } else if (progress < 60) {
        setStatusText('LIGHTNING MEDIA PIPELINE READY...');
      } else if (progress < 95) {
        setStatusText('CALIBRATING DIRECT EXTRACTOR...');
      } else {
        setStatusText('WELCOME TO FADI KING VIP');
      }

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            onCompleteRef.current?.();
          }, 250);
        }, 150);
      }
    }, 20);

    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-black text-white transition-opacity duration-700 select-none overflow-hidden ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        backgroundColor: '#000000',
        fontFamily: '"Montserrat", "Cinzel", "Segoe UI", sans-serif',
      }}
    >
      {/* Ambient background glow effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-tr from-amber-500/10 via-yellow-600/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-gradient-to-br from-amber-400/15 via-white/5 to-transparent rounded-full blur-2xl pointer-events-none" />

      {/* Grid line watermark background */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.2) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="relative z-10 flex flex-col items-center justify-center px-6 w-full max-w-md text-center">
        {/* Crown / VIP Emblem */}
        <div className="mb-4 relative flex items-center justify-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-neutral-900 via-neutral-950 to-black border border-amber-500/40 flex items-center justify-center shadow-[0_0_35px_rgba(212,175,55,0.25)]">
            <svg
              className="w-8 h-8 text-amber-400 drop-shadow-[0_2px_8px_rgba(251,191,36,0.6)] animate-pulse"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z" />
            </svg>
          </div>
          {/* Subtle spinning ring */}
          <div className="absolute -inset-1.5 rounded-2xl border border-amber-500/20 border-dashed animate-spin" style={{ animationDuration: '14s' }} />
        </div>

        {/* FADI KING Animated Brand Typography */}
        <div className="relative mb-2">
          <h1
            className="text-3xl sm:text-4xl md:text-5xl font-black tracking-[0.28em] uppercase text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-100 drop-shadow-[0_4px_20px_rgba(251,191,36,0.35)]"
            style={{
              letterSpacing: '0.28em',
              textShadow: '0 0 25px rgba(245, 158, 11, 0.45)',
            }}
          >
            {brandName}
          </h1>
          <div className="flex items-center justify-center gap-2 mt-1.5">
            <span className="h-[1px] w-6 bg-gradient-to-r from-transparent to-amber-500/60" />
            <p className="text-[10px] sm:text-[11px] font-bold tracking-[0.45em] uppercase text-amber-300/80">
              ROYAL 8K MEDIA ENGINE
            </p>
            <span className="h-[1px] w-6 bg-gradient-to-l from-transparent to-amber-500/60" />
          </div>
        </div>

        {/* Dynamic Percentage Counter */}
        <div className="my-6 relative flex items-baseline justify-center">
          <span className="text-6xl sm:text-7xl font-black font-mono tracking-tighter text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.4)]">
            {percent}
          </span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-amber-400 ml-1">
            %
          </span>
        </div>

        {/* Dynamic Counting Line (Progress Bar with scanning light sweep) */}
        <div className="w-full max-w-xs sm:max-w-sm">
          {/* Outer glowing track */}
          <div className="relative w-full h-2 rounded-full bg-neutral-900 border border-white/10 p-0.5 overflow-hidden shadow-[inset_0_1px_3px_rgba(0,0,0,0.8)]">
            {/* The animated fill line */}
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300 transition-all duration-100 ease-out relative shadow-[0_0_14px_rgba(251,191,36,0.8)]"
              style={{ width: `${percent}%` }}
            >
              {/* Shimmer light sweep running over the line */}
              <div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/70 to-transparent animate-shimmer"
                style={{
                  backgroundSize: '200% 100%',
                }}
              />
            </div>
          </div>

          {/* Status Subtitle below counting line */}
          <div className="flex items-center justify-between mt-3 text-[10px] font-mono tracking-wider text-neutral-400 px-1">
            <span className="text-amber-400/90 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>{statusText}</span>
            </span>
            <span className="text-neutral-500">{percent}/100</span>
          </div>
        </div>

        {/* 1-Tap Skip button for quick testing */}
        <button
          type="button"
          onClick={() => {
            setIsFadingOut(true);
            setTimeout(onComplete, 250);
          }}
          className="mt-8 text-[11px] uppercase tracking-[0.25em] text-neutral-500 hover:text-amber-300 transition-colors cursor-pointer py-1 px-3 rounded-full hover:bg-white/5 border border-transparent hover:border-white/10"
        >
          Skip Loading →
        </button>
      </div>
    </div>
  );
};
