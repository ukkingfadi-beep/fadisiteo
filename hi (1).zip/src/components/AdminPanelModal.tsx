import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Lock,
  KeyRound,
  X,
  Copy,
  Check,
  PlusCircle,
  RefreshCw,
  Trash2,
  Search,
  MessageSquare,
  AlertCircle,
  Crown,
  Palette,
  Music2,
  Sliders,
  Settings,
  Sparkles,
  Play,
  Pause,
  Volume2,
  Radio,
  CheckCircle2,
  Save,
  Tv,
  Image as ImageIcon,
  Video,
  Eye,
  EyeOff,
  Clock,
  ShieldAlert,
  Users,
  UserCheck,
  UserX,
  Ban,
  Bell,
  Send,
  Layout,
  Move,
  Layers,
  Volume1,
  Upload,
  Flame,
  Star,
  Trophy,
  Headphones,
  Mic,
  Disc,
  ShoppingBag,
  ArrowDownToLine,
  Zap,
  Gem,
  Package,
  ListOrdered,
} from 'lucide-react';
import { Language, translations } from '../utils/translations';
import {
  adminLogin,
  fetchAdminLicenses,
  adminGenerateCode,
  adminDeleteLicense,
  UPGRADE_PRICE_PKR,
} from '../utils/quotaManager';
import {
  THEME_PRESETS,
  HOBBY_TRACKS,
  ThemePreset,
  AnimationThemeType,
  IconStyleType,
  SiteConfigState,
  getLocalConfig,
  saveLocalConfig,
  updateServerConfig,
  purgeCacheAndSync,
  DEFAULT_SHOWCASE_SLIDES,
  DEFAULT_ITEM_ICONS,
  ShowcaseSlide,
  ItemIconsConfig,
} from '../utils/themeAndConfigManager';
import {
  playAmbientTune,
  stopAmbientTune,
  isAmbientPlaying,
} from '../utils/ambientMusicPlayer';
import { playSound, playAlertTune, NotificationTuneType } from '../utils/sound';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  currentConfig: SiteConfigState;
  onConfigUpdated: (config: SiteConfigState) => void;
}

interface LicenseItem {
  id: string;
  email: string;
  code: string;
  createdAt: string;
  status: 'active' | 'revoked';
  plan: string;
  price: string;
  redeemedCount?: number;
}

interface RegisteredMemberItem {
  username: string;
  avatarUrl?: string;
  isLifetimeVip: boolean;
  vipEmail?: string;
  isBlocked: boolean;
  joinedAt: string;
  lastActiveAt: string;
  messageCount: number;
}

const BG_PHOTO_PRESETS = [
  { name: 'Cyber City Night', url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80' },
  { name: 'Royal Gold Abstract', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80' },
  { name: 'Deep Space Galaxy', url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1920&q=80' },
  { name: 'Dark Velvet Shimmer', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=1920&q=80' },
];

const BG_VIDEO_PRESETS = [
  { name: 'Dark Particles Loop', url: 'https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-starfield-in-space-12792-large.mp4' },
  { name: 'Cyber Wave Mesh', url: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31911-large.mp4' },
];

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  lang,
  currentConfig,
  onConfigUpdated,
}) => {
  const t = translations[lang];

  // Auth state & Security Lockout
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [lockoutSeconds, setLockoutSeconds] = useState<number>(0);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);

  // Active Tab
  const [activeTab, setActiveTab] = useState<
    'theme' | 'icons' | 'screen' | 'layout' | 'chat_security' | 'alerts' | 'audio' | 'features' | 'licenses' | 'members'
  >('theme');
  const [activeSlideIdx, setActiveSlideIdx] = useState<number>(0);
  const [uploadingSlideIdx, setUploadingSlideIdx] = useState<number | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadStatusMsg, setUploadStatusMsg] = useState<string>('');
  const activeUploadXhr = useRef<XMLHttpRequest | null>(null);

  // Broadcast Alerts & Sound System State
  const [alertsList, setAlertsList] = useState<any[]>([]);
  const [alertTitle, setAlertTitle] = useState('');
  const [alertText, setAlertText] = useState('');
  const [alertTag, setAlertTag] = useState<'alert' | 'update' | 'offer' | 'notice'>('alert');
  const [alertTune, setAlertTune] = useState<NotificationTuneType>('tung_tung');
  const [alertPopup, setAlertPopup] = useState<boolean>(true);
  const [sendingAlert, setSendingAlert] = useState(false);
  const [alertSuccess, setAlertSuccess] = useState(false);

  // Licensing state
  const [licenses, setLicenses] = useState<LicenseItem[]>([]);
  const [loadingLicenses, setLoadingLicenses] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [genLoading, setGenLoading] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [generatedCode, setGeneratedCode] = useState<LicenseItem | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedMsg, setCopiedMsg] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Members & Chat Moderation State (Track who joined, VIP vs Free, Block/Unblock)
  const [members, setMembers] = useState<RegisteredMemberItem[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [memberFilter, setMemberFilter] = useState<'all' | 'vip' | 'free' | 'blocked'>('all');
  const [actionLoadingUser, setActionLoadingUser] = useState<string | null>(null);

  // Editable Site Config Form State
  const [configDraft, setConfigDraft] = useState<SiteConfigState>(currentConfig);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [testMusicPlaying, setTestMusicPlaying] = useState(false);

  // Live Background Upload State
  const [uploadingBg, setUploadingBg] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [animSyncToast, setAnimSyncToast] = useState<string | null>(null);
  const [purgingCache, setPurgingCache] = useState(false);
  const [cachePurgedMsg, setCachePurgedMsg] = useState<string | null>(null);
  const bgFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setConfigDraft((prev) => {
        if (JSON.stringify(prev) === JSON.stringify(currentConfig)) return prev;
        return currentConfig;
      });
    }
  }, [isOpen, currentConfig]);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutSeconds > 0) {
      const timer = window.setInterval(() => {
        setLockoutSeconds((prev) => (prev <= 1 ? 0 : prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [lockoutSeconds]);

  // Load licenses on auth
  const loadLicenses = async (pwd: string) => {
    setLoadingLicenses(true);
    try {
      const data = await fetchAdminLicenses(pwd);
      if (data.licenses) {
        setLicenses(data.licenses);
      }
    } catch (err: any) {
      console.error('Error fetching admin licenses:', err);
    } finally {
      setLoadingLicenses(false);
    }
  };

  // Load all registered members & chat users directory
  const loadMembers = async (pwd: string) => {
    setLoadingMembers(true);
    try {
      const res = await fetch('/api/admin/members', {
        headers: {
          'x-admin-password': pwd,
        },
      });
      const data = await res.json();
      if (data.members) {
        setMembers(data.members);
      }
    } catch (err: any) {
      console.error('Error fetching admin members directory:', err);
    } finally {
      setLoadingMembers(false);
    }
  };

  // 1-Click Block/Unblock user moderation
  const handleToggleBlockUser = async (targetUsername: string, currentlyBlocked: boolean) => {
    setActionLoadingUser(targetUsername);
    playSound('click');
    try {
      const endpoint = currentlyBlocked ? '/api/admin/unblock-user' : '/api/admin/block-user';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': password,
        },
        body: JSON.stringify({ username: targetUsername }),
      });
      const data = await res.json();
      if (data.success) {
        playSound(currentlyBlocked ? 'unlock' : 'error');
        setMembers((prev) =>
          prev.map((m) =>
            m.username.toLowerCase() === targetUsername.toLowerCase()
              ? { ...m, isBlocked: !currentlyBlocked }
              : m
          )
        );
      } else {
        alert(data.error || 'Failed to update user status');
      }
    } catch (err) {
      console.error('Error toggling user block status:', err);
    } finally {
      setActionLoadingUser(null);
    }
  };

  const loadAlerts = async () => {
    try {
      const res = await fetch('/api/alerts');
      const data = await res.json();
      if (data.alerts) setAlertsList(data.alerts);
    } catch (err) {
      console.warn('Could not load alerts list:', err);
    }
  };

  const handleSendBroadcastAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!alertText.trim()) return;
    setSendingAlert(true);
    playSound('click');
    try {
      const res = await fetch('/api/admin/broadcast-alert', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': password,
        },
        body: JSON.stringify({
          title: alertTitle.trim() || '📢 Official Notification',
          text: alertText.trim(),
          tag: alertTag,
          soundTune: alertTune,
          popup: alertPopup,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        playAlertTune(alertTune);
        setAlertTitle('');
        setAlertText('');
        setAlertSuccess(true);
        setTimeout(() => setAlertSuccess(false), 3500);
        loadAlerts();
      } else {
        alert(data.error || 'Failed to send alert broadcast.');
      }
    } catch {
      alert('Network error while sending broadcast alert.');
    } finally {
      setSendingAlert(false);
    }
  };

  const handleDeleteAlert = async (id: string) => {
    playSound('click');
    try {
      const res = await fetch(`/api/admin/alert/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: { 'x-admin-password': password },
      });
      if (res.ok) {
        setAlertsList((prev) => prev.filter((a) => a.id !== id));
      }
    } catch {}
  };

  const handleClearAllAlerts = async () => {
    if (!confirm('Clear all broadcast alert notifications for everyone?')) return;
    playSound('click');
    try {
      await fetch('/api/admin/clear-alerts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': password,
        },
      });
      setAlertsList([]);
    } catch {}
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutSeconds > 0 || isVerifying) return;

    setAuthError(null);
    playSound('click');

    const cleanPass = password.trim();
    if (!cleanPass) {
      setAuthError('Barah-e-karam admin password enter karein.');
      return;
    }

    setIsVerifying(true);
    try {
      const result = await adminLogin(cleanPass);
      if (result.success) {
        setIsAuthenticated(true);
        setFailedAttempts(0);
        try {
          localStorage.setItem('fadiking_admin_password', cleanPass);
        } catch {}
        playSound('unlock');
        loadLicenses(cleanPass);
        loadMembers(cleanPass);
        loadAlerts();
      } else {
        const nextFail = failedAttempts + 1;
        setFailedAttempts(nextFail);
        const waitTime = nextFail >= 2 ? 45 : 30;
        setLockoutSeconds(waitTime);
        setAuthError(
          result.error ||
            `Ghalat Password! Barah-e-karam durust admin password enter karein. (${waitTime} seconds lockout)`
        );
        playSound('error');
      }
    } catch {
      playSound('error');
      setAuthError('Server se rabta nahi ho saka. Barah-e-karam dobara koshish karein.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleUploadBackgroundFile = (file: File) => {
    if (!file) return;
    if (file.size > 55 * 1024 * 1024) {
      setUploadError('File size is too large (max 55MB). Please choose a smaller image or compressed video.');
      playSound('error');
      return;
    }

    setUploadingBg(true);
    setUploadError(null);
    setUploadSuccess(null);
    playSound('click');

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64Data = e.target?.result as string;
      if (!base64Data) {
        setUploadingBg(false);
        setUploadError('Could not read file data.');
        return;
      }

      const isVideo = file.type.startsWith('video/') || /\.(mp4|webm|mov|ogg|m4v)$/i.test(file.name);
      const targetBgType: 'video' | 'image' = isVideo ? 'video' : 'image';

      try {
        const res = await fetch('/api/admin/upload-background', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-password': password,
          },
          body: JSON.stringify({
            fileData: base64Data,
            fileName: file.name,
            fileType: targetBgType,
            autoApply: true,
          }),
        });

        const data = await res.json();
        if (res.ok && data.success) {
          playSound('success');
          setUploadSuccess(`🎉 Background ${targetBgType === 'video' ? 'Video' : 'Photo'} is now LIVE on website!`);

          const updatedTheme = {
            ...configDraft.theme,
            bgType: data.bgType as 'image' | 'video',
            bgMediaUrl: data.url,
            bgOverlayOpacity: configDraft.theme.bgOverlayOpacity ?? 0.40,
          };
          const newConfig: SiteConfigState = {
            ...configDraft,
            theme: updatedTheme,
          };
          setConfigDraft(newConfig);
          saveLocalConfig(newConfig);
          if (typeof window !== 'undefined') {
            localStorage.setItem('fadiking_bg_media_url', data.url);
            localStorage.setItem('fadiking_bg_type', data.bgType);
          }
          onConfigUpdated(data.config || newConfig);
          setTimeout(() => setUploadSuccess(null), 6000);
        } else {
          playSound('error');
          setUploadError(data.error || 'Failed to upload background media.');
        }
      } catch (err: any) {
        console.error('Error uploading background:', err);
        playSound('error');
        setUploadError('Network error while uploading background.');
      } finally {
        setUploadingBg(false);
      }
    };

    reader.onerror = () => {
      setUploadingBg(false);
      playSound('error');
      setUploadError('Could not process file.');
    };

    reader.readAsDataURL(file);
  };

  const handleForceApplyBackground = async (mediaUrl: string, mediaType: 'image' | 'video') => {
    if (!mediaUrl.trim()) return;
    playSound('click');
    setUploadError(null);
    setUploadSuccess(null);

    const updatedConfig: SiteConfigState = {
      ...configDraft,
      theme: {
        ...configDraft.theme,
        bgType: mediaType,
        bgMediaUrl: mediaUrl.trim(),
        bgOverlayOpacity: configDraft.theme.bgOverlayOpacity ?? 0.40,
      },
    };

    setConfigDraft(updatedConfig);
    saveLocalConfig(updatedConfig);
    if (typeof window !== 'undefined') {
      localStorage.setItem('fadiking_bg_media_url', mediaUrl.trim());
      localStorage.setItem('fadiking_bg_type', mediaType);
    }

    try {
      const res = await updateServerConfig(password, updatedConfig);
      if (res.success) {
        playSound('success');
        onConfigUpdated(updatedConfig);
        setUploadSuccess(`🎉 Background ${mediaType === 'video' ? 'Video' : 'Photo'} is now LIVE on website!`);
        setTimeout(() => setUploadSuccess(null), 5000);
      } else {
        playSound('error');
        setUploadError(res.error || 'Failed to set live background.');
      }
    } catch {
      playSound('error');
      setUploadError('Network error while updating background.');
    }
  };

  const handleResetBackgroundToColor = async () => {
    playSound('click');
    setUploadError(null);
    setUploadSuccess(null);

    const updatedConfig: SiteConfigState = {
      ...configDraft,
      theme: {
        ...configDraft.theme,
        bgType: 'color',
        bgMediaUrl: '',
      },
    };

    setConfigDraft(updatedConfig);
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('fadiking_bg_media_url');
        localStorage.removeItem('fadiking_bg_type');
      } catch {}
    }

    try {
      const res = await updateServerConfig(password, updatedConfig);
      if (res.success) {
        playSound('success');
        onConfigUpdated(updatedConfig);
        setUploadSuccess('Default Royal Obsidian Brown & Gold background restored live!');
        setTimeout(() => setUploadSuccess(null), 4000);
      }
    } catch {
      playSound('error');
    }
  };

  const handlePurgeAllCache = async () => {
    playSound('click');
    setPurgingCache(true);
    setCachePurgedMsg(null);
    try {
      const res = await purgeCacheAndSync(password);
      if (res.success) {
        playSound('success');
        setCachePurgedMsg('⚡ کیش کلیئر ہو گیا! (Cache Purged) Server, Cloudflare CDN اور تمام براؤزرز کی کیش تازہ ہو گئی ہے۔');
        setTimeout(() => setCachePurgedMsg(null), 6000);
      } else {
        playSound('error');
        alert(res.message || 'Cache purge failed.');
      }
    } catch {
      playSound('error');
    } finally {
      setPurgingCache(false);
    }
  };

  const handleSelectAnimationTheme = async (themeId: AnimationThemeType, themeName?: string) => {
    playSound('click');
    const updatedTheme = { ...configDraft.theme, animationTheme: themeId };
    const updatedConfig: SiteConfigState = { ...configDraft, theme: updatedTheme };
    setConfigDraft(updatedConfig);
    onConfigUpdated(updatedConfig);
    saveLocalConfig(updatedConfig);
    setAnimSyncToast(themeName ? `"${themeName}" website par live update ho gaya!` : 'Theme live update ho gaya!');
    setTimeout(() => setAnimSyncToast(null), 4000);
    try {
      const res = await updateServerConfig(password, updatedConfig);
      if (res.success) {
        playSound('success');
      }
    } catch (err) {
      console.warn('Auto-save animation theme failed:', err);
    }
  };

  const handleSaveConfig = async () => {
    setSaveStatus('saving');
    playSound('click');

    try {
      const res = await updateServerConfig(password, configDraft);
      if (res.success) {
        setSaveStatus('saved');
        playSound('success');
        onConfigUpdated(configDraft);
        setTimeout(() => setSaveStatus('idle'), 2500);
      } else {
        setSaveStatus('error');
        playSound('error');
      }
    } catch {
      setSaveStatus('error');
      playSound('error');
    }
  };

  const handleClearChatHistory = async () => {
    if (!confirm('Are you sure you want to clear all community live chat messages?')) return;
    playSound('click');
    try {
      await fetch('/api/admin/clear-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': password,
        },
      });
      playSound('success');
      alert('Live chat board cleared successfully.');
    } catch (e) {
      playSound('error');
    }
  };

  const handleSelectPreset = (presetKey: ThemePreset) => {
    playSound('click');
    const preset = THEME_PRESETS[presetKey];
    if (preset) {
      setConfigDraft((prev) => ({
        ...prev,
        theme: {
          ...prev.theme,
          ...preset,
        },
      }));
    }
  };

  const handleToggleTestMusic = () => {
    playSound('click');
    if (testMusicPlaying) {
      stopAmbientTune();
      setTestMusicPlaying(false);
    } else {
      playAmbientTune(
        configDraft.audio.selectedTrackId,
        configDraft.audio.volume,
        configDraft.audio.customTrackUrl
      );
      setTestMusicPlaying(true);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim()) {
      setGenError('Please enter a valid customer email address.');
      return;
    }

    setGenLoading(true);
    setGenError(null);
    setGeneratedCode(null);
    playSound('click');

    try {
      const data = await adminGenerateCode(password, newEmail.trim());
      setGeneratedCode(data.license);
      setNewEmail('');
      playSound('success');
      loadLicenses(password);
    } catch (err: any) {
      setGenError(err?.message || 'Failed to generate code.');
      playSound('error');
    } finally {
      setGenLoading(false);
    }
  };

  const handleDelete = async (licenseId: string) => {
    if (!confirm('Are you sure you want to revoke this license?')) return;
    playSound('click');
    const ok = await adminDeleteLicense(password, licenseId);
    if (ok) {
      loadLicenses(password);
    }
  };

  const copyCodeOnly = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    playSound('click');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyWhatsAppMessage = (item: LicenseItem) => {
    const text = `Assalam-o-Alaikum! Your FADI KING Lifetime VIP Plan has been approved.

👑 Activation Code: ${item.code}
📧 Registered Email: ${item.email}
💎 Price: ${configDraft.features.planPricePKR} (Lifetime Unlimited)

Open the website, click "Upgrade Plan", enter your email & activation code to unlock unlimited downloads forever!`;

    navigator.clipboard.writeText(text);
    setCopiedMsg(true);
    playSound('click');
    setTimeout(() => setCopiedMsg(false), 2500);
  };

  if (!isOpen) return null;

  const filteredLicenses = licenses.filter(
    (lic) =>
      lic.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lic.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/90 backdrop-blur-xl overflow-hidden">
      <div className="relative w-full max-w-5xl h-[95vh] max-h-[95vh] flex flex-col bg-[#080d1a] border border-amber-500/40 rounded-3xl shadow-2xl shadow-amber-950/50 text-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Sticky Pinned Header */}
        <div className="shrink-0 z-30 border-b border-slate-800 bg-[#0c1222] px-4 py-3 sm:px-6 sm:py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-500 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-[#080d1a] rounded-[14px] flex items-center justify-center text-amber-400">
                <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>FADI KING Master Control Suite</span>
              </h2>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Full control over animated themes, background video/photo, live screen updates, and VIP codes.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isAuthenticated && (
              <>
                <button
                  type="button"
                  onClick={handlePurgeAllCache}
                  disabled={purgingCache}
                  className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-[10px] sm:text-[11px] font-bold cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                  title="Purge Server, Cloudflare CDN, and Browser Caches"
                >
                  <RefreshCw className={`w-3 h-3 ${purgingCache ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Purge Cache & Sync</span>
                  <span className="sm:hidden">Clear Cache</span>
                </button>

                <div className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-[10px] sm:text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-slate-300 hidden sm:inline">Admin:</span>
                  <span className="font-mono font-bold text-emerald-300">Active ⚡</span>
                </div>
              </>
            )}
            <button
              onClick={() => {
                playSound('click');
                if (testMusicPlaying) stopAmbientTune();
                onClose();
              }}
              className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Cache Purge Feedback Banner */}
        {cachePurgedMsg && (
          <div className="shrink-0 bg-emerald-950/80 border-b border-emerald-500/40 px-4 py-2 text-center text-xs text-emerald-200 font-bold flex items-center justify-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{cachePurgedMsg}</span>
          </div>
        )}

        {/* Sticky Pinned Navigation Tabs Bar (Visible when authenticated) */}
        {isAuthenticated && (
          <div className="shrink-0 z-20 border-b border-slate-800/80 bg-black/85 backdrop-blur-md px-3 sm:px-5 py-2 overflow-x-auto no-scrollbar flex items-center gap-1.5">
            <button
              onClick={() => {
                playSound('click');
                setActiveTab('theme');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'theme'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Theme & Wallpapers</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('icons');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'icons'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>🎨 Icon & Item Studio</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('screen');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'screen'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Tv className="w-3.5 h-3.5 text-cyan-400" />
              <span>🎬 Live Showcase Screen</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('layout');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'layout'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layout className="w-3.5 h-3.5" />
              <span>Layout & Positions</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('chat_security');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'chat_security'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Chatbot & Security</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('alerts');
                loadAlerts();
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'alerts'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Alerts System 🔔</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('audio');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'audio'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Music2 className="w-3.5 h-3.5" />
              <span>Audio & Tunes</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('features');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'features'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Website Controls</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('licenses');
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'licenses'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>VIP Codes ({licenses.length})</span>
            </button>

            <button
              onClick={() => {
                playSound('click');
                setActiveTab('members');
                if (password) {
                  loadMembers(password);
                }
              }}
              className={`shrink-0 py-2 px-3 sm:px-3.5 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'members'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Members ({members.length})</span>
            </button>
          </div>
        )}

        {/* Scrollable Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6">
        {/* Screen 1: Password-Only Admin Verification Gate */}
        {!isAuthenticated ? (
          <div className="max-w-md mx-auto py-8 sm:py-12 px-4 text-center space-y-6 animate-in fade-in">
            {/* Emblem */}
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500/20 via-yellow-500/10 to-amber-600/20 border border-amber-500/40 mx-auto flex items-center justify-center text-amber-400 shadow-2xl shadow-amber-500/10">
              {lockoutSeconds > 0 ? (
                <ShieldAlert className="w-10 h-10 text-red-400 animate-pulse" />
              ) : (
                <Lock className="w-10 h-10 text-amber-400 drop-shadow-[0_2px_10px_rgba(245,158,11,0.5)]" />
              )}
            </div>

            {/* Title & Info */}
            <div className="space-y-1.5">
              <h3 className="text-2xl font-black text-white tracking-tight">
                Admin Panel Login
              </h3>
              <p className="text-xs text-slate-300">
                ایڈمن پینل کھولنے کے لیے پاس ورڈ درج کریں اور ویریفائی کر کے لاگ ان کریں۔
              </p>
            </div>

            {/* Lockout Countdown Warning */}
            {lockoutSeconds > 0 && (
              <div className="p-4 bg-red-950/70 border border-red-500/60 rounded-2xl text-center space-y-1.5 animate-in zoom-in-95">
                <span className="flex items-center justify-center gap-1.5 text-red-300 font-bold text-xs uppercase tracking-wider">
                  <Clock className="w-4 h-4 animate-spin" />
                  <span>Security Lockout Active</span>
                </span>
                <p className="text-2xl font-mono font-black text-white">
                  {lockoutSeconds}s
                </p>
                <p className="text-[11px] text-red-200">
                  Multiple wrong password attempts. Please wait for the timer to expire.
                </p>
              </div>
            )}

            {/* Password Login Form */}
            <form
              onSubmit={handleLogin}
              className="p-5 sm:p-6 bg-gradient-to-b from-neutral-900/90 via-black to-neutral-950/90 border border-amber-500/30 rounded-3xl text-left space-y-4 shadow-2xl backdrop-blur-xl"
            >
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                  <span>Admin Password (ایڈمن پاس ورڈ):</span>
                  <span className="text-[10px] text-amber-400/80 font-mono">Protected</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    disabled={lockoutSeconds > 0 || isVerifying}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={lockoutSeconds > 0 ? `Locked for ${lockoutSeconds}s...` : 'Enter confidential admin password...'}
                    autoFocus
                    className="w-full px-4 py-3.5 pr-12 bg-black/80 border border-slate-700 focus:border-amber-400 focus:ring-2 focus:ring-amber-500/20 rounded-2xl text-sm text-white placeholder-slate-500 outline-none font-mono transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors cursor-pointer p-1"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {authError && lockoutSeconds === 0 && (
                <div className="p-3 bg-red-950/80 border border-red-500/50 rounded-2xl text-xs text-red-200 flex items-center gap-2.5 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span className="leading-relaxed">{authError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={lockoutSeconds > 0 || isVerifying}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black rounded-2xl transition-all shadow-xl shadow-amber-500/20 cursor-pointer active:scale-98 disabled:opacity-40 disabled:cursor-not-allowed text-xs sm:text-sm flex items-center justify-center gap-2 tracking-wide uppercase"
              >
                {isVerifying ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Verifying Password...</span>
                  </>
                ) : (
                  <>
                    <KeyRound className="w-4 h-4 text-slate-950" />
                    <span>Verify & Login (تصدیق اور لاگ ان)</span>
                  </>
                )}
              </button>
            </form>
          </div>
        ) : (

          /* Screen 2: Master Control Suite Active Tab Body */
          <div className="space-y-6">

            {/* TAB 1: Themes, 3D Icon Studio & Background Photo/Video */}
            {activeTab === 'theme' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                {/* 0. Advanced Icon & Visual Studio */}
                <div className="p-4 bg-black/40 border border-[#d4af37]/30 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black text-white flex items-center gap-2">
                        <Crown className="w-4 h-4 text-[#d4af37]" />
                        <span>Icon Style Studio (2D / 3D Metallic / Animated / Glassmorphic)</span>
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Switch all website icons between 3D luxury gold, clean 2D outlines, floating shimmers, or glassmorphic gradients.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { id: '3d', name: '3D Metallic Gold Emboss', desc: 'Regal specular drop-shadow & 3D bevels' },
                      { id: '2d', name: '2D Minimalist Clean Outline', desc: 'Precision stroke lines with high contrast' },
                      { id: 'animated', name: 'Animated Shimmer & Float', desc: 'Continuous floating micro-animations' },
                      { id: 'colorful_glass', name: 'Colorful Glassmorphism', desc: 'Translucent frosted gradient backing' },
                    ].map((style) => (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => {
                          playSound('click');
                          setConfigDraft((prev) => ({
                            ...prev,
                            theme: { ...prev.theme, iconStyle: style.id as IconStyleType },
                          }));
                        }}
                        className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                          (configDraft.theme.iconStyle || '3d') === style.id
                            ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border-[#d4af37] text-white ring-1 ring-[#d4af37]'
                            : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                          <span>{style.name}</span>
                          {(configDraft.theme.iconStyle || '3d') === style.id && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37]" />
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 leading-tight">{style.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 1. Animation Themes with Rich Animated Server Icons & 1-Click Instant Sync */}
                <div className="p-4 sm:p-5 bg-gradient-to-b from-neutral-900/80 via-black to-neutral-950/80 border border-amber-500/30 rounded-2xl space-y-3.5 shadow-xl">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Live Website Animation Themes (Server Shaders)</span>
                        <span className="px-2 py-0.5 text-[10px] bg-amber-400/20 text-amber-300 rounded-full border border-amber-400/40 font-mono">
                          REAL-TIME SYNC
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Different server animations for website background. Click any card to apply live on the website and save on server.
                      </p>
                    </div>

                    {animSyncToast && (
                      <div className="px-3 py-1.5 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in shrink-0">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span>{animSyncToast}</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {[
                      {
                        id: 'royal_gold_shimmer',
                        name: 'Royal Gold Shimmer',
                        tag: 'Regal Gold Particles',
                        desc: 'Luminous metallic golden dust & warm cognac pulses floating across the screen.',
                        icon: Crown,
                        badgeColor: 'text-amber-400 bg-amber-500/15 border-amber-500/30',
                        activeBorder: 'border-amber-400 ring-2 ring-amber-400/50 bg-amber-950/25',
                        iconGlow: 'text-amber-400',
                      },
                      {
                        id: 'cyber_matrix',
                        name: 'Cyber Matrix Grid',
                        tag: 'Digital Matrix Grid',
                        desc: 'Electric cyan matrix scanlines with deep blue futuristic perspective glow.',
                        icon: Zap,
                        badgeColor: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30',
                        activeBorder: 'border-cyan-400 ring-2 ring-cyan-400/50 bg-cyan-950/25',
                        iconGlow: 'text-cyan-400',
                      },
                      {
                        id: 'cosmic_nebula',
                        name: 'Deep Cosmic Nebula',
                        tag: 'Celestial Galaxy Dust',
                        desc: 'Ethereal celestial violet orbs and deep space galaxy starlight dust.',
                        icon: Flame,
                        badgeColor: 'text-purple-400 bg-purple-500/15 border-purple-500/30',
                        activeBorder: 'border-purple-400 ring-2 ring-purple-400/50 bg-purple-950/25',
                        iconGlow: 'text-purple-400',
                      },
                      {
                        id: 'neon_synthwave',
                        name: 'Neon Synthwave Horizon',
                        tag: '3D Laser Horizon',
                        desc: 'Dynamic 3D perspective retro laser ground with sunset pink horizon pulses.',
                        icon: Move,
                        badgeColor: 'text-rose-400 bg-rose-500/15 border-rose-500/30',
                        activeBorder: 'border-rose-400 ring-2 ring-rose-400/50 bg-rose-950/25',
                        iconGlow: 'text-rose-400',
                      },
                      {
                        id: 'quantum_waves',
                        name: 'Quantum Waves Matrix',
                        tag: 'Emerald Energy Wave',
                        desc: 'Pulsating emerald wave lines and quantum electromagnetic aura.',
                        icon: Radio,
                        badgeColor: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30',
                        activeBorder: 'border-emerald-400 ring-2 ring-emerald-400/50 bg-emerald-950/25',
                        iconGlow: 'text-emerald-400',
                      },
                      {
                        id: 'crystal_aurora',
                        name: 'Crystal Aurora Borealis',
                        tag: 'Prismatic Shimmer',
                        desc: 'Multicolor shifting chromatic caustics with starlight diamond glints.',
                        icon: Gem,
                        badgeColor: 'text-sky-300 bg-sky-500/15 border-sky-400/30',
                        activeBorder: 'border-sky-400 ring-2 ring-sky-400/50 bg-sky-950/25',
                        iconGlow: 'text-sky-300',
                      },
                      {
                        id: 'clean_slate',
                        name: 'Graphite Minimalist Glass',
                        tag: 'Dark Clean Obsidian',
                        desc: 'Understated dark matte glass without dynamic particles for quiet focus.',
                        icon: ShieldCheck,
                        badgeColor: 'text-slate-300 bg-slate-700/20 border-slate-600/30',
                        activeBorder: 'border-slate-400 ring-2 ring-slate-400/50 bg-slate-900/40',
                        iconGlow: 'text-slate-300',
                      },
                    ].map((anim) => {
                      const IconComp = anim.icon;
                      const isActive = configDraft.theme.animationTheme === anim.id;
                      return (
                        <div
                          key={anim.id}
                          onClick={() => handleSelectAnimationTheme(anim.id as AnimationThemeType, anim.name)}
                          className={`p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 relative group flex flex-col justify-between ${
                            isActive
                              ? `${anim.activeBorder} text-white shadow-xl`
                              : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white hover:bg-white/5 hover:border-slate-700'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between gap-2 mb-2.5">
                              <div className="flex items-center gap-2.5">
                                <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${anim.badgeColor}`}>
                                  <IconComp className={`w-4 h-4 ${anim.iconGlow}`} />
                                </div>
                                <div>
                                  <span className="font-black text-xs text-white block">
                                    {anim.name}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono">
                                    {anim.tag}
                                  </span>
                                </div>
                              </div>

                              {isActive ? (
                                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black shrink-0">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                                  <span>ACTIVE ⚡</span>
                                </div>
                              ) : (
                                <span className="text-[10px] text-slate-500 group-hover:text-amber-400 transition-colors">
                                  Apply →
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-300/80 leading-relaxed">
                              {anim.desc}
                            </p>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[10px]">
                            <span className="text-slate-400">Server Status:</span>
                            <span className={isActive ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                              {isActive ? '● Live on Website' : 'Ready to activate'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Background Media Mode (Direct Upload Photo/Video, Live Preview, and Real-Time Activation) */}
                <div className="p-4 bg-gradient-to-br from-black/80 via-[#180e08]/70 to-black/80 border border-amber-500/30 rounded-2xl space-y-4 shadow-xl shadow-black/50">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold text-amber-300 flex items-center gap-2">
                        <Video className="w-4 h-4 text-amber-400" />
                        <span>Live Background System (Photo / Video / Color)</span>
                        <span className="px-2 py-0.5 text-[10px] bg-amber-400/20 text-amber-300 rounded-full border border-amber-400/40 animate-pulse">
                          LIVE SYNC
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Apne device se koi bhi photo ya video upload karein, woh foran live website ke background par chal jayegi!
                      </p>
                    </div>

                    {/* Mode Selector */}
                    <div className="flex items-center gap-1.5 p-1 bg-black/80 rounded-xl border border-amber-500/30 text-xs self-start sm:self-auto">
                      {(['color', 'image', 'video'] as const).map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => {
                            playSound('click');
                            setConfigDraft((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, bgType: type },
                            }));
                          }}
                          className={`px-3 py-1 rounded-lg font-bold capitalize transition-all cursor-pointer ${
                            configDraft.theme.bgType === type
                              ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md shadow-amber-950/60'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Upload Notification Banners */}
                  {uploadSuccess && (
                    <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{uploadSuccess}</span>
                    </div>
                  )}

                  {uploadError && (
                    <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl text-rose-300 text-xs font-semibold flex items-center justify-between gap-2 animate-in fade-in">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        <span>{uploadError}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setUploadError(null)}
                        className="text-rose-400 hover:text-white p-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* DIRECT FILE UPLOAD BOX FOR PHOTO OR VIDEO */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    onDrop={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        handleUploadBackgroundFile(e.dataTransfer.files[0]);
                      }
                    }}
                    className="relative border-2 border-dashed border-amber-500/40 hover:border-amber-400 rounded-2xl p-5 bg-black/50 hover:bg-black/70 transition-all text-center group cursor-pointer"
                    onClick={() => bgFileInputRef.current?.click()}
                  >
                    <input
                      ref={bgFileInputRef}
                      type="file"
                      accept="image/*,video/*,.mp4,.webm,.mov"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          handleUploadBackgroundFile(e.target.files[0]);
                        }
                      }}
                    />

                    {uploadingBg ? (
                      <div className="py-4 space-y-2 flex flex-col items-center">
                        <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
                        <p className="text-xs font-bold text-amber-300">
                          Uploading & Activating Live Background...
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Please wait while your media is saved and broadcasted to all active visitors.
                        </p>
                      </div>
                    ) : (
                      <div className="py-2 space-y-2 flex flex-col items-center">
                        <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                          <Upload className="w-6 h-6 text-amber-400" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                            Click to Upload Photo or Video (یا فائل یہاں ڈریگ کریں)
                          </p>
                          <p className="text-[11px] text-slate-400 mt-1">
                            Supports HD/4K Photos (JPG, PNG, WebP) & Looping Videos (MP4, WebM, MOV) up to 55MB.
                          </p>
                        </div>
                        <button
                          type="button"
                          className="mt-1 px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-950/50 hover:brightness-110 cursor-pointer pointer-events-none"
                        >
                          Select Photo or Video File
                        </button>
                      </div>
                    )}
                  </div>

                  {/* CURRENT ACTIVE LIVE BACKGROUND PREVIEW BOX */}
                  {configDraft.theme.bgMediaUrl ? (
                    <div className="p-3.5 bg-black/60 border border-amber-500/25 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                          <span className="text-xs font-bold text-white uppercase tracking-wider">
                            Live Active Background ({configDraft.theme.bgType})
                          </span>
                        </div>
                        <span className="text-[10px] text-amber-400/80 font-mono truncate max-w-[200px]">
                          {configDraft.theme.bgMediaUrl}
                        </span>
                      </div>

                      {/* Mini Live Preview Container */}
                      <div className="relative w-full h-32 rounded-xl overflow-hidden border border-slate-700 bg-black flex items-center justify-center">
                        {configDraft.theme.bgType === 'video' || /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(configDraft.theme.bgMediaUrl) ? (
                          <video
                            key={configDraft.theme.bgMediaUrl}
                            src={configDraft.theme.bgMediaUrl}
                            autoPlay
                            muted
                            loop
                            playsInline
                            className="w-full h-full object-cover"
                            style={{ filter: configDraft.theme.bgBlur ? `blur(${configDraft.theme.bgBlur}px)` : undefined }}
                          />
                        ) : (
                          <img
                            key={configDraft.theme.bgMediaUrl}
                            src={configDraft.theme.bgMediaUrl}
                            alt="Background preview"
                            className="w-full h-full object-cover"
                            style={{ filter: configDraft.theme.bgBlur ? `blur(${configDraft.theme.bgBlur}px)` : undefined }}
                          />
                        )}
                        {/* Overlay preview */}
                        <div
                          className="absolute inset-0 bg-black pointer-events-none"
                          style={{ opacity: configDraft.theme.bgOverlayOpacity ?? 0.4 }}
                        />
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-md text-[10px] text-amber-300 font-bold border border-amber-500/30">
                          ● PREVIEW
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => handleForceApplyBackground(configDraft.theme.bgMediaUrl, configDraft.theme.bgType === 'video' ? 'video' : 'image')}
                          className="flex-1 min-w-[140px] px-3 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-950/40 hover:brightness-110 cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>⚡ Re-Sync Live Now</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleResetBackgroundToColor}
                          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Reset to Default</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl text-xs text-amber-300/80 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Default Royal Espresso & Gold ambient theme is currently active. Upload a photo or video above to make it your custom website background.</span>
                    </div>
                  )}

                  {/* Manual URL & Presets Option */}
                  <div className="border-t border-slate-800 pt-3 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-300">
                        Or Pick a Royalty-Free Wallpaper / Looping Video Preset:
                      </label>
                      <span className="text-[10px] text-slate-400">1-Click Fast Select</span>
                    </div>

                    {/* Presets */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {BG_PHOTO_PRESETS.map((p) => (
                        <button
                          key={p.name}
                          type="button"
                          onClick={() => {
                            playSound('click');
                            handleForceApplyBackground(p.url, 'image');
                          }}
                          className={`p-2 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer truncate ${
                            configDraft.theme.bgMediaUrl === p.url
                              ? 'bg-amber-400/20 border-amber-400 text-amber-300 ring-1 ring-amber-400'
                              : 'bg-black/50 border-slate-700 text-slate-300 hover:border-slate-500'
                          }`}
                        >
                          📷 {p.name}
                        </button>
                      ))}
                      {BG_VIDEO_PRESETS.map((v) => (
                        <button
                          key={v.name}
                          type="button"
                          onClick={() => {
                            playSound('click');
                            handleForceApplyBackground(v.url, 'video');
                          }}
                          className={`p-2 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer truncate ${
                            configDraft.theme.bgMediaUrl === v.url
                              ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 ring-1 ring-cyan-400'
                              : 'bg-black/50 border-slate-700 text-slate-300 hover:border-slate-500'
                          }`}
                        >
                          🎬 {v.name}
                        </button>
                      ))}
                    </div>

                    {/* Custom URL Input */}
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={configDraft.theme.bgMediaUrl}
                        onChange={(e) =>
                          setConfigDraft((prev) => ({
                            ...prev,
                            theme: {
                              ...prev.theme,
                              bgMediaUrl: e.target.value,
                              bgType: /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(e.target.value) ? 'video' : 'image',
                            },
                          }))
                        }
                        placeholder="Or paste external image/video URL (e.g. https://.../loop.mp4)"
                        className="flex-1 px-3.5 py-2 bg-black/70 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const isVid = /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(configDraft.theme.bgMediaUrl);
                          handleForceApplyBackground(configDraft.theme.bgMediaUrl, isVid ? 'video' : 'image');
                        }}
                        className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl cursor-pointer shrink-0 transition-colors"
                      >
                        ⚡ Set Live
                      </button>
                    </div>
                  </div>

                  {/* Darkness Overlay & Blur Sliders */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
                    <div>
                      <div className="flex justify-between text-xs text-slate-400 mb-1">
                        <span>Background Darkness Tint (Visibility)</span>
                        <span className="font-mono text-amber-300 font-bold">
                          {Math.round((configDraft.theme.bgOverlayOpacity ?? 0.40) * 100)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="0.95"
                        step="0.05"
                        value={configDraft.theme.bgOverlayOpacity ?? 0.40}
                        onChange={(e) =>
                          setConfigDraft((prev) => ({
                            ...prev,
                            theme: { ...prev.theme, bgOverlayOpacity: parseFloat(e.target.value) },
                          }))
                        }
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        Lower % = Photo/Video zyada saaf aur bright dikhega.
                      </p>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-slate-400 mb-1">
                        <span>Background Blur</span>
                        <span className="font-mono text-amber-300 font-bold">
                          {configDraft.theme.bgBlur || 0}px
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="12"
                        step="1"
                        value={configDraft.theme.bgBlur || 0}
                        onChange={(e) =>
                          setConfigDraft((prev) => ({
                            ...prev,
                            theme: { ...prev.theme, bgBlur: parseInt(e.target.value, 10) },
                          }))
                        }
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        0px = Crystal sharp clear. Higher = Soft frosted blur.
                      </p>
                    </div>
                  </div>
                </div>

                {/* 3. Individual Color Fine-Tuning */}
                <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-3">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Sliders className="w-3.5 h-3.5 text-amber-400" />
                    <span>Customize Website Colors Individually (ایک ایک رنگ تبدیل کریں)</span>
                  </h4>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Primary Color (Buttons)</label>
                      <div className="flex items-center gap-2 bg-black/60 p-1.5 rounded-xl border border-slate-700">
                        <input
                          type="color"
                          value={configDraft.theme.primaryColor}
                          onChange={(e) =>
                            setConfigDraft((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, primaryColor: e.target.value, preset: 'custom' },
                            }))
                          }
                          className="w-6 h-6 rounded border-0 cursor-pointer bg-transparent"
                        />
                        <span className="font-mono text-[11px] text-slate-200 uppercase">
                          {configDraft.theme.primaryColor}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Secondary Accent</label>
                      <div className="flex items-center gap-2 bg-black/60 p-1.5 rounded-xl border border-slate-700">
                        <input
                          type="color"
                          value={configDraft.theme.secondaryColor}
                          onChange={(e) =>
                            setConfigDraft((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, secondaryColor: e.target.value, preset: 'custom' },
                            }))
                          }
                          className="w-6 h-6 rounded border-0 cursor-pointer bg-transparent"
                        />
                        <span className="font-mono text-[11px] text-slate-200 uppercase">
                          {configDraft.theme.secondaryColor}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Highlight / Jewel Glow</label>
                      <div className="flex items-center gap-2 bg-black/60 p-1.5 rounded-xl border border-slate-700">
                        <input
                          type="color"
                          value={configDraft.theme.accentColor}
                          onChange={(e) =>
                            setConfigDraft((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, accentColor: e.target.value, preset: 'custom' },
                            }))
                          }
                          className="w-6 h-6 rounded border-0 cursor-pointer bg-transparent"
                        />
                        <span className="font-mono text-[11px] text-slate-200 uppercase">
                          {configDraft.theme.accentColor}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Canvas Background</label>
                      <div className="flex items-center gap-2 bg-black/60 p-1.5 rounded-xl border border-slate-700">
                        <input
                          type="color"
                          value={configDraft.theme.backgroundColor}
                          onChange={(e) =>
                            setConfigDraft((prev) => ({
                              ...prev,
                              theme: { ...prev.theme, backgroundColor: e.target.value, preset: 'custom' },
                            }))
                          }
                          className="w-6 h-6 rounded border-0 cursor-pointer bg-transparent"
                        />
                        <span className="font-mono text-[11px] text-slate-200 uppercase">
                          {configDraft.theme.backgroundColor}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleSaveConfig}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saveStatus === 'saving' ? 'Applying...' : saveStatus === 'saved' ? 'Theme Saved!' : 'Save & Apply All Visuals'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB: Dynamic Layout & Element Position Control */}
            {activeTab === 'layout' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                    <Layout className="w-4 h-4 text-[#d4af37]" />
                    <span>Dynamic Layout & Positions Control (مکمل لے آؤٹ اور پوزیشن کنٹرول)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Change positions of search bars, quick action icons, live chat, container scaling, and dual-panel layout dynamically.
                  </p>
                </div>

                {/* 1. Dashboard Structure Style */}
                <div className="p-4 bg-black/40 border border-[#d4af37]/30 rounded-2xl space-y-3">
                  <h4 className="text-xs font-black text-white flex items-center gap-2">
                    <Move className="w-4 h-4 text-amber-400" />
                    <span>Dashboard Architecture Style</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {[
                      {
                        id: 'dual_panel',
                        name: 'Dual-Panel Dashboard',
                        desc: 'Left: Downloader & Audio Studio, Right: Docked Live Chat box',
                      },
                      {
                        id: 'stacked',
                        name: 'Stacked Vertical Flow',
                        desc: 'Classic stacked cards with floating bottom live chat button',
                      },
                      {
                        id: 'compact',
                        name: 'Compact Streamlined',
                        desc: 'Minimal padding and fast-action single viewport focus',
                      },
                    ].map((style) => (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => {
                          playSound('click');
                          setConfigDraft((prev) => ({
                            ...prev,
                            layout: {
                              ...prev.layout,
                              dashboardStyle: style.id as any,
                            },
                          }));
                        }}
                        className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                          (configDraft.layout?.dashboardStyle || 'dual_panel') === style.id
                            ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border-[#d4af37] text-white ring-1 ring-[#d4af37]'
                            : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                          <span>{style.name}</span>
                          {(configDraft.layout?.dashboardStyle || 'dual_panel') === style.id && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37]" />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-snug">{style.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Container Width & Responsive Scaling */}
                <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-3">
                  <h4 className="text-xs font-black text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    <span>Responsive Container Width & Viewport Scale</span>
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { id: '5xl', name: 'Standard (5xl)', desc: 'Max 1024px centered' },
                      { id: '6xl', name: 'Balanced VIP (6xl)', desc: 'Max 1152px default' },
                      { id: '7xl', name: 'Cinematic Wide (7xl)', desc: 'Max 1280px luxury' },
                      { id: 'full', name: 'Full-Width Ultra (100%)', desc: 'Edge-to-edge layout' },
                    ].map((w) => (
                      <button
                        key={w.id}
                        type="button"
                        onClick={() => {
                          playSound('click');
                          setConfigDraft((prev) => ({
                            ...prev,
                            layout: {
                              ...prev.layout,
                              containerWidth: w.id as any,
                            },
                          }));
                        }}
                        className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                          (configDraft.layout?.containerWidth || '6xl') === w.id
                            ? 'bg-cyan-500/15 border-cyan-400 text-white ring-1 ring-cyan-400'
                            : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                        }`}
                      >
                        <div className="text-xs font-bold text-cyan-300">{w.name}</div>
                        <p className="text-[10px] text-slate-400 mt-0.5">{w.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. Element Positioning (Live Chat & Search Bar) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Live Chat Position */}
                  <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-3">
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-emerald-400" />
                      <span>Live Chat Widget Position</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {[
                        { id: 'bottom-right', label: 'Bottom Right ↘' },
                        { id: 'bottom-left', label: 'Bottom Left ↙' },
                        { id: 'top-right', label: 'Top Right ↗' },
                        { id: 'embedded_card', label: 'Dock In Dashboard' },
                      ].map((pos) => (
                        <button
                          key={pos.id}
                          type="button"
                          onClick={() => {
                            playSound('click');
                            setConfigDraft((prev) => ({
                              ...prev,
                              layout: {
                                ...prev.layout,
                                chatWidgetPosition: pos.id as any,
                              },
                            }));
                          }}
                          className={`p-2.5 rounded-xl border font-bold text-center transition-all cursor-pointer ${
                            (configDraft.layout?.chatWidgetPosition || 'bottom-right') === pos.id
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                              : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {pos.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Quick Action Icons Placement */}
                  <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-3">
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <Move className="w-4 h-4 text-amber-400" />
                      <span>Quick Action Platform Icons Placement</span>
                    </h4>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {[
                        { id: 'hero', label: 'Under Search' },
                        { id: 'top', label: 'Top of Page' },
                        { id: 'bottom', label: 'Above FAQ' },
                      ].map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            playSound('click');
                            setConfigDraft((prev) => ({
                              ...prev,
                              layout: {
                                ...prev.layout,
                                quickActionsPosition: p.id as any,
                              },
                            }));
                          }}
                          className={`p-2.5 rounded-xl border font-bold text-center transition-all cursor-pointer ${
                            (configDraft.layout?.quickActionsPosition || 'hero') === p.id
                              ? 'bg-amber-500/20 border-[#d4af37] text-amber-300'
                              : 'bg-black/50 border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Save Button */}
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleSaveConfig}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saveStatus === 'saving' ? 'Applying...' : saveStatus === 'saved' ? 'Layout Saved!' : 'Save & Broadcast Layout'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB: Chatbot & Access Security Management */}
            {activeTab === 'chat_security' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                    <Lock className="w-4 h-4 text-[#d4af37]" />
                    <span>Chatbot & Access Security Management (سیکیورٹی اور چیٹ پابندیاں)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Lock/unlock live chat, force email verification, or restrict community chat board to VIP lifetime members.
                  </p>
                </div>

                {/* 1. Master Chat Lock Switch */}
                <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Lock Live Chatbot & Community Board
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Jab lock active hoga, visitors messages nahi bhej sakeinge aur maintenance notice show hoga.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(configDraft.chatSecurity?.locked)}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          chatSecurity: {
                            ...prev.chatSecurity,
                            locked: e.target.checked,
                          },
                        }))
                      }
                      className="w-5 h-5 rounded cursor-pointer accent-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Maintenance / Lock Notice Message:
                    </label>
                    <input
                      type="text"
                      value={configDraft.chatSecurity?.lockNotice || ''}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          chatSecurity: {
                            ...prev.chatSecurity,
                            lockNotice: e.target.value,
                          },
                        }))
                      }
                      placeholder="e.g. Live Chat is temporarily in VIP maintenance. Check back shortly!"
                      className="w-full px-3.5 py-2.5 bg-black/60 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 2. Verification & VIP Only Toggles */}
                <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-4">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Access Control & User Verification</span>
                  </h4>

                  {/* Force Email / Google Verification */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Force &quot;Continue with Email/Google&quot; Verification
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Chat message bhejne se pehle email identity verification lazmi karein.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(configDraft.chatSecurity?.requireVerification)}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          chatSecurity: {
                            ...prev.chatSecurity,
                            requireVerification: e.target.checked,
                          },
                        }))
                      }
                      className="w-5 h-5 rounded cursor-pointer accent-amber-400"
                    />
                  </div>

                  {/* Restrict to VIP Lifetime Members Only */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <span className="text-xs font-bold text-amber-300 block">
                        👑 VIP Lifetime Members Only Chat
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Free visitors chat sirf read kar sakein ge, message sirf 250 PKR VIP lifetime members bhej sakein ge.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(configDraft.chatSecurity?.vipOnly)}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          chatSecurity: {
                            ...prev.chatSecurity,
                            vipOnly: e.target.checked,
                          },
                        }))
                      }
                      className="w-5 h-5 rounded cursor-pointer accent-[#d4af37]"
                    />
                  </div>

                  {/* Chatbot Auto-Help Assistant */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Enable Chatbot Assistant Auto-Response
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Automatic greeting and instant troubleshooting tips inside live chat.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={configDraft.chatSecurity?.botEnabled !== false}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          chatSecurity: {
                            ...prev.chatSecurity,
                            botEnabled: e.target.checked,
                          },
                        }))
                      }
                      className="w-5 h-5 rounded cursor-pointer accent-amber-400"
                    />
                  </div>
                </div>

                {/* Save Button */}
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleSaveConfig}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saveStatus === 'saving' ? 'Applying...' : saveStatus === 'saved' ? 'Security Saved!' : 'Save & Enforce Security'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 2: Clean Live Showcase Screen - Delete & Re-apply Video/Photo */}
            {activeTab === 'screen' && (() => {
              const hasActiveMedia = Boolean(
                configDraft.features.liveScreenNotice?.enabled !== false &&
                configDraft.features.liveScreenNotice?.slides &&
                configDraft.features.liveScreenNotice.slides.length > 0 &&
                configDraft.features.liveScreenNotice.slides[0]?.mediaUrl
              );

              const currentSlide: ShowcaseSlide | null = hasActiveMedia
                ? configDraft.features.liveScreenNotice!.slides![0]
                : null;

              const handleApplySingleMedia = async (mediaUrl: string, mediaType: 'image' | 'video') => {
                if (!mediaUrl.trim()) return;
                playSound('click');

                // Completely replace any old slides - only 1 clean media exists!
                const newSingleSlide: ShowcaseSlide = {
                  id: 'live_' + Date.now(),
                  tag: '',
                  title: 'Live Showcase',
                  subtitle: '',
                  mediaType,
                  mediaUrl: mediaUrl.trim(),
                  buttonText: '',
                  buttonAction: 'whatsapp',
                  showButton: false,
                };

                const updatedConfig: SiteConfigState = {
                  ...configDraft,
                  features: {
                    ...configDraft.features,
                    liveScreenNotice: {
                      ...configDraft.features.liveScreenNotice,
                      enabled: true,
                      screenMode: mediaType === 'video' ? 'video' : 'photo',
                      slides: [newSingleSlide],
                    },
                  },
                };

                setConfigDraft(updatedConfig);
                saveLocalConfig(updatedConfig);
                if (typeof window !== 'undefined') {
                  localStorage.setItem('fadiking_saved_slides', JSON.stringify([newSingleSlide]));
                }

                try {
                  const res = await updateServerConfig(password, updatedConfig);
                  await fetch('/api/client-persist-config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      slides: [newSingleSlide],
                      liveScreenEnabled: true,
                    }),
                  });

                  if (res.success) {
                    playSound('success');
                    onConfigUpdated(updatedConfig);
                    setUploadSuccess(
                      `🎉 Live Screen par naya ${mediaType === 'video' ? 'Video' : 'Photo'} lag gaya hai aur live chal raha hai!`
                    );
                    setTimeout(() => setUploadSuccess(null), 5000);
                  }
                } catch {
                  playSound('error');
                }
              };

              // Delete Live Screen Media Completely (Empty / Hidden on Website)
              const handleDeleteLiveScreenMedia = async () => {
                playSound('click');
                const updatedConfig: SiteConfigState = {
                  ...configDraft,
                  features: {
                    ...configDraft.features,
                    liveScreenNotice: {
                      ...configDraft.features.liveScreenNotice,
                      enabled: false,
                      slides: [],
                    },
                  },
                };

                setConfigDraft(updatedConfig);
                saveLocalConfig(updatedConfig);
                if (typeof window !== 'undefined') {
                  localStorage.setItem('fadiking_saved_slides', JSON.stringify([]));
                }

                try {
                  await updateServerConfig(password, updatedConfig);
                  await fetch('/api/client-persist-config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      slides: [],
                      liveScreenEnabled: false,
                    }),
                  });
                  playSound('success');
                  onConfigUpdated(updatedConfig);
                  setUploadSuccess(
                    '🗑️ Live Screen video/photo mukammal delete kar di gayi hai! Screen ab website se hat chuki hai.'
                  );
                  setTimeout(() => setUploadSuccess(null), 6000);
                } catch {
                  playSound('error');
                }
              };

              const handleCancelUpload = () => {
                if (activeUploadXhr.current) {
                  try {
                    activeUploadXhr.current.abort();
                  } catch {}
                  activeUploadXhr.current = null;
                }
                setUploadingSlideIdx(null);
                setUploadProgress(0);
                setUploadStatusMsg('');
                playSound('click');
              };

              const handleUploadLiveScreenFile = (file: File) => {
                if (!file) return;
                if (file.size > 120 * 1024 * 1024) {
                  alert('File size zyada hai (Max 120MB). Barah-e-karam choti video ya photo chunein.');
                  return;
                }
                setUploadingSlideIdx(0);
                setUploadProgress(1);
                setUploadStatusMsg('Connecting to high-speed stream upload...');
                playSound('click');

                const isVideo = file.type.startsWith('video/') || /\.(mp4|webm|mov|ogg|m4v)$/i.test(file.name);

                if (activeUploadXhr.current) {
                  try {
                    activeUploadXhr.current.abort();
                  } catch {}
                }

                const xhr = new XMLHttpRequest();
                activeUploadXhr.current = xhr;

                xhr.open(
                  'POST',
                  `/api/admin/upload-stream?filename=${encodeURIComponent(file.name)}&fileType=${isVideo ? 'video' : 'image'}`
                );
                xhr.setRequestHeader('x-admin-password', password);
                xhr.setRequestHeader('x-filename', file.name);
                xhr.timeout = 75000; // 75 seconds maximum timeout

                xhr.upload.onprogress = (e) => {
                  if (e.lengthComputable && e.total > 0) {
                    const pct = Math.min(99, Math.round((e.loaded / e.total) * 100));
                    setUploadProgress(pct);
                    const loadedMb = (e.loaded / (1024 * 1024)).toFixed(1);
                    const totalMb = (e.total / (1024 * 1024)).toFixed(1);
                    setUploadStatusMsg(`Uploading: ${pct}% (${loadedMb}MB / ${totalMb}MB)...`);
                  }
                };

                xhr.onload = async () => {
                  activeUploadXhr.current = null;
                  if (xhr.status >= 200 && xhr.status < 300) {
                    setUploadProgress(100);
                    setUploadStatusMsg('Media uploaded! Setting live on screen...');
                    try {
                      const data = JSON.parse(xhr.responseText);
                      if (data.success && data.url) {
                        await handleApplySingleMedia(data.url, isVideo ? 'video' : 'image');
                      } else {
                        alert(data.error || 'Failed to publish media to Live Screen');
                        playSound('error');
                      }
                    } catch {
                      alert('Server response error during upload');
                      playSound('error');
                    }
                  } else {
                    alert(`Upload failed with server status ${xhr.status}. Please try again.`);
                    playSound('error');
                  }
                  setUploadingSlideIdx(null);
                  setUploadProgress(0);
                  setUploadStatusMsg('');
                };

                xhr.onerror = () => {
                  activeUploadXhr.current = null;
                  setUploadingSlideIdx(null);
                  setUploadProgress(0);
                  setUploadStatusMsg('');
                  alert('Network error while uploading media. Please check connection and try again.');
                  playSound('error');
                };

                xhr.ontimeout = () => {
                  activeUploadXhr.current = null;
                  setUploadingSlideIdx(null);
                  setUploadProgress(0);
                  setUploadStatusMsg('');
                  alert('Upload timed out. File was too large or internet is slow.');
                  playSound('error');
                };

                xhr.send(file);
              };

              const SCREEN_PRESETS = [
                { name: '💻 Cyber Matrix Code', type: 'video' as const, url: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31911-large.mp4' },
                { name: '✨ Deep Space Nebula', type: 'video' as const, url: 'https://assets.mixkit.co/videos/preview/mixkit-flying-through-a-starfield-in-space-12792-large.mp4' },
                { name: '🏙️ Cyber City Night', type: 'image' as const, url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80' },
                { name: '👑 Royal Gold Abstract', type: 'image' as const, url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80' },
              ];

              return (
                <div className="space-y-6 animate-in fade-in duration-150">
                  {/* Tab Header & Quick Status */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-500/20">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                        <Tv className="w-4 h-4 text-cyan-400" />
                        <span>Live Screen Media Manager (ویڈیو ڈیلیٹ اور دوبارہ لگانے کا کنٹرول)</span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Live Screen video/photo ko aik click me delete karein ya dobara naya media lagayein.
                      </p>
                    </div>

                    <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl self-start sm:self-auto">
                      <span className="text-xs font-bold text-amber-300">Live Screen Status:</span>
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                          hasActiveMedia
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-red-500/20 text-red-300 border border-red-500/40'
                        }`}
                      >
                        {hasActiveMedia ? '🟢 Active' : '🔴 Empty / Deleted'}
                      </span>
                    </div>
                  </div>

                  {uploadSuccess && (
                    <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{uploadSuccess}</span>
                    </div>
                  )}

                  {/* ACTIVE PREVIEW & DELETE SECTION */}
                  {hasActiveMedia && currentSlide ? (
                    <div className="p-4 sm:p-5 bg-gradient-to-br from-amber-950/20 via-black/80 to-black/95 border border-amber-500/30 rounded-2xl space-y-4 shadow-xl">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                          Currently Active Live Media (اس وقت لائیو اسکرین پر یہ چل رہا ہے)
                        </span>
                        <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono font-bold uppercase">
                          {currentSlide.mediaType === 'video' ? '🎬 Live Video' : '📸 Live Photo'}
                        </span>
                      </div>

                      <div className="relative w-full h-48 sm:h-64 rounded-2xl overflow-hidden border border-white/10 bg-black flex items-center justify-center shadow-inner">
                        {currentSlide.mediaType === 'video' || /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(currentSlide.mediaUrl) ? (
                          <video
                            key={currentSlide.mediaUrl}
                            src={currentSlide.mediaUrl}
                            autoPlay
                            muted
                            loop
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <img
                            key={currentSlide.mediaUrl}
                            src={currentSlide.mediaUrl}
                            alt="Live Screen Media"
                            className="w-full h-full object-cover"
                          />
                        )}
                        <div className="absolute bottom-2 left-2 px-3 py-1 rounded-xl bg-black/75 backdrop-blur-md text-[11px] text-white font-mono border border-white/15">
                          Clean Screen · Active
                        </div>
                      </div>

                      {/* 🗑️ DEDICATED DELETE BUTTON */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-red-950/30 border border-red-500/40 rounded-xl">
                        <div>
                          <span className="text-xs font-bold text-red-200 block">
                            Delete Live Screen Media (ویڈیو / تصویر ڈیلیٹ کریں)
                          </span>
                          <span className="text-[11px] text-red-300/80">
                            Is par click karne se video/photo website se fauran hat jayegi aur screen khali ho jayegi.
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleDeleteLiveScreenMedia}
                          className="px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 cursor-pointer transition-transform active:scale-95 shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Delete Live Screen (مکمل ختم کریں)</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* EMPTY STATE WHEN DELETED */
                    <div className="p-6 bg-slate-900/40 border border-dashed border-amber-500/40 rounded-2xl text-center space-y-2">
                      <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 mx-auto flex items-center justify-center text-amber-400">
                        <Tv className="w-6 h-6" />
                      </div>
                      <h4 className="text-sm font-bold text-white">
                        Live Screen is currently Empty / Deleted (اس وقت لائیو اسکرین خالی ہے)
                      </h4>
                      <p className="text-xs text-slate-400 max-w-md mx-auto">
                        Website ke top par koi video ya photo nahi chal rahi. Dobara lagane ke liye neeche diye gaye tareeqon me se koi aik chunein!
                      </p>
                    </div>
                  )}

                  {/* ➕ DOBARA LAGAYEIN (RE-ADD / UPLOAD MEDIA) SECTION */}
                  <div className="p-4 sm:p-5 bg-black/60 border border-amber-500/40 rounded-2xl space-y-4 shadow-xl">
                    <div className="flex items-center gap-2 pb-2 border-b border-amber-500/20">
                      <PlusCircle className="w-4 h-4 text-amber-400" />
                      <h4 className="text-xs sm:text-sm font-bold text-white">
                        Dobara Video / Photo Lagayein (Re-Add Video or Photo)
                      </h4>
                    </div>

                    {/* Method 1: Direct File Upload */}
                    <div className="space-y-2">
                      <span className="text-xs font-semibold text-slate-300 block">
                        Tareeqa 1: Apne Mobile / Computer se File Upload Karein:
                      </span>
                      <label className="border-2 border-dashed border-amber-500/40 hover:border-amber-400 rounded-2xl p-5 bg-black/40 hover:bg-black/60 transition-all flex flex-col items-center justify-center gap-2 cursor-pointer text-center group">
                        <input
                          type="file"
                          accept="video/*,image/*,.mp4,.webm,.mov"
                          className="hidden"
                          disabled={uploadingSlideIdx === 0}
                          onChange={(e) => {
                            if (e.target.files && e.target.files.length > 0) {
                              handleUploadLiveScreenFile(e.target.files[0]);
                            }
                          }}
                        />
                        {uploadingSlideIdx === 0 ? (
                          <div className="w-full py-4 px-3 flex flex-col items-center justify-center gap-3">
                            <div className="flex items-center gap-2.5">
                              <RefreshCw className="w-6 h-6 text-amber-400 animate-spin shrink-0" />
                              <div className="text-left">
                                <span className="text-xs sm:text-sm font-bold text-white block">
                                  {uploadStatusMsg || 'Uploading media stream...'}
                                </span>
                                <span className="text-[10px] text-amber-300 font-mono">
                                  Live Screen Publishing Pipeline · {uploadProgress}%
                                </span>
                              </div>
                            </div>

                            {/* Progress bar */}
                            <div className="w-full max-w-sm h-2.5 bg-black/80 rounded-full overflow-hidden border border-amber-500/30 p-0.5">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 transition-all duration-150 shadow-[0_0_10px_rgba(245,158,11,0.6)]"
                                style={{ width: `${Math.max(4, uploadProgress)}%` }}
                              />
                            </div>

                            {/* Cancel upload button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                handleCancelUpload();
                              }}
                              className="mt-1 px-3 py-1 rounded-lg bg-red-950/80 hover:bg-red-900 border border-red-500/40 text-red-200 text-[11px] font-bold cursor-pointer transition-colors inline-flex items-center gap-1"
                            >
                              <X className="w-3 h-3" />
                              <span>Cancel Upload (کینسل کریں)</span>
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                              <Upload className="w-6 h-6" />
                            </div>
                            <div>
                              <span className="text-xs font-bold text-white block">Click to Browse Video / Photo from Device</span>
                              <span className="text-[11px] text-slate-400">Supports MP4, WebM, MOV, JPG, PNG (Auto-activates on website)</span>
                            </div>
                          </>
                        )}
                      </label>
                    </div>

                    {/* Method 2: Fast 1-Click Presets */}
                    <div className="pt-2 border-t border-slate-800 space-y-2">
                      <span className="text-xs font-semibold text-slate-300 block">
                        Tareeqa 2: 1-Click Fast Presets me se Lagayein:
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {SCREEN_PRESETS.map((p) => (
                          <button
                            key={p.name}
                            type="button"
                            onClick={() => handleApplySingleMedia(p.url, p.type)}
                            className={`p-3 rounded-xl border text-xs font-bold text-center transition-all cursor-pointer truncate ${
                              currentSlide?.mediaUrl === p.url
                                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 ring-1 ring-cyan-400'
                                : 'bg-black/50 border-slate-700 text-slate-300 hover:border-amber-400 hover:text-white'
                            }`}
                          >
                            {p.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Method 3: Online Direct URL */}
                    <div className="pt-2 border-t border-slate-800 space-y-2">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Tareeqa 3: Online Video / Photo Direct URL Paste Karein:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="url"
                          placeholder="https://... (e.g. https://.../video.mp4)"
                          defaultValue={currentSlide?.mediaUrl || ''}
                          id="customLiveScreenUrlInput"
                          className="flex-1 px-3.5 py-2.5 bg-black/70 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400 font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const el = document.getElementById('customLiveScreenUrlInput') as HTMLInputElement | null;
                            if (el && el.value.trim()) {
                              const val = el.value.trim();
                              const isVid = /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(val);
                              handleApplySingleMedia(val, isVid ? 'video' : 'image');
                            }
                          }}
                          className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black text-xs rounded-xl cursor-pointer transition-colors shadow-md flex items-center gap-1.5"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>Set Live</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* TAB: Icon & Item Studio (آئیکن اور بٹن کنٹرولر) */}
            {activeTab === 'icons' && (() => {
              const currentIcons: ItemIconsConfig = configDraft.itemIcons || DEFAULT_ITEM_ICONS;

              const updateIcons = (updates: Partial<ItemIconsConfig>) => {
                setConfigDraft((prev) => ({
                  ...prev,
                  itemIcons: {
                    ...(prev.itemIcons || DEFAULT_ITEM_ICONS),
                    ...updates,
                  },
                }));
              };

              return (
                <div className="space-y-6 animate-in fade-in duration-150">
                  <div className="pb-3 border-b border-amber-500/20">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Icon & Item Studio (آئیکن تبدیل کرنے کا آپشن)</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Website ke logo, direct downloader, batch queue, audio studio aur VIP badge ke icons apni marzi ke mutabiq tabdeel karein!
                    </p>
                  </div>

                  {/* Global Icon Theme Style */}
                  <div className="p-4 bg-black/40 border border-amber-900/40 rounded-2xl space-y-3">
                    <label className="block text-xs font-bold text-amber-300">
                      Global Icon Theme Style (گلوبل آئیکن اسٹائل):
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: '3d', label: '3D Gold Metallic', desc: 'Embossed luxury gold' },
                        { id: 'animated', label: 'Cyber Animated Glow', desc: 'Vibrant neon pulse' },
                        { id: '2d', label: 'Minimal Luxury 2D', desc: 'Crisp thin gold line' },
                        { id: 'colorful_glass', label: 'Frosted Glass', desc: 'Smoky glass tint' },
                      ].map((style) => (
                        <button
                          key={style.id}
                          type="button"
                          onClick={() => updateIcons({ iconStyle: style.id as ItemIconsConfig['iconStyle'] })}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            (currentIcons.iconStyle || '3d') === style.id
                              ? 'bg-amber-500/20 border-amber-400 shadow-md shadow-amber-500/10'
                              : 'bg-black/50 border-slate-800 hover:border-amber-900'
                          }`}
                        >
                          <span className="block text-xs font-bold text-white">{style.label}</span>
                          <span className="block text-[10px] text-slate-400 mt-0.5">{style.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Individual Icon Customization */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* 1. Brand Logo Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Crown className="w-4 h-4 text-amber-400" />
                          Brand Logo Icon (لوگو کا آئیکن)
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.logoIcon || 'crown'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'crown', label: '👑 Crown' },
                          { id: 'diamond', label: '💎 Diamond' },
                          { id: 'rocket', label: '🚀 Rocket' },
                          { id: 'flame', label: '🔥 Flame' },
                          { id: 'shield', label: '🛡️ Shield' },
                          { id: 'trophy', label: '🏆 Trophy' },
                          { id: 'zap', label: '⚡ Zap' },
                          { id: 'star', label: '⭐ Star' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ logoIcon: item.id as ItemIconsConfig['logoIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.logoIcon || 'crown') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Or Custom Image Logo URL:</label>
                        <input
                          type="url"
                          value={currentIcons.logoCustomUrl || ''}
                          onChange={(e) => updateIcons({ logoCustomUrl: e.target.value })}
                          placeholder="https://.../my-logo.png"
                          className="w-full px-3 py-1.5 bg-black/60 border border-slate-700 rounded-xl text-xs text-white outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    {/* 2. Direct Downloader Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-400" />
                          Direct Downloader Tab Icon
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.directDownloaderIcon || 'zap'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'zap', label: '⚡ Zap' },
                          { id: 'download', label: '📥 Download' },
                          { id: 'rocket', label: '🚀 Rocket' },
                          { id: 'film', label: '🎬 Film' },
                          { id: 'sparkles', label: '✨ Sparkles' },
                          { id: 'play', label: '▶️ Play' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ directDownloaderIcon: item.id as ItemIconsConfig['directDownloaderIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.directDownloaderIcon || 'zap') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 3. Batch URLs (Bulk) Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Layers className="w-4 h-4 text-amber-400" />
                          Batch URLs Tab Icon
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.batchDownloaderIcon || 'layers'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'layers', label: '📚 Layers' },
                          { id: 'list', label: '📋 List Queue' },
                          { id: 'package', label: '📦 Package' },
                          { id: 'copy', label: '📑 Multi-Copy' },
                          { id: 'grid', label: '⊞ Grid' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ batchDownloaderIcon: item.id as ItemIconsConfig['batchDownloaderIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.batchDownloaderIcon || 'layers') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 4. Audio Studio Tab Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Music2 className="w-4 h-4 text-amber-400" />
                          Audio & MP3 Studio Tab Icon
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.audioStudioIcon || 'music'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'music', label: '🎵 Music' },
                          { id: 'headphones', label: '🎧 Headphones' },
                          { id: 'mic', label: '🎤 Mic' },
                          { id: 'disc', label: '💿 Disc' },
                          { id: 'radio', label: '📻 Radio' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ audioStudioIcon: item.id as ItemIconsConfig['audioStudioIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.audioStudioIcon || 'music') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 5. VIP Badge Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Gem className="w-4 h-4 text-amber-400" />
                          VIP Member Badge Icon
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.vipBadgeIcon || 'crown'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'crown', label: '👑 Crown' },
                          { id: 'gem', label: '💎 Gem' },
                          { id: 'shield', label: '🛡️ Shield' },
                          { id: 'award', label: '🎖️ Award' },
                          { id: 'sparkles', label: '✨ Sparkles' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ vipBadgeIcon: item.id as ItemIconsConfig['vipBadgeIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.vipBadgeIcon || 'crown') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 6. Stream Visualizer Icon */}
                    <div className="p-4 bg-black/40 border border-amber-900/30 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-400" />
                          Stream Visualizer Mode Icon
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                          {currentIcons.streamVisualizerIcon || 'activity'}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { id: 'activity', label: '📈 Activity' },
                          { id: 'waveform', label: '〰️ Waveform' },
                          { id: 'laser', label: '⚡ Laser' },
                          { id: 'radar', label: '🎯 Radar' },
                          { id: 'cpu', label: '💻 CPU Engine' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => updateIcons({ streamVisualizerIcon: item.id as ItemIconsConfig['streamVisualizerIcon'] })}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                              (currentIcons.streamVisualizerIcon || 'activity') === item.id
                                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg'
                                : 'bg-black/60 border-slate-800 text-slate-300 hover:border-amber-500/50'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Save Icon Customizations Button */}
                  <div className="flex justify-end pt-3">
                    <button
                      onClick={handleSaveConfig}
                      className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                    >
                      <Save className="w-4 h-4" />
                      <span>{saveStatus === 'saving' ? 'Saving Icons...' : saveStatus === 'saved' ? 'Icons Saved Live!' : 'Save Icon Customization'}</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* TAB 3: Audio & Hobby Song */}
            {activeTab === 'audio' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                    <Music2 className="w-4 h-4 text-amber-400" />
                    <span>Hobby Song & Background Music Player</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Play curated ambient chill tunes or your custom MP3 song across the website.
                  </p>
                </div>

                {/* Master Toggles */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">Background Music</span>
                      <span className="text-[11px] text-slate-400">Enable audio engine</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={configDraft.audio.bgMusicEnabled}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          audio: { ...prev.audio, bgMusicEnabled: e.target.checked },
                        }))
                      }
                      className="w-5 h-5 rounded text-amber-500 focus:ring-0 cursor-pointer"
                    />
                  </div>

                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">Floating Player</span>
                      <span className="text-[11px] text-slate-400">Visitor control bar</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={configDraft.audio.showFloatingPlayer}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          audio: { ...prev.audio, showFloatingPlayer: e.target.checked },
                        }))
                      }
                      className="w-5 h-5 rounded text-amber-500 focus:ring-0 cursor-pointer"
                    />
                  </div>

                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">Autoplay</span>
                      <span className="text-[11px] text-slate-400">Start on page load</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={configDraft.audio.autoplay}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          audio: { ...prev.audio, autoplay: e.target.checked },
                        }))
                      }
                      className="w-5 h-5 rounded text-amber-500 focus:ring-0 cursor-pointer"
                    />
                  </div>
                </div>

                {/* Select Hobby Song Track */}
                <div className="p-4 bg-black/40 border border-slate-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Choose Active Hobby Song:</span>
                    <button
                      onClick={handleToggleTestMusic}
                      className="py-1 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      {testMusicPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      <span>{testMusicPlaying ? 'Stop Test' : 'Preview Active Track'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {HOBBY_TRACKS.map((track) => (
                      <div
                        key={track.id}
                        onClick={() => {
                          playSound('click');
                          setConfigDraft((prev) => ({
                            ...prev,
                            audio: { ...prev.audio, selectedTrackId: track.id },
                          }));
                          if (testMusicPlaying) {
                            playAmbientTune(track.id, configDraft.audio.volume, configDraft.audio.customTrackUrl);
                          }
                        }}
                        className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                          configDraft.audio.selectedTrackId === track.id
                            ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border-amber-400 text-white'
                            : 'bg-black/30 border-slate-800 text-slate-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">{track.name}</span>
                          <span className="text-[10px] font-mono text-amber-300">{track.genre}</span>
                        </div>
                        <span className="text-[11px] text-slate-500 block mt-0.5">{track.mood}</span>
                      </div>
                    ))}
                  </div>

                  {/* Custom URL input if custom_audio selected */}
                  {configDraft.audio.selectedTrackId === 'custom_audio' && (
                    <div className="pt-2 animate-in fade-in">
                      <label className="block text-xs font-semibold text-amber-300 mb-1">
                        Paste Custom Audio / MP3 Stream URL:
                      </label>
                      <input
                        type="url"
                        value={configDraft.audio.customTrackUrl || ''}
                        onChange={(e) =>
                          setConfigDraft((prev) => ({
                            ...prev,
                            audio: { ...prev.audio, customTrackUrl: e.target.value },
                          }))
                        }
                        placeholder="https://example.com/my-favorite-song.mp3"
                        className="w-full px-3.5 py-2.5 bg-black/60 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400"
                      />
                    </div>
                  )}

                  {/* Volume Slider */}
                  <div className="pt-2 flex items-center gap-3">
                    <Volume2 className="w-4 h-4 text-slate-400" />
                    <span className="text-xs text-slate-400">Default Volume:</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={configDraft.audio.volume}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          audio: { ...prev.audio, volume: parseInt(e.target.value, 10) },
                        }))
                      }
                      className="flex-1 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                    />
                    <span className="text-xs font-mono text-white w-10 text-right">
                      {configDraft.audio.volume}%
                    </span>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleSaveConfig}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saveStatus === 'saving' ? 'Saving...' : saveStatus === 'saved' ? 'Audio Saved!' : 'Save Audio Settings'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 4: Website Controls & Chat Moderation */}
            {activeTab === 'features' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                    <Settings className="w-4 h-4 text-amber-400" />
                    <span>Website Features & Chat Controls</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Adjust limits, WhatsApp ordering links, announcements, and moderate live chat.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Download Quota Limit */}
                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl">
                    <label className="block text-xs font-bold text-white mb-1">
                      Free Download Limit (per visitor)
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={configDraft.features.freeDownloadQuota}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          features: {
                            ...prev.features,
                            freeDownloadQuota: parseInt(e.target.value, 10) || 5,
                          },
                        }))
                      }
                      className="w-full px-3.5 py-2 bg-black/60 border border-slate-700 rounded-xl text-sm font-mono text-white outline-none focus:border-amber-400"
                    />
                  </div>

                  {/* Plan Price */}
                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl">
                    <label className="block text-xs font-bold text-white mb-1">
                      Upgrade Plan Price (PKR)
                    </label>
                    <input
                      type="text"
                      value={configDraft.features.planPricePKR}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          features: { ...prev.features, planPricePKR: e.target.value },
                        }))
                      }
                      placeholder="250 PKR"
                      className="w-full px-3.5 py-2 bg-black/60 border border-slate-700 rounded-xl text-sm font-mono text-amber-400 outline-none focus:border-amber-400"
                    />
                  </div>

                  {/* WhatsApp Support Number */}
                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl">
                    <label className="block text-xs font-bold text-white mb-1">
                      WhatsApp Orders Phone Number
                    </label>
                    <input
                      type="text"
                      value={configDraft.features.whatsappOrdersPhone}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          features: { ...prev.features, whatsappOrdersPhone: e.target.value },
                        }))
                      }
                      placeholder="923708392045"
                      className="w-full px-3.5 py-2 bg-black/60 border border-slate-700 rounded-xl text-sm font-mono text-emerald-400 outline-none focus:border-emerald-400"
                    />
                  </div>

                  {/* WhatsApp Channel Link */}
                  <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl">
                    <label className="block text-xs font-bold text-white mb-1">
                      WhatsApp Channel URL (Single Clean Link)
                    </label>
                    <input
                      type="url"
                      value={configDraft.features.whatsappChannelUrl}
                      onChange={(e) =>
                        setConfigDraft((prev) => ({
                          ...prev,
                          features: { ...prev.features, whatsappChannelUrl: e.target.value },
                        }))
                      }
                      placeholder="https://whatsapp.com/channel/..."
                      className="w-full px-3.5 py-2 bg-black/60 border border-slate-700 rounded-xl text-sm font-mono text-white outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                {/* Modular Feature Manager (Turn Any Section ON/OFF) */}
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-2 mb-2">
                    <Layers className="w-3.5 h-3.5 text-amber-400" />
                    <span>Modular Feature Manager (ہر سیکشن کو آن یا آف کریں)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                    {[
                      {
                        key: 'directDownloaderEnabled',
                        name: 'Direct Downloader',
                        desc: 'Single URL analysis & downloads',
                        val: configDraft.features.directDownloaderEnabled !== false,
                      },
                      {
                        key: 'batchDownloaderEnabled',
                        name: 'Batch Downloader',
                        desc: 'Multi-link queue processing',
                        val: configDraft.features.batchDownloaderEnabled !== false,
                      },
                      {
                        key: 'audioStudioEnabled',
                        name: 'Studio Audio',
                        desc: 'Audio converter & waveform',
                        val: configDraft.features.audioStudioEnabled !== false,
                      },
                      {
                        key: 'liveChatEnabled',
                        name: 'Live Chat Board',
                        desc: 'Real-time community chat',
                        val: configDraft.features.liveChatEnabled !== false,
                      },
                      {
                        key: 'featuredPlatformsEnabled',
                        name: 'Platforms Grid',
                        desc: 'Supported social icons & samples',
                        val: configDraft.features.featuredPlatformsEnabled !== false,
                      },
                      {
                        key: 'downloadHistoryEnabled',
                        name: 'Download History',
                        desc: 'Recent downloaded clips list',
                        val: configDraft.features.downloadHistoryEnabled !== false,
                      },
                      {
                        key: 'faqSectionEnabled',
                        name: 'FAQ & Guide',
                        desc: 'Questions & help center',
                        val: configDraft.features.faqSectionEnabled !== false,
                      },
                      {
                        key: 'requireGateFollow',
                        name: 'Channel Entrance Gate',
                        desc: 'Require WhatsApp channel follow',
                        val: Boolean(configDraft.features.requireGateFollow),
                      },
                    ].map((f) => (
                      <div
                        key={f.key}
                        className="p-3 bg-black/40 border border-slate-800 rounded-xl flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-white block truncate">{f.name}</span>
                          <span className="text-[10px] text-slate-400 truncate block">{f.desc}</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={f.val}
                          onChange={(e) =>
                            setConfigDraft((prev) => ({
                              ...prev,
                              features: {
                                ...prev.features,
                                [f.key]: e.target.checked,
                              },
                            }))
                          }
                          className="w-4 h-4 rounded cursor-pointer accent-[#d4af37] shrink-0"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Chat Moderation */}
                <div className="p-3.5 bg-black/40 border border-slate-800 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">Live Chat Moderation</span>
                    <span className="text-[11px] text-slate-400">Clear all community chat messages from board</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleClearChatHistory}
                    className="py-1.5 px-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Chat History
                  </button>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleSaveConfig}
                    className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer transition-transform active:scale-95"
                  >
                    <Save className="w-4 h-4" />
                    <span>{saveStatus === 'saving' ? 'Saving...' : saveStatus === 'saved' ? 'Settings Saved!' : 'Save Website Controls'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 5: VIP Licenses & Code Generator */}
            {activeTab === 'licenses' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="p-3 bg-black/40 border border-slate-800 rounded-xl">
                    <span className="text-[11px] text-slate-400 block">Total Issued</span>
                    <span className="text-lg font-bold font-mono text-amber-400">
                      {licenses.length} Licenses
                    </span>
                  </div>
                  <div className="p-3 bg-black/40 border border-slate-800 rounded-xl">
                    <span className="text-[11px] text-slate-400 block">Plan Price</span>
                    <span className="text-lg font-bold font-mono text-amber-400">
                      {configDraft.features.planPricePKR}
                    </span>
                  </div>
                  <div className="col-span-2 sm:col-span-1 p-3 bg-black/40 border border-slate-800 rounded-xl">
                    <span className="text-[11px] text-slate-400 block">Est. Revenue</span>
                    <span className="text-lg font-bold font-mono text-white">
                      {licenses.length * 250} PKR
                    </span>
                  </div>
                </div>

                {/* Generator Box */}
                <div className="p-4 bg-black/40 border border-amber-500/20 rounded-xl space-y-3">
                  <div className="flex items-center gap-2 text-sm font-semibold text-amber-300">
                    <PlusCircle className="w-4 h-4" />
                    <span>Generate Customer Lifetime Code</span>
                  </div>

                  <form onSubmit={handleGenerate} className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="email"
                      required
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="e.g. buyer@gmail.com"
                      className="flex-1 px-3.5 py-2.5 bg-black/60 border border-slate-700 focus:border-amber-500 rounded-xl text-sm text-white placeholder-slate-500 outline-none"
                    />
                    <button
                      type="submit"
                      disabled={genLoading}
                      className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs rounded-xl transition-all shrink-0 disabled:opacity-50 cursor-pointer"
                    >
                      {genLoading ? 'Generating...' : 'Generate Unique Code'}
                    </button>
                  </form>

                  {genError && (
                    <div className="p-2.5 bg-red-950/40 border border-red-500/30 rounded-lg text-xs text-red-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{genError}</span>
                    </div>
                  )}

                  {generatedCode && (
                    <div className="mt-3 p-3.5 bg-amber-950/30 border border-amber-500/40 rounded-xl animate-in fade-in space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                          <Crown className="w-3.5 h-3.5 text-amber-400" />
                          <span>License Code Generated Successfully!</span>
                        </span>
                        <span className="text-[11px] text-slate-400">{generatedCode.email}</span>
                      </div>

                      <div className="p-2.5 bg-black/70 rounded-lg border border-slate-800 flex items-center justify-between">
                        <span className="font-mono text-base font-bold text-amber-400 tracking-wider">
                          {generatedCode.code}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => copyCodeOnly(generatedCode.code)}
                            className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-white text-xs rounded flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                          </button>
                          <button
                            onClick={() => copyWhatsAppMessage(generatedCode)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            {copiedMsg ? <Check className="w-3 h-3" /> : <MessageSquare className="w-3 h-3" />}
                            <span>{copiedMsg ? 'Copied Msg' : 'Copy WhatsApp Reply'}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Licenses Table */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-300">
                      Active Licenses Registry ({licenses.length})
                    </span>
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Search email or code..."
                          className="pl-8 pr-2.5 py-1 bg-black/50 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 outline-none w-36 sm:w-48"
                        />
                      </div>
                      <button
                        onClick={() => loadLicenses(password)}
                        className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                        title="Refresh"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${loadingLicenses ? 'animate-spin' : ''}`} />
                      </button>
                    </div>
                  </div>

                  <div className="max-h-60 overflow-y-auto border border-slate-800 rounded-xl bg-black/30">
                    {filteredLicenses.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-500">
                        No licenses generated yet.
                      </div>
                    ) : (
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-900/60 text-slate-400 border-b border-slate-800 sticky top-0">
                          <tr>
                            <th className="py-2 px-3">Customer Email</th>
                            <th className="py-2 px-3">Activation Code</th>
                            <th className="py-2 px-3 hidden sm:table-cell">Date Created</th>
                            <th className="py-2 px-3 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {filteredLicenses.map((lic) => (
                            <tr key={lic.id} className="hover:bg-white/[0.02]">
                              <td className="py-2.5 px-3 font-sans truncate max-w-[140px] sm:max-w-[180px]">
                                {lic.email}
                              </td>
                              <td className="py-2.5 px-3 text-amber-400 font-semibold select-all">
                                {lic.code}
                              </td>
                              <td className="py-2.5 px-3 text-slate-500 text-[11px] hidden sm:table-cell">
                                {new Date(lic.createdAt).toLocaleDateString()}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <div className="inline-flex items-center gap-1">
                                  <button
                                    onClick={() => copyWhatsAppMessage(lic)}
                                    className="p-1 text-slate-400 hover:text-emerald-400 rounded hover:bg-white/5 cursor-pointer"
                                    title="Copy WhatsApp Reply"
                                  >
                                    <MessageSquare className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => copyCodeOnly(lic.code)}
                                    className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5 cursor-pointer"
                                    title="Copy Code"
                                  >
                                    <Copy className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDelete(lic.id)}
                                    className="p-1 text-slate-500 hover:text-red-400 rounded hover:bg-white/5 cursor-pointer"
                                    title="Revoke"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 6: Member Directory, VIP Upgrade Record & Chat Block Moderation */}
            {activeTab === 'members' && (() => {
              const totalCount = members.length;
              const vipCount = members.filter((m) => m.isLifetimeVip).length;
              const freeCount = members.filter((m) => !m.isLifetimeVip).length;
              const blockedCount = members.filter((m) => m.isBlocked).length;

              const filteredMembers = members.filter((m) => {
                const matchesSearch =
                  m.username.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
                  (m.vipEmail && m.vipEmail.toLowerCase().includes(memberSearchQuery.toLowerCase()));

                if (!matchesSearch) return false;

                if (memberFilter === 'vip') return m.isLifetimeVip;
                if (memberFilter === 'free') return !m.isLifetimeVip;
                if (memberFilter === 'blocked') return m.isBlocked;
                return true;
              });

              return (
                <div className="space-y-6 animate-in fade-in duration-150">
                  {/* Header Title */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                        <Users className="w-4 h-4 text-amber-400" />
                        <span>Registered Members Directory & Chat Moderation</span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Record of all members who joined, VIP Lifetime (250 PKR) vs Free Plan tracking, and 1-click chat block/unblock control.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                      <button
                        onClick={handleClearChatHistory}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold shadow-md shadow-red-950/40 transition-all cursor-pointer active:scale-95"
                        title="Delete all messages from the live community chat board for all visitors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Clear All Chat For Everyone</span>
                      </button>

                      <button
                        onClick={() => loadMembers(password)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-amber-500/50 rounded-xl text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${loadingMembers ? 'animate-spin text-amber-400' : ''}`} />
                        <span>Refresh</span>
                      </button>
                    </div>
                  </div>

                  {/* 4 Stats Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 bg-black/40 border border-slate-800 rounded-xl">
                      <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
                        <span>Total Members</span>
                        <Users className="w-3.5 h-3.5 text-slate-400" />
                      </div>
                      <p className="text-xl font-bold font-mono text-white">{totalCount}</p>
                      <span className="text-[10px] text-slate-500">Joined users</span>
                    </div>

                    <div className="p-3.5 bg-amber-950/20 border border-amber-500/30 rounded-xl">
                      <div className="flex items-center justify-between text-amber-300 text-[11px] mb-1">
                        <span>VIP Lifetime (250 PKR)</span>
                        <Crown className="w-3.5 h-3.5 text-amber-400" />
                      </div>
                      <p className="text-xl font-bold font-mono text-amber-400">{vipCount}</p>
                      <span className="text-[10px] text-amber-400/70">Upgraded members</span>
                    </div>

                    <div className="p-3.5 bg-black/40 border border-slate-800 rounded-xl">
                      <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
                        <span>Free Plan Members</span>
                        <Sparkles className="w-3.5 h-3.5 text-slate-400" />
                      </div>
                      <p className="text-xl font-bold font-mono text-slate-300">{freeCount}</p>
                      <span className="text-[10px] text-slate-500">Standard users</span>
                    </div>

                    <div className="p-3.5 bg-red-950/20 border border-red-500/30 rounded-xl">
                      <div className="flex items-center justify-between text-red-300 text-[11px] mb-1">
                        <span>Blocked from Chat</span>
                        <Ban className="w-3.5 h-3.5 text-red-400" />
                      </div>
                      <p className="text-xl font-bold font-mono text-red-400">{blockedCount}</p>
                      <span className="text-[10px] text-red-400/70">Restricted users</span>
                    </div>
                  </div>

                  {/* Filter Pills & Search Bar */}
                  <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs">
                      <button
                        onClick={() => { playSound('click'); setMemberFilter('all'); }}
                        className={`px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                          memberFilter === 'all'
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-semibold'
                            : 'bg-black/30 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        All ({totalCount})
                      </button>
                      <button
                        onClick={() => { playSound('click'); setMemberFilter('vip'); }}
                        className={`px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1 ${
                          memberFilter === 'vip'
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-semibold'
                            : 'bg-black/30 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Crown className="w-3 h-3 text-amber-400" />
                        <span>VIP ({vipCount})</span>
                      </button>
                      <button
                        onClick={() => { playSound('click'); setMemberFilter('free'); }}
                        className={`px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                          memberFilter === 'free'
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-semibold'
                            : 'bg-black/30 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        Free ({freeCount})
                      </button>
                      <button
                        onClick={() => { playSound('click'); setMemberFilter('blocked'); }}
                        className={`px-3 py-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1 ${
                          memberFilter === 'blocked'
                            ? 'bg-red-500/20 border-red-500 text-red-300 font-semibold'
                            : 'bg-black/30 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Ban className="w-3 h-3 text-red-400" />
                        <span>Blocked ({blockedCount})</span>
                      </button>
                    </div>

                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Search username or email..."
                        value={memberSearchQuery}
                        onChange={(e) => setMemberSearchQuery(e.target.value)}
                        className="pl-8 pr-3 py-1.5 bg-black/50 border border-slate-800 focus:border-amber-500/50 rounded-xl text-xs text-white placeholder-slate-500 outline-none w-full sm:w-64"
                      />
                    </div>
                  </div>

                  {/* Members Directory Table */}
                  <div className="border border-slate-800 rounded-xl bg-black/40 overflow-hidden">
                    {filteredMembers.length === 0 ? (
                      <div className="p-8 text-center text-xs text-slate-500 space-y-2">
                        <Users className="w-8 h-8 mx-auto text-slate-600" />
                        <p>No members match your current filter or search criteria.</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto max-h-[380px] overflow-y-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800 sticky top-0 backdrop-blur-md z-10">
                            <tr>
                              <th className="py-2.5 px-3 font-semibold">User Profile</th>
                              <th className="py-2.5 px-3 font-semibold">Membership Plan</th>
                              <th className="py-2.5 px-3 font-semibold">Chat Moderation</th>
                              <th className="py-2.5 px-3 font-semibold hidden md:table-cell">Activity & Messages</th>
                              <th className="py-2.5 px-3 font-semibold text-right">Moderation Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60">
                            {filteredMembers.map((member) => (
                              <tr
                                key={member.username}
                                className={`transition-colors ${
                                  member.isBlocked
                                    ? 'bg-red-950/15 hover:bg-red-950/25'
                                    : 'hover:bg-white/[0.02]'
                                }`}
                              >
                                {/* User Profile */}
                                <td className="py-3 px-3">
                                  <div className="flex items-center gap-2.5">
                                    {member.avatarUrl ? (
                                      <img
                                        src={member.avatarUrl}
                                        alt={member.username}
                                        className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
                                      />
                                    ) : (
                                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                                        member.isLifetimeVip
                                          ? 'bg-gradient-to-br from-amber-500 to-yellow-600 text-slate-950'
                                          : 'bg-slate-800 text-slate-300'
                                      }`}>
                                        {member.username.slice(0, 2).toUpperCase()}
                                      </div>
                                    )}
                                    <div className="min-w-0">
                                      <div className="font-semibold text-white flex items-center gap-1.5 truncate">
                                        <span className="truncate">{member.username}</span>
                                        {member.isLifetimeVip && (
                                          <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                        )}
                                      </div>
                                      <p className="text-[10px] text-slate-500 truncate">
                                        Joined: {new Date(member.joinedAt).toLocaleDateString()}
                                      </p>
                                    </div>
                                  </div>
                                </td>

                                {/* Plan Status (Record of who upgraded vs free) */}
                                <td className="py-3 px-3">
                                  {member.isLifetimeVip ? (
                                    <div className="space-y-0.5">
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/40 rounded-full text-[10px] font-bold text-amber-300">
                                        <Crown className="w-3 h-3 text-amber-400" />
                                        <span>👑 VIP Lifetime (250 PKR)</span>
                                      </span>
                                      {member.vipEmail && (
                                        <p className="text-[10px] font-mono text-slate-400 truncate">
                                          {member.vipEmail}
                                        </p>
                                      )}
                                    </div>
                                  ) : (
                                    <div>
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-800 border border-slate-700 rounded-full text-[10px] font-medium text-slate-400">
                                        ⚡ Free Plan
                                      </span>
                                      <p className="text-[10px] text-slate-500">Not upgraded</p>
                                    </div>
                                  )}
                                </td>

                                {/* Chat Moderation Status */}
                                <td className="py-3 px-3">
                                  {member.isBlocked ? (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-950/60 border border-red-500/50 rounded-lg text-[11px] font-bold text-red-300 animate-pulse">
                                      <Ban className="w-3 h-3 text-red-400" />
                                      <span>🚫 Blocked from Chat</span>
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-[11px] font-medium text-emerald-300">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                      <span>Active in Chat</span>
                                    </span>
                                  )}
                                </td>

                                {/* Activity & Messages */}
                                <td className="py-3 px-3 hidden md:table-cell text-slate-400 text-[11px]">
                                  <div className="space-y-0.5">
                                    <p>Messages: <span className="font-mono text-white font-semibold">{member.messageCount || 0}</span></p>
                                    <p className="text-[10px] text-slate-500">Last seen: {new Date(member.lastActiveAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                  </div>
                                </td>

                                {/* 1-Click Block/Unblock Action */}
                                <td className="py-3 px-3 text-right">
                                  <button
                                    onClick={() => handleToggleBlockUser(member.username, member.isBlocked)}
                                    disabled={actionLoadingUser === member.username}
                                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95 disabled:opacity-50 ${
                                      member.isBlocked
                                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50'
                                        : 'bg-red-600/80 hover:bg-red-600 text-white shadow-red-950/50'
                                    }`}
                                    title={member.isBlocked ? 'Allow user to send messages again' : 'Block user from sending messages'}
                                  >
                                    {actionLoadingUser === member.username ? (
                                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                    ) : member.isBlocked ? (
                                      <>
                                        <UserCheck className="w-3.5 h-3.5" />
                                        <span>Unblock User</span>
                                      </>
                                    ) : (
                                      <>
                                        <Ban className="w-3.5 h-3.5" />
                                        <span>Block from Chat</span>
                                      </>
                                    )}
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* TAB 7: Real-Time Alert Broadcasts & Bell System */}
            {activeTab === 'alerts' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
                      <Bell className="w-4 h-4 text-amber-400 fill-amber-400/20" />
                      <span>Real-Time Alert Notification Broadcast (Website Ghanti System)</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Yahan se alert bhejne par tamaam visitors ki screen par ghanti (bell) billing karegi, unread count show hoga, aur "Tung-Tung" notification sound baje gi!
                    </p>
                  </div>
                  {alertsList.length > 0 && (
                    <button
                      type="button"
                      onClick={handleClearAllAlerts}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 text-xs font-semibold cursor-pointer transition-colors self-start sm:self-auto"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      <span>Clear All Alerts</span>
                    </button>
                  )}
                </div>

                {/* Send Alert Broadcast Form */}
                <form
                  onSubmit={handleSendBroadcastAlert}
                  className="p-5 bg-gradient-to-b from-slate-900/90 to-black/60 border border-amber-500/35 rounded-2xl shadow-xl space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <Send className="w-3.5 h-3.5" />
                      <span>Compose Real-Time Alert Broadcast</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      <span>Instant Live Push</span>
                    </span>
                  </div>

                  {alertSuccess && (
                    <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        Alert tamaam website visitors ko foran send kar diya gaya hai! Visitors ki ghanti baj gayi aur Tung-Tung chime play ho gaya.
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2 space-y-1">
                      <label className="block text-[11px] font-semibold text-slate-300">
                        Alert Title / Heading
                      </label>
                      <input
                        type="text"
                        value={alertTitle}
                        onChange={(e) => setAlertTitle(e.target.value)}
                        placeholder="e.g. 📢 Important Update, 🔥 Special Discount, ⚡ Server Speed 4K"
                        maxLength={80}
                        className="w-full px-3 py-2 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[11px] font-semibold text-slate-300">
                        Category Tag
                      </label>
                      <select
                        value={alertTag}
                        onChange={(e) => setAlertTag(e.target.value as any)}
                        className="w-full px-3 py-2 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-xs text-white outline-none cursor-pointer"
                      >
                        <option value="alert">🚨 Urgent Alert</option>
                        <option value="update">✨ New Update</option>
                        <option value="offer">🎁 VIP Offer</option>
                        <option value="notice">ℹ️ General Notice</option>
                      </select>
                    </div>
                  </div>

                  {/* Notification Tune Selector & Popup Control */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-black/40 border border-slate-800 rounded-xl">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-semibold text-amber-300 flex items-center gap-1">
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>Select Notification Sound / Tune</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            playAlertTune(alertTune);
                          }}
                          className="px-2 py-0.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-[#d4af37] border border-[#d4af37]/40 text-[10px] font-black flex items-center gap-1 cursor-pointer transition-colors"
                          title="Preview selected tune"
                        >
                          <Play className="w-2.5 h-2.5 fill-current" />
                          <span>Test Sound</span>
                        </button>
                      </div>
                      <select
                        value={alertTune}
                        onChange={(e) => {
                          const tune = e.target.value as NotificationTuneType;
                          setAlertTune(tune);
                          playAlertTune(tune);
                        }}
                        className="w-full px-3 py-2 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-xs text-white outline-none cursor-pointer"
                      >
                        <option value="tung_tung">🔔 Pashto Rubab Tung-Tung (Original)</option>
                        <option value="royal_bell">👑 Royal Cathedral Palace Bell</option>
                        <option value="crystal_chime">✨ Crystal Glass Shimmer Chime</option>
                        <option value="cyber_alert">⚡ 8-bit Sci-Fi Cyber Pulse</option>
                        <option value="success_fanfare">🎺 VIP Victory Fanfare</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-xl bg-black/30 border border-slate-800/80">
                      <div>
                        <span className="text-xs font-bold text-white block">
                          Instant Floating Popup Dialog
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Auto-open alert modal dialog across visitors screen
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={alertPopup}
                        onChange={(e) => setAlertPopup(e.target.checked)}
                        className="w-4 h-4 rounded cursor-pointer accent-[#d4af37]"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[11px] font-semibold text-slate-300">
                      Message Content (Ye text ghanti open karne par sab ko nazar aayega)
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={alertText}
                      onChange={(e) => setAlertText(e.target.value)}
                      placeholder="Apna alert message yahan likhein (e.g. Assalam-o-Alaikum! Naya server launch ho chuka hai, ab tamam 4K videos aur Pakistani Sad songs full HD mein download karein!)..."
                      className="w-full px-3.5 py-2.5 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-xs text-white placeholder-slate-500 outline-none resize-none"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <p className="text-[11px] text-slate-400">
                      Alert bhejte hi sab visitors ki ghanti ring karegi aur chuni hui sound tune baje gi.
                    </p>

                    <button
                      type="submit"
                      disabled={sendingAlert || !alertText.trim()}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/40 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Bell className="w-4 h-4 fill-current" />
                      <span>{sendingAlert ? 'Sending Alert...' : 'Broadcast Alert & Play Tune 🔔'}</span>
                    </button>
                  </div>
                </form>

                {/* Broadcast History */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Sent Broadcast Alerts History ({alertsList.length})</span>
                  </h4>

                  {alertsList.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500 border border-slate-800 rounded-2xl bg-black/30">
                      Abhi tak koi alert send nahi kiya gaya. Upar se pehla alert send karein!
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-72 overflow-y-auto">
                      {alertsList.map((item) => (
                        <div
                          key={item.id}
                          className="p-3.5 bg-black/40 border border-slate-800 hover:border-slate-700 rounded-2xl flex items-start justify-between gap-3 text-xs"
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-xs">{item.title}</span>
                              <span className="px-2 py-0.2 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                                {item.tag}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                {new Date(item.timestamp).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                            </div>
                            <p className="text-slate-300 text-[11px] leading-relaxed break-words whitespace-pre-wrap">
                              {item.text}
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteAlert(item.id)}
                            className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-white/5 transition-colors cursor-pointer shrink-0"
                            title="Delete this alert"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
        </div>
      </div>
    </div>
  );
};
