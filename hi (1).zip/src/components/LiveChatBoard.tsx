import React, { useState, useEffect, useRef } from 'react';
import {
  MessageCircle,
  Bot,
  X,
  Send,
  User,
  Crown,
  Shield,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  Smile,
  RefreshCw,
  Image as ImageIcon,
  Mic,
  Square,
  Play,
  Pause,
  Trash2,
  Camera,
  Check,
  Radio,
  Users,
  ShieldAlert,
  ChevronDown,
  MoreVertical,
  Ban,
  UserCheck,
  VolumeX,
  Volume2,
  Lock,
} from 'lucide-react';
import { playClickSound, playSuccessChime } from '../utils/sound';

export interface ChatMessage {
  id: string;
  username: string;
  text: string;
  role: 'admin' | 'vip' | 'user';
  tag?: 'masla' | 'help' | 'general' | 'feedback';
  timestamp: string;
  avatarColor: string;
  avatarUrl?: string;
  photoUrl?: string;
  audioVoiceUrl?: string;
  audioDuration?: number;
}

export interface ActiveUserItem {
  username: string;
  avatarUrl?: string;
}

interface LiveChatBoardProps {
  isOpen: boolean;
  onClose?: () => void;
  onlineCount: number;
  isLifetimeVip?: boolean;
  securityConfig?: {
    locked?: boolean;
    lockNotice?: string;
    requireVerification?: boolean;
    vipOnly?: boolean;
    botEnabled?: boolean;
  };
  isEmbedded?: boolean;
}

const CHAT_USERNAME_KEY = 'fadiking_chat_username';
const CHAT_AVATAR_KEY = 'fadiking_chat_avatar';
const CHAT_DEVICE_ID_KEY = 'fadiking_chat_device_id';

function getOrCreateDeviceId(): string {
  try {
    let id = localStorage.getItem(CHAT_DEVICE_ID_KEY);
    if (!id) {
      id = 'dev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 10);
      localStorage.setItem(CHAT_DEVICE_ID_KEY, id);
    }
    return id;
  } catch {
    return 'dev_fallback';
  }
}

const AVATAR_PRESETS = ['👑', '🦁', '🦅', '⚡', '🛡️', '💎', '🚀', '🔥', '🌟', '🎯'];

const EMOJI_PALETTE = [
  '👍', '🔥', '👑', '⚡', '❤️', '😂', '🚀', '💯', '✨', '🎉',
  '🙌', '👏', '😍', '🥳', '🚨', '❓', '💡', '💬', '💪', '🙏',
  '👌', '🤩', '😎', '🤝', '⭐', '💎', '🛡️', '🦁', '🦅', '🎯',
];

/**
 * Client-side Canvas Image Compressor
 * Downscales images to max 1280px and compresses to lightweight JPEG
 * Guarantees instant photo sending without network lag!
 */
function compressImage(file: File, maxWidth = 1200, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export const LiveChatBoard: React.FC<LiveChatBoardProps> = ({
  isOpen,
  onClose,
  onlineCount,
  isLifetimeVip,
  securityConfig,
  isEmbedded = false,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeUsersList, setActiveUsersList] = useState<ActiveUserItem[]>([]);
  const [showActiveUsers, setShowActiveUsers] = useState(false);

  const [username, setUsername] = useState<string>('');
  const [avatarUrl, setAvatarUrl] = useState<string>('');
  const [inputUsername, setInputUsername] = useState<string>('');
  const [inputText, setInputText] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<'masla' | 'help' | 'general' | 'feedback'>('general');
  const [sending, setSending] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);

  // Server-Wide Blocked Members List (synced via SSE & GET /api/chat)
  const [serverBlockedUsers, setServerBlockedUsers] = useState<string[]>([]);

  // Local Client-Side Mute in GC (Hide harassing users locally)
  const LOCAL_MUTED_KEY = 'fadiking_chat_muted_users';
  const [locallyMutedUsers, setLocallyMutedUsers] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(LOCAL_MUTED_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Profile Picture (Avatar / DP) Selection Modal - Name remains strictly locked, only DP can be updated
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [selectedAvatarTemp, setSelectedAvatarTemp] = useState<string>('');
  const avatarFileInputRef = useRef<HTMLInputElement | null>(null);

  // Photo Attachment state
  const [attachedPhoto, setAttachedPhoto] = useState<string | null>(null);
  const [compressingPhoto, setCompressingPhoto] = useState(false);
  const photoInputRef = useRef<HTMLInputElement | null>(null);

  // Deletion & Chat Clean state
  const LOCAL_DELETED_KEY = 'fadiking_chat_deleted_ids';
  const [locallyDeletedIds, setLocallyDeletedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('fadiking_chat_deleted_ids');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [activeMenuMsgId, setActiveMenuMsgId] = useState<string | null>(null);
  const [showClearModal, setShowClearModal] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // In-app alert / notice toast
  const [chatNotice, setChatNotice] = useState<string | null>(null);
  const showNotice = (msg: string) => {
    setChatNotice(msg);
    setTimeout(() => {
      setChatNotice((cur) => (cur === msg ? null : cur));
    }, 4500);
  };

  // Voice Note state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const selectedMimeRef = useRef<string>('audio/webm');
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const audioFileInputRef = useRef<HTMLInputElement | null>(null);

  // Playing audio state
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);

  // Emoji Drawer
  const [showEmojis, setShowEmojis] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Load permanently saved username & avatar
  useEffect(() => {
    try {
      const saved = localStorage.getItem(CHAT_USERNAME_KEY);
      if (saved) {
        setUsername(saved);
        setInputUsername(saved);
      }
      const savedAv = localStorage.getItem(CHAT_AVATAR_KEY);
      if (savedAv) {
        setAvatarUrl(savedAv);
      }
    } catch {}
  }, []);

  const loadMessages = async () => {
    try {
      const res = await fetch('/api/chat');
      const data = await res.json();
      if (data.success && Array.isArray(data.messages)) {
        setMessages(data.messages);
      }
      if (data.activeUsers && Array.isArray(data.activeUsers)) {
        setActiveUsersList(data.activeUsers);
      }
      if (data.blockedUsers && Array.isArray(data.blockedUsers)) {
        setServerBlockedUsers(data.blockedUsers);
        if (username && data.blockedUsers.some((b: string) => b.toLowerCase() === username.toLowerCase())) {
          setIsBlocked(true);
        } else if (username) {
          setIsBlocked(false);
        }
      }
    } catch (e) {
      console.warn('Could not load chat messages:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadMessages();
    }
  }, [isOpen, username]);

  // Periodic Presence Heartbeat & Block Check
  useEffect(() => {
    const reportPresence = async () => {
      try {
        const res = await fetch('/api/chat/presence', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: username || '',
            avatarUrl,
            isLifetimeVip,
            deviceId: getOrCreateDeviceId(),
          }),
        });
        const data = await res.json();
        if (data.activeUsers) setActiveUsersList(data.activeUsers);
        if (data.isBlocked !== undefined) setIsBlocked(data.isBlocked);
      } catch {}
    };

    reportPresence();
    const timer = window.setInterval(reportPresence, 15000);
    return () => clearInterval(timer);
  }, [username, avatarUrl, isLifetimeVip]);

  // Listen to live broadcast events
  useEffect(() => {
    const handleNewMessage = (e: any) => {
      if (e.detail) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === e.detail.id)) return prev;
          return [...prev, e.detail];
        });
        if (isOpen) {
          playSuccessChime();
        }
      }
    };

    const handleClearChat = () => {
      setMessages([]);
    };

    const handleMessageDelete = (e: any) => {
      if (e.detail?.messageId) {
        setMessages((prev) => prev.filter((m) => m.id !== e.detail.messageId));
      }
    };

    const handleUserBlocked = (e: any) => {
      const blockedName = e.detail?.username;
      if (blockedName) {
        setServerBlockedUsers((prev) => Array.from(new Set([...prev, blockedName])));
        if (username && blockedName.toLowerCase() === username.toLowerCase()) {
          setIsBlocked(true);
        }
      }
    };

    const handleUserUnblocked = (e: any) => {
      const unblockedName = e.detail?.username;
      if (unblockedName) {
        setServerBlockedUsers((prev) =>
          prev.filter((b) => b.toLowerCase() !== unblockedName.toLowerCase())
        );
        if (username && unblockedName.toLowerCase() === username.toLowerCase()) {
          setIsBlocked(false);
        }
      } else {
        setIsBlocked(false);
      }
    };

    const handlePresenceUsers = (e: any) => {
      if (e.detail?.activeUsers) {
        setActiveUsersList(e.detail.activeUsers);
      }
    };

    window.addEventListener('fadiking-live-chat-message', handleNewMessage);
    window.addEventListener('fadiking-live-chat-clear', handleClearChat);
    window.addEventListener('fadiking-live-chat-delete', handleMessageDelete);
    window.addEventListener('fadiking-user-blocked', handleUserBlocked);
    window.addEventListener('fadiking-user-unblocked', handleUserUnblocked);
    window.addEventListener('fadiking-presence-users', handlePresenceUsers);

    return () => {
      window.removeEventListener('fadiking-live-chat-message', handleNewMessage);
      window.removeEventListener('fadiking-live-chat-clear', handleClearChat);
      window.removeEventListener('fadiking-live-chat-delete', handleMessageDelete);
      window.removeEventListener('fadiking-user-blocked', handleUserBlocked);
      window.removeEventListener('fadiking-user-unblocked', handleUserUnblocked);
      window.removeEventListener('fadiking-presence-users', handlePresenceUsers);
    };
  }, [isOpen, username]);

  // Auto-scroll
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  // Set Username once permanently (No repeated editing)
  const handleSetUsername = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUsername.trim()) return;
    const clean = inputUsername.trim().substring(0, 25);
    setUsername(clean);
    try {
      localStorage.setItem(CHAT_USERNAME_KEY, clean);
    } catch {}
    playClickSound();
  };

  // Local Client-Side Mute / Hide in GC
  const handleToggleLocalMute = (targetUsername: string) => {
    playClickSound();
    const clean = targetUsername.toLowerCase();
    setLocallyMutedUsers((prev) => {
      const next = prev.includes(clean) ? prev.filter((u) => u !== clean) : [...prev, clean];
      try {
        localStorage.setItem(LOCAL_MUTED_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
    setActiveMenuMsgId(null);
  };

  // Admin Block & Unblock directly from GC
  const getAdminPassword = (): string | null => {
    try {
      const saved = localStorage.getItem('fadiking_admin_password');
      if (saved) return saved;
    } catch {}
    const entered = window.prompt('Enter Admin Password to manage Group Chat blocks:');
    if (entered) {
      try {
        localStorage.setItem('fadiking_admin_password', entered);
      } catch {}
      return entered;
    }
    return null;
  };

  const handleAdminBlock = async (targetUsername: string) => {
    playClickSound();
    const pwd = getAdminPassword();
    if (!pwd) return;

    try {
      const res = await fetch('/api/admin/block-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': pwd,
        },
        body: JSON.stringify({ username: targetUsername }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setServerBlockedUsers((prev) => Array.from(new Set([...prev, targetUsername])));
        if (targetUsername.toLowerCase() === username.toLowerCase()) {
          setIsBlocked(true);
        }
        alert(`User "${targetUsername}" ko Group Chat se block kar diya gaya hai. Ab unke messages band ho gaye hain.`);
      } else {
        alert(data.error || 'Block karne mein masla pesh aya.');
      }
    } catch {
      alert('Network error while blocking user.');
    } finally {
      setActiveMenuMsgId(null);
    }
  };

  const handleAdminUnblock = async (targetUsername: string) => {
    playClickSound();
    const pwd = getAdminPassword();
    if (!pwd) return;

    try {
      const res = await fetch('/api/admin/unblock-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': pwd,
        },
        body: JSON.stringify({ username: targetUsername }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setServerBlockedUsers((prev) =>
          prev.filter((b) => b.toLowerCase() !== targetUsername.toLowerCase())
        );
        if (targetUsername.toLowerCase() === username.toLowerCase()) {
          setIsBlocked(false);
        }
        alert(`User "${targetUsername}" ko unblock kar diya gaya hai. Ab unke messages dubara aana shuru ho jayenge!`);
      } else {
        alert(data.error || 'Unblock karne mein masla pesh aya.');
      }
    } catch {
      alert('Network error while unblocking user.');
    } finally {
      setActiveMenuMsgId(null);
    }
  };

  // Profile DP (Avatar Image / Emoji) Selection Handlers
  const openAvatarPicker = () => {
    playClickSound();
    setSelectedAvatarTemp(avatarUrl || '👑');
    setShowAvatarModal(true);
  };

  const handleSaveAvatar = () => {
    playClickSound();
    const newAv = selectedAvatarTemp || '👑';
    setAvatarUrl(newAv);
    try {
      localStorage.setItem(CHAT_AVATAR_KEY, newAv);
    } catch {}
    setShowAvatarModal(false);
  };

  const handleAvatarFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file, 260, 0.85);
      setSelectedAvatarTemp(compressed);
      playClickSound();
    } catch {
      alert('Photo process nahi ho saki.');
    }
  };

  // High-Resolution Photo Selection with Automatic Canvas Compression
  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCompressingPhoto(true);
    try {
      const compressedDataUrl = await compressImage(file, 1200, 0.82);
      setAttachedPhoto(compressedDataUrl);
      playClickSound();
    } catch (err) {
      alert('Could not process photo.');
    } finally {
      setCompressingPhoto(false);
    }
  };

  // Deletion Handlers: Delete for Me & Delete for Everyone
  const handleDeleteForMe = (msgId: string) => {
    playClickSound();
    setLocallyDeletedIds((prev) => {
      const next = [...prev, msgId];
      try {
        localStorage.setItem(LOCAL_DELETED_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
    setActiveMenuMsgId(null);
  };

  const handleDeleteForEveryone = async (msgId: string) => {
    playClickSound();
    if (!confirm('Kya aap waqayi yeh message SAB KE LIYE delete karna chahte hain?')) return;
    setDeletingId(msgId);
    try {
      const res = await fetch(`/api/chat/message/${encodeURIComponent(msgId)}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessages((prev) => prev.filter((m) => m.id !== msgId));
      } else {
        alert(data.error || 'Message delete nahi ho saka.');
      }
    } catch {
      alert('Network error: Message delete nahi ho saka.');
    } finally {
      setDeletingId(null);
      setActiveMenuMsgId(null);
    }
  };

  const handleClearForMe = () => {
    playClickSound();
    const allIds = messages.map((m) => m.id);
    setLocallyDeletedIds((prev) => {
      const next = Array.from(new Set([...prev, ...allIds]));
      try {
        localStorage.setItem(LOCAL_DELETED_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
    setShowClearModal(false);
  };

  // High-Compatibility Voice Note Recording with Audio File Fallback & Permission Guard
  const handleAudioFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) {
      showNotice('Audio file ka size 12MB se kam hona chahiye.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const base64Audio = reader.result as string;
      sendActualMessage('', undefined, base64Audio, 5);
      showNotice('Voice note kamyabi se bhej diya gaya!');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const startRecording = async () => {
    if (isBlocked) {
      showNotice('Aap blocked hain, voice note nahi bhej sakte.');
      return;
    }
    if (!username.trim()) {
      showNotice('Pehle apna naam likh kar chat room join karein.');
      return;
    }

    if (!navigator?.mediaDevices?.getUserMedia) {
      showNotice('Is device/browser mein direct mic recording allow nahi hai. Audio file select karke bhejein.');
      setTimeout(() => {
        audioFileInputRef.current?.click();
      }, 250);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      audioChunksRef.current = [];

      // Determine supported mime type
      const mimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/aac',
        'audio/ogg',
      ];
      let selectedMime = '';
      for (const mime of mimeTypes) {
        if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(mime)) {
          selectedMime = mime;
          break;
        }
      }
      selectedMimeRef.current = selectedMime || 'audio/webm';

      const mediaRecorder = selectedMime
        ? new MediaRecorder(stream, { mimeType: selectedMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setRecordingSeconds(0);
      playClickSound();

      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      // Graceful fallback for permission denied or hardware unavailable
      console.warn('Microphone permission info:', err?.message || err);
      showNotice('Microphone access browser mein blocked hai. Aap voice note file choose karke bhej sakte hain.');
      setTimeout(() => {
        audioFileInputRef.current?.click();
      }, 350);
    }
  };

  const cancelRecording = () => {
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsRecording(false);
    setRecordingSeconds(0);
    audioChunksRef.current = [];
    playClickSound();
  };

  const stopAndSendRecording = () => {
    if (!mediaRecorderRef.current || !isRecording) return;

    const duration = Math.max(1, recordingSeconds);
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    setIsRecording(false);

    const recorder = mediaRecorderRef.current;

    recorder.onstop = () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      const mime = selectedMimeRef.current || 'audio/webm';
      const audioBlob = new Blob(audioChunksRef.current, { type: mime });

      if (audioBlob.size < 200) {
        showNotice('Voice note bohot mukhtasir hai. Baraye meharbani bolte huay voice note record karein.');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64Audio = reader.result as string;
        sendActualMessage('', undefined, base64Audio, duration);
      };
      reader.readAsDataURL(audioBlob);
    };

    if (recorder.state !== 'inactive') {
      try {
        recorder.stop();
      } catch {}
    }
    playClickSound();
  };

  // Play / Pause voice memo in chat
  const togglePlayVoice = (msgId: string, audioUrl: string) => {
    playClickSound();
    if (playingAudioId === msgId) {
      audioElRef.current?.pause();
      setPlayingAudioId(null);
    } else {
      if (audioElRef.current) {
        audioElRef.current.pause();
      }
      audioElRef.current = new Audio(audioUrl);
      audioElRef.current.play().catch(() => {});
      audioElRef.current.onended = () => {
        setPlayingAudioId(null);
      };
      setPlayingAudioId(msgId);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (securityConfig?.locked) {
      alert(securityConfig.lockNotice || 'Live Chat is temporarily locked by Admin.');
      return;
    }

    if (securityConfig?.vipOnly && !isLifetimeVip) {
      alert('Live Chat is currently restricted to VIP Lifetime Members.');
      return;
    }

    if (isBlocked) {
      alert('Aapko Admin ne block kiya hua hai. Aap message nahi bhej sakte.');
      return;
    }

    if (!inputText.trim() && !attachedPhoto) return;

    const textToSend = inputText.trim();
    const photoToSend = attachedPhoto || undefined;

    setInputText('');
    setAttachedPhoto(null);
    setShowEmojis(false);
    sendActualMessage(textToSend, photoToSend);
  };

  const sendActualMessage = async (
    text: string,
    photo?: string,
    audioVoice?: string,
    duration?: number
  ) => {
    setSending(true);
    playClickSound();

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          avatarUrl: avatarUrl || undefined,
          text,
          tag: selectedTag,
          photoUrl: photo,
          audioVoiceUrl: audioVoice,
          audioDuration: duration,
          isLifetimeVip,
          deviceId: getOrCreateDeviceId(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        if (data.blocked) {
          setIsBlocked(true);
        }
        alert(data.error || 'Failed to send message.');
        return;
      }

      if (data.success && data.message) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === data.message.id)) return prev;
          return [...prev, data.message];
        });
      }
    } catch (err) {
      alert('Network error: message could not be sent.');
    } finally {
      setSending(false);
    }
  };

  const insertEmoji = (emoji: string) => {
    playClickSound();
    setInputText((prev) => prev + emoji);
  };

  if (!isOpen) return null;

  const chatCard = (
    <div className={`relative w-full ${isEmbedded ? 'h-[580px] sm:h-[620px]' : 'max-w-2xl h-[92dvh] sm:h-[90vh] max-h-[720px]'} bg-neutral-900/60 border border-white/10 rounded-3xl shadow-2xl flex flex-col text-slate-100 overflow-hidden backdrop-blur-3xl`}>
      {/* Hidden File Input */}
      <input
        type="file"
        ref={photoInputRef}
        accept="image/*"
        onChange={handlePhotoSelect}
        className="hidden"
      />

      {/* Admin Lock / VIP Restriction Notice Bar */}
      {securityConfig?.locked && (
        <div className="px-4 py-2 bg-rose-950/90 border-b border-rose-500/40 text-rose-200 text-xs flex items-center gap-2 shrink-0">
          <Lock className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span className="font-semibold text-[11px] sm:text-xs">{securityConfig.lockNotice || 'Live Chat is temporarily locked by Admin.'}</span>
        </div>
      )}
      {securityConfig?.vipOnly && !isLifetimeVip && (
        <div className="px-4 py-2 bg-neutral-950/90 border-b border-white/15 text-white/90 text-xs flex items-center gap-2 shrink-0">
          <Crown className="w-3.5 h-3.5 text-white shrink-0" />
          <span className="font-semibold text-[11px] sm:text-xs">👑 VIP Restricted Mode: Only Lifetime members can send messages. Free visitors can read.</span>
        </div>
      )}

      {/* Header */}
      <div className="p-3.5 sm:p-4 bg-neutral-950/70 border-b border-white/10 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3 truncate">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#fef08a] via-[#d4af37] to-[#c68642] text-slate-950 shadow-lg shadow-amber-500/25 shrink-0 flex items-center justify-center relative border border-white/20">
            <div className="relative flex flex-col items-center justify-center -space-y-0.5">
              <Crown className="w-3 h-3 text-slate-950 fill-slate-950" />
              <Bot className="w-4 h-4 text-slate-950" />
            </div>
          </div>
            <div className="truncate">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white truncate">
                  Live Support & Global VIP Chat
                </h3>

                {/* Active Users Badge Button */}
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setShowActiveUsers(!showActiveUsers);
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 shrink-0 cursor-pointer transition-colors"
                  title="Click to view Active Users Roster"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>Active Users ({activeUsersList.length || onlineCount})</span>
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                Photo bhejein, voice note bhejain, ya masla share karein!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {username && (
              <button
                type="button"
                onClick={openAvatarPicker}
                className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/5 transition-colors cursor-pointer"
                title="Change Profile Picture (DP)"
              >
                <Camera className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => {
                playClickSound();
                onClose?.();
              }}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Active Online Members Roster Drawer with Direct GC Block & Unblock */}
        {showActiveUsers && (
          <div className="px-4 py-3 bg-black/80 border-b border-slate-800 text-xs animate-in slide-in-from-top-2 duration-150">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Currently Active Members ({activeUsersList.length || 1})</span>
              </span>
              <button
                onClick={() => setShowActiveUsers(false)}
                className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto">
              {activeUsersList.map((usr, i) => {
                const isBlockedOnServer = serverBlockedUsers.some(
                  (b) => b.toLowerCase() === usr.username.toLowerCase()
                );
                const isCurrentMe = usr.username.toLowerCase() === username.toLowerCase();
                const isLocallyMuted = locallyMutedUsers.includes(usr.username.toLowerCase());

                return (
                  <div
                    key={i}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[11px] ${
                      isBlockedOnServer
                        ? 'bg-red-950/40 border-red-500/40 text-red-200'
                        : 'bg-slate-900 border-slate-800 text-slate-200'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isBlockedOnServer ? 'bg-red-500' : 'bg-emerald-400'
                      }`}
                    />
                    <span className="font-medium truncate max-w-[110px]">{usr.username}</span>

                    {isBlockedOnServer && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-red-600 text-white font-bold">
                        BLOCKED
                      </span>
                    )}

                    {!isCurrentMe && (
                      <div className="flex items-center gap-1 ml-1 border-l border-slate-700/60 pl-1.5">
                        {isBlockedOnServer ? (
                          <button
                            type="button"
                            onClick={() => handleAdminUnblock(usr.username)}
                            className="px-1.5 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 transition-colors cursor-pointer"
                            title="Unblock user so their messages resume"
                          >
                            Unblock
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleAdminBlock(usr.username)}
                            className="px-1.5 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[10px] font-bold border border-rose-500/40 transition-colors cursor-pointer"
                            title="Block user from Group Chat"
                          >
                            Block
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleToggleLocalMute(usr.username)}
                          className="px-1 text-[10px] text-slate-400 hover:text-white cursor-pointer"
                          title="Mute/Unmute user for yourself"
                        >
                          {isLocallyMuted ? 'Unmute' : 'Mute'}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Initial Username Screen */}
        {!username ? (
          <div className="flex-1 flex items-center justify-center p-6 text-center">
            <form onSubmit={handleSetUsername} className="w-full max-w-sm space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 mx-auto flex items-center justify-center text-amber-400">
                <User className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-lg font-black text-white">Enter Your Chat Name</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Chat board mein apna naam enter karein taake sab aapko pehchan sakein:
                </p>
              </div>

              <input
                type="text"
                required
                value={inputUsername}
                onChange={(e) => setInputUsername(e.target.value)}
                placeholder="e.g. Ali, King_Fahad, Usman..."
                maxLength={25}
                className="w-full px-4 py-3 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-center text-sm text-white placeholder-slate-500 outline-none"
              />

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
              >
                Join Live Chat
              </button>
            </form>
          </div>
        ) : (
          /* Active Chat Screen */
          <>
            {/* Top Sub-Bar */}
            <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400 shrink-0">
              <div className="flex items-center gap-2">
                <span>Chatting as:</span>
                <span className="font-bold text-amber-300 font-mono flex items-center gap-1">
                  {avatarUrl && avatarUrl.length < 5 ? <span>{avatarUrl}</span> : null}
                  <span>{username}</span>
                </span>
                {isLifetimeVip && (
                  <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 text-[10px] font-bold">
                    VIP
                  </span>
                )}
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 font-medium flex items-center gap-1 ml-1" title="Name is permanently locked to this device">
                  <Lock className="w-2.5 h-2.5" />
                  <span>Permanent (Locked)</span>
                </span>
                <button
                  type="button"
                  onClick={openAvatarPicker}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 text-[10px] font-bold border border-amber-500/30 transition-colors cursor-pointer ml-1"
                  title="Profile picture lagayein ya tabdeel karein"
                >
                  <Camera className="w-3 h-3 text-amber-400" />
                  <span>Profile DP</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    playClickSound();
                    setShowClearModal(true);
                  }}
                  className="flex items-center gap-1 text-slate-400 hover:text-red-400 cursor-pointer text-[11px] px-2 py-0.5 rounded-md hover:bg-white/5 transition-colors"
                  title="Chat clean / clear options"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                  <span>Clear Chat</span>
                </button>

                <button
                  onClick={() => {
                    playClickSound();
                    loadMessages();
                  }}
                  className="flex items-center gap-1 text-slate-400 hover:text-white cursor-pointer text-[11px]"
                  title="Refresh messages"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Refresh</span>
                </button>
              </div>
            </div>

            {/* Blocked Notification Banner */}
            {isBlocked && (
              <div className="p-2.5 bg-red-950/80 border-b border-red-500/50 text-red-200 text-xs flex items-center gap-2 justify-center shrink-0">
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                <span>Aapko Admin ki taraf se block kar diya gaya hai. Aap message nahi bhej sakte.</span>
              </div>
            )}

            {/* Chat Messages Feed */}
            {(() => {
              const visibleMessages = messages.filter(
                (m) =>
                  !locallyDeletedIds.includes(m.id) &&
                  !locallyMutedUsers.includes(m.username.toLowerCase())
              );
              return (
                <div className="flex-1 p-4 overflow-y-auto space-y-3.5 scroll-smooth">
                  {visibleMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
                      <MessageCircle className="w-12 h-12 text-slate-700 mb-2 animate-bounce" />
                      <p className="text-sm font-semibold text-slate-400">No messages yet!</p>
                      <p className="text-xs text-slate-600 mt-1">
                        Photo, voice note, ya koi bhi sawal neeche se bhejain.
                      </p>
                    </div>
                  ) : (
                    visibleMessages.map((msg) => {
                      const isMe = msg.username.toLowerCase() === username.toLowerCase();
                      const isAdmin = msg.role === 'admin';
                      const isVip = msg.role === 'vip';
                      const isUserBlockedOnServer = serverBlockedUsers.some(
                        (b) => b.toLowerCase() === msg.username.toLowerCase()
                      );
                      const isLocallyMuted = locallyMutedUsers.includes(msg.username.toLowerCase());

                      return (
                        <div
                          key={msg.id}
                          className={`flex gap-3 text-xs animate-in fade-in duration-150 ${
                            isMe ? 'flex-row-reverse' : 'flex-row'
                          }`}
                        >
                          {/* Avatar */}
                          {msg.avatarUrl && msg.avatarUrl.startsWith('data:image') ? (
                            <img
                              src={msg.avatarUrl}
                              alt={msg.username}
                              className="w-8 h-8 rounded-xl object-cover shrink-0 shadow-sm border border-slate-700"
                            />
                          ) : (
                            <div
                              className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-slate-950 shrink-0 shadow-sm text-sm"
                              style={{ backgroundColor: msg.avatarColor || '#eab308' }}
                            >
                              {msg.avatarUrl && msg.avatarUrl.length < 5
                                ? msg.avatarUrl
                                : isAdmin
                                ? '👑'
                                : msg.username.charAt(0).toUpperCase()}
                            </div>
                          )}

                          {/* Bubble */}
                          <div
                            className={`max-w-[80%] rounded-2xl p-3 shadow-md space-y-1.5 relative group ${
                              isAdmin
                                ? 'bg-gradient-to-r from-amber-950/70 via-slate-900 to-amber-950/70 border border-amber-500/40 text-slate-100'
                                : isMe
                                ? 'bg-gradient-to-r from-amber-600 to-yellow-600 text-slate-950 font-medium'
                                : 'bg-slate-900/90 border border-slate-800 text-slate-200'
                            }`}
                          >
                            {/* Header: Name + Badge + Tag + Delete Options */}
                            <div
                              className={`flex items-center gap-1.5 text-[10px] ${
                                isMe ? 'text-slate-950/80 font-bold' : 'text-slate-400'
                              }`}
                            >
                              <span className="font-bold truncate max-w-[120px]">{msg.username}</span>

                              {isAdmin && (
                                <span className="px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 font-black text-[9px] shadow-sm">
                                  ADMIN
                                </span>
                              )}

                              {isVip && !isAdmin && (
                                <span className="px-1.5 py-0.2 rounded bg-cyan-400/20 text-cyan-300 font-bold text-[9px]">
                                  VIP
                                </span>
                              )}

                              {isUserBlockedOnServer && (
                                <span className="px-1.5 py-0.2 rounded bg-red-600 text-white font-bold text-[9px]">
                                  BLOCKED
                                </span>
                              )}

                              {msg.tag === 'masla' && (
                                <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-bold text-[9px] flex items-center gap-0.5">
                                  <AlertTriangle className="w-2.5 h-2.5" />
                                  <span>Masla</span>
                                </span>
                              )}

                              {msg.tag === 'help' && (
                                <span className="px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 font-bold text-[9px] flex items-center gap-0.5">
                                  <HelpCircle className="w-2.5 h-2.5" />
                                  <span>Help</span>
                                </span>
                              )}

                              <span className="opacity-60 text-[9px] ml-auto">
                                {new Date(msg.timestamp).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>

                              {/* 3-Dots Action Popover */}
                              <div className="relative inline-block">
                                <button
                                  type="button"
                                  onClick={() => {
                                    playClickSound();
                                    setActiveMenuMsgId(activeMenuMsgId === msg.id ? null : msg.id);
                                  }}
                                  className="p-0.5 rounded hover:bg-black/20 text-current opacity-70 hover:opacity-100 transition-opacity cursor-pointer"
                                  title="Options"
                                >
                                  <MoreVertical className="w-3 h-3" />
                                </button>

                                {activeMenuMsgId === msg.id && (
                                  <div className="absolute right-0 top-full mt-1 w-52 bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl py-1 z-30 text-[11px] text-slate-200">
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteForMe(msg.id)}
                                      className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors cursor-pointer text-slate-300 hover:text-white"
                                    >
                                      <Trash2 className="w-3 h-3 text-slate-400" />
                                      <span>Delete for me</span>
                                    </button>

                                    {(isMe || isAdmin) && (
                                      <button
                                        type="button"
                                        disabled={deletingId === msg.id}
                                        onClick={() => handleDeleteForEveryone(msg.id)}
                                        className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-red-500/20 text-left transition-colors cursor-pointer text-red-300 hover:text-red-200"
                                      >
                                        <Trash2 className="w-3 h-3 text-red-400" />
                                        <span>{deletingId === msg.id ? 'Deleting...' : 'Delete for everyone'}</span>
                                      </button>
                                    )}

                                    {!isMe && (
                                      <>
                                        <button
                                          type="button"
                                          onClick={() => handleToggleLocalMute(msg.username)}
                                          className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-white/10 text-left transition-colors cursor-pointer text-amber-300 hover:text-amber-200 border-t border-slate-800"
                                        >
                                          {isLocallyMuted ? (
                                            <>
                                              <Volume2 className="w-3 h-3 text-amber-400" />
                                              <span>Unmute {msg.username} in GC</span>
                                            </>
                                          ) : (
                                            <>
                                              <VolumeX className="w-3 h-3 text-amber-400" />
                                              <span>Mute / Hide {msg.username} in GC</span>
                                            </>
                                          )}
                                        </button>

                                        {isUserBlockedOnServer ? (
                                          <button
                                            type="button"
                                            onClick={() => handleAdminUnblock(msg.username)}
                                            className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-emerald-500/20 text-left transition-colors cursor-pointer text-emerald-300 hover:text-emerald-200 border-t border-slate-800"
                                          >
                                            <Check className="w-3 h-3 text-emerald-400" />
                                            <span>Unblock {msg.username} (Allow Chat)</span>
                                          </button>
                                        ) : (
                                          <button
                                            type="button"
                                            onClick={() => handleAdminBlock(msg.username)}
                                            className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-rose-500/20 text-left transition-colors cursor-pointer text-rose-300 hover:text-rose-200 border-t border-slate-800"
                                          >
                                            <Ban className="w-3 h-3 text-rose-400" />
                                            <span>Block {msg.username} from Group Chat</span>
                                          </button>
                                        )}
                                      </>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>

                        {/* Text Message */}
                        {msg.text && (
                          <p className="text-xs leading-relaxed whitespace-pre-wrap break-words">
                            {msg.text}
                          </p>
                        )}

                        {/* Photo Attachment */}
                        {msg.photoUrl && (
                          <div className="pt-1">
                            <img
                              src={msg.photoUrl}
                              alt="Attachment"
                              className="rounded-xl max-h-56 w-auto object-cover border border-black/30 shadow-md cursor-pointer hover:opacity-95"
                              onClick={() => window.open(msg.photoUrl, '_blank')}
                            />
                          </div>
                        )}

                        {/* Voice Note Audio Bubble */}
                        {msg.audioVoiceUrl && (
                          <div className="pt-1 flex items-center gap-2.5 bg-black/30 p-2 rounded-xl border border-white/10">
                            <button
                              type="button"
                              onClick={() => togglePlayVoice(msg.id, msg.audioVoiceUrl!)}
                              className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 cursor-pointer shadow-md ${
                                isMe ? 'bg-slate-950 text-amber-400' : 'bg-amber-400 text-slate-950'
                              }`}
                            >
                              {playingAudioId === msg.id ? (
                                <Pause className="w-4 h-4 fill-current" />
                              ) : (
                                <Play className="w-4 h-4 fill-current ml-0.5" />
                              )}
                            </button>

                            <div className="flex-1">
                              <div className="flex items-center gap-1 h-3">
                                <span className={`w-1 h-2 rounded-full ${playingAudioId === msg.id ? 'animate-pulse bg-amber-400' : 'bg-slate-500'}`} />
                                <span className={`w-1 h-3 rounded-full ${playingAudioId === msg.id ? 'animate-pulse bg-amber-400 delay-75' : 'bg-slate-500'}`} />
                                <span className={`w-1 h-1.5 rounded-full ${playingAudioId === msg.id ? 'animate-pulse bg-amber-400 delay-150' : 'bg-slate-500'}`} />
                                <span className={`w-1 h-2.5 rounded-full ${playingAudioId === msg.id ? 'animate-pulse bg-amber-400 delay-100' : 'bg-slate-500'}`} />
                                <span className={`w-1 h-2 rounded-full ${playingAudioId === msg.id ? 'animate-pulse bg-amber-400' : 'bg-slate-500'}`} />
                              </div>
                              <span className="text-[10px] opacity-75 font-mono">
                                Voice Note {msg.audioDuration ? `(${msg.audioDuration}s)` : ''}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>
          );
        })()}

            {/* Photo Attachment Preview */}
            {attachedPhoto && (
              <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex items-center gap-3">
                <img
                  src={attachedPhoto}
                  alt="Attachment Preview"
                  className="w-12 h-12 rounded-lg object-cover border border-amber-400/40"
                />
                <span className="text-xs text-slate-300 truncate flex-1">
                  Photo ready to send with message
                </span>
                <button
                  type="button"
                  onClick={() => setAttachedPhoto(null)}
                  className="p-1 rounded text-slate-400 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Voice Recording Live Bar */}
            {isRecording && (
              <div className="px-4 py-3 bg-red-950/60 border-t border-red-500/50 flex items-center justify-between gap-3 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                  <span className="text-xs font-bold text-red-200">
                    Recording Voice Note: {recordingSeconds}s
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={cancelRecording}
                    className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs text-slate-300 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={stopAndSendRecording}
                    className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3 h-3" />
                    <span>Send Audio</span>
                  </button>
                </div>
              </div>
            )}

            {/* Emoji Drawer Popover */}
            {showEmojis && (
              <div className="p-3 bg-black/90 border-t border-slate-800 max-h-36 overflow-y-auto grid grid-cols-10 gap-1 animate-in fade-in">
                {EMOJI_PALETTE.map((em) => (
                  <button
                    key={em}
                    type="button"
                    onClick={() => insertEmoji(em)}
                    className="text-lg p-1.5 hover:scale-125 transition-transform cursor-pointer rounded hover:bg-white/5"
                  >
                    {em}
                  </button>
                ))}
              </div>
            )}

            {/* Tag Selection & Quick Action Bar */}
            <div className="px-4 py-1.5 bg-black/40 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0 text-xs">
              <div className="flex items-center gap-1 overflow-x-auto py-0.5">
                <span className="text-[10px] text-slate-500 font-semibold mr-1">Topic:</span>
                <button
                  type="button"
                  onClick={() => setSelectedTag('general')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                    selectedTag === 'general' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  General
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTag('masla')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                    selectedTag === 'masla' ? 'bg-rose-500 text-white font-bold' : 'bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  🚨 Masla
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTag('help')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                    selectedTag === 'help' ? 'bg-blue-500 text-white font-bold' : 'bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  Madad
                </button>
              </div>

              {/* Action Buttons: Emojis, Photo, Voice */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowEmojis(!showEmojis)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/5 transition-colors cursor-pointer"
                  title="Emojis"
                >
                  <Smile className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  disabled={compressingPhoto || isBlocked}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-white/5 transition-colors cursor-pointer disabled:opacity-50"
                  title="Attach Photo / Screenshot"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={startRecording}
                  disabled={isRecording || isBlocked}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/5 transition-colors cursor-pointer disabled:opacity-50"
                  title="Record Voice Note"
                >
                  <Mic className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Message Compose Form */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                disabled={isBlocked}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  isBlocked
                    ? 'Aap blocked hain, message nahi bhej sakte...'
                    : selectedTag === 'masla'
                    ? 'Apna masla likhein, photo ya voice note bhejain...'
                    : 'Type a message in live chat...'
                }
                className="flex-1 px-4 py-2.5 bg-black/60 border border-slate-700 focus:border-amber-400 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 outline-none disabled:opacity-40 disabled:cursor-not-allowed"
              />

              <button
                type="submit"
                disabled={sending || isBlocked || (!inputText.trim() && !attachedPhoto)}
                className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-amber-950/40 active:scale-95 transition-all disabled:opacity-50 cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">{sending ? 'Sending...' : 'Send'}</span>
              </button>
            </form>
          </>
        )}
        {/* Clear Chat Options Modal */}
        {showClearModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
            <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-[#080d1a] border border-amber-500/40 rounded-2xl shadow-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <Trash2 className="w-4 h-4 text-rose-400" />
                  <span>Clear Chat Screen</span>
                </div>
                <button
                  onClick={() => setShowClearModal(false)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Kya aap apni screen se tamam messages saaf karna chahte hain?
              </p>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleClearForMe}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Haan, Mere Liye Chat Saaf Karein</span>
                </button>

                <p className="text-[11px] text-slate-400 text-center">
                  Tamam community chat sab ke liye saaf karne ka option Admin Panel mein mojood hai.
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowClearModal(false)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Profile DP / Avatar Selection Modal (Name is Strictly Locked, Only DP can be changed) */}
        {showAvatarModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
            <div className="w-full max-w-sm bg-gradient-to-b from-[#0b1224] to-[#080d1a] border border-amber-500/40 rounded-3xl shadow-2xl p-5 space-y-4 text-slate-100">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span>Set Profile Picture (DP)</span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAvatarModal(false)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Username Info - Strictly Read-Only & Permanent */}
              <div className="p-3 rounded-xl bg-black/50 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 block text-[10px]">Your Chat Name</span>
                  <span className="font-bold text-amber-300 font-mono text-sm">{username}</span>
                </div>
                <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 font-bold">
                  <Lock className="w-2.5 h-2.5" />
                  <span>Name Locked</span>
                </span>
              </div>

              {/* Current Preview */}
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-900/80 border border-amber-500/20">
                {selectedAvatarTemp && selectedAvatarTemp.startsWith('data:image') ? (
                  <img
                    src={selectedAvatarTemp}
                    alt="Preview"
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-2xl shadow-md text-slate-950 font-bold">
                    {selectedAvatarTemp || '👑'}
                  </div>
                )}
                <div>
                  <span className="text-xs font-bold text-white block">Selected Avatar Preview</span>
                  <span className="text-[11px] text-slate-400">Ye photo sab ko chat mein nazar aayegi</span>
                </div>
              </div>

              {/* Choose Preset Avatar Emojis */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2">Choose Avatar Preset:</label>
                <div className="grid grid-cols-5 gap-2">
                  {AVATAR_PRESETS.map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setSelectedAvatarTemp(icon);
                      }}
                      className={`h-10 rounded-xl flex items-center justify-center text-lg border transition-all cursor-pointer ${
                        selectedAvatarTemp === icon
                          ? 'bg-amber-400/20 border-amber-400 scale-110 shadow-md'
                          : 'bg-black/40 border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload Custom Photo from Device */}
              <div>
                <input
                  type="file"
                  ref={avatarFileInputRef}
                  accept="image/*"
                  onChange={handleAvatarFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => avatarFileInputRef.current?.click()}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span>Gallery / Camera Se Photo Upload Karein</span>
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAvatarModal(false)}
                  className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveAvatar}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#fef08a] via-[#d4af37] to-[#f39c12] hover:from-[#fff59d] hover:to-[#d4af37] text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer active:scale-95"
                >
                  Save Profile DP
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );

    if (isEmbedded) {
      return chatCard;
    }

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-hidden animate-in fade-in duration-200">
        {chatCard}
      </div>
    );
};
