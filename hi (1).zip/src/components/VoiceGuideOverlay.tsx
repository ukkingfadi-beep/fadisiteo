import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Sparkles, X, RotateCcw } from 'lucide-react';
import {
  VoiceGuideMessage,
  isVoiceGuideActive,
  setVoiceGuideActive,
  speakFeature,
} from '../utils/voiceGuide';
import { playClickSound } from '../utils/sound';

export const VoiceGuideOverlay: React.FC = () => {
  const [currentMessage, setCurrentMessage] = useState<VoiceGuideMessage | null>(null);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [isVisible, setIsVisible] = useState<boolean>(false);

  useEffect(() => {
    setIsActive(isVoiceGuideActive());

    const handleSpeak = (e: Event) => {
      const customEvent = e as CustomEvent<VoiceGuideMessage>;
      if (customEvent.detail) {
        setCurrentMessage(customEvent.detail);
        setIsVisible(true);
      }
    };

    const handleToggle = (e: Event) => {
      const customEvent = e as CustomEvent<boolean>;
      setIsActive(customEvent.detail);
    };

    window.addEventListener('fadiking-voice-speak', handleSpeak);
    window.addEventListener('fadiking-voice-toggle', handleToggle);

    return () => {
      window.removeEventListener('fadiking-voice-speak', handleSpeak);
      window.removeEventListener('fadiking-voice-toggle', handleToggle);
    };
  }, []);

  // Auto-hide toast after 7 seconds
  useEffect(() => {
    if (!isVisible) return;
    const t = setTimeout(() => {
      setIsVisible(false);
    }, 7000);
    return () => clearTimeout(t);
  }, [isVisible, currentMessage?.spokenAt]);

  const toggleActive = () => {
    playClickSound();
    const next = !isActive;
    setIsActive(next);
    setVoiceGuideActive(next);
    if (next) {
      speakFeature(
        'Voice Guide Active',
        'Voice guide on ho gaya hai. Ab aap website par jis bhi button ya option par click karenge, woh bol kar apna kaam batayega.',
        true
      );
    }
  };

  const handleReplay = () => {
    if (currentMessage) {
      playClickSound();
      speakFeature(currentMessage.title, currentMessage.text, true);
    }
  };

  return (
    <>
      {/* Floating Global Voice Guide Status Button (bottom-left) */}
      <div className="fixed bottom-4 left-4 z-40 hidden sm:flex items-center gap-2">
        <button
          type="button"
          onClick={toggleActive}
          className={`px-3 py-1.5 rounded-full backdrop-blur-xl border text-xs font-bold shadow-xl transition-all flex items-center gap-2 cursor-pointer ${
            isActive
              ? 'bg-[#1e130a]/90 border-amber-500/50 text-amber-300 hover:bg-[#28190d]'
              : 'bg-black/80 border-slate-700 text-slate-400 hover:text-white'
          }`}
          title="Toggle Urdu/Hindi Interactive Voice Guide"
        >
          {isActive ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <Volume2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Voice Guide: ON (بول کر بتانے والا)</span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5 text-slate-500" />
              <span>Voice Guide: OFF</span>
            </>
          )}
        </button>
      </div>

      {/* Spoken Subtitle Banner / Notification Toast (Center Bottom) */}
      {isVisible && currentMessage && (
        <aside
          role="status"
          aria-live="polite"
          aria-label={`Voice Guide Announcement: ${currentMessage.title}`}
          className="fixed bottom-16 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-xl animate-in fade-in slide-in-from-bottom-3 duration-200"
        >
          <div className="rounded-2xl bg-[#140b06]/95 border-2 border-amber-500/60 p-3 sm:p-4 shadow-[0_10px_35px_rgba(0,0,0,0.95)] backdrop-blur-2xl flex items-start gap-3 text-left">
            {/* Audio Wave Icon */}
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center shrink-0 shadow-md">
              <Volume2 className="w-5 h-5 animate-bounce" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2 mb-0.5">
                <span className="text-[11px] font-black uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Mera Kaam: {currentMessage.title}</span>
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleReplay}
                    className="p-1 rounded-md text-amber-300 hover:text-white hover:bg-white/10 text-[10px] flex items-center gap-1 cursor-pointer"
                    title="Dobara sunein (Listen Again)"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span className="hidden sm:inline">Replay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsVisible(false)}
                    className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-white font-medium leading-relaxed">
                "{currentMessage.text}"
              </p>
            </div>
          </div>
        </aside>
      )}
    </>
  );
};
