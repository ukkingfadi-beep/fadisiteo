import React, { useState, useEffect } from 'react';
import {
  Music2,
  Play,
  Pause,
  Volume2,
  VolumeX,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Radio,
  Sliders,
  Disc3,
  X,
} from 'lucide-react';
import { HOBBY_TRACKS, HobbyTrack, SiteConfigState } from '../utils/themeAndConfigManager';
import {
  playAmbientTune,
  stopAmbientTune,
  setAmbientVolume,
  isAmbientPlaying,
  setupAudioUnlocker,
} from '../utils/ambientMusicPlayer';
import { playClickSound } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

interface FloatingMusicWidgetProps {
  config: SiteConfigState;
  onOpenAdmin: () => void;
}

export const FloatingMusicWidget: React.FC<FloatingMusicWidgetProps> = ({
  config,
  onOpenAdmin,
}) => {
  const [playing, setPlaying] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [isMinimized, setIsMinimized] = useState(() => (typeof window !== 'undefined' ? window.innerWidth < 768 : false));
  const [selectedTrack, setSelectedTrack] = useState<string>(config.audio.selectedTrackId);
  const [volume, setVolume] = useState<number>(config.audio.volume || 30);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    setupAudioUnlocker();
  }, []);

  useEffect(() => {
    setSelectedTrack(config.audio.selectedTrackId);
    setVolume(config.audio.volume);
  }, [config.audio.selectedTrackId, config.audio.volume]);

  // Sync with global audio events
  useEffect(() => {
    const handleAudioEvent = (e: any) => {
      if (e.detail) {
        setPlaying(e.detail.isPlaying);
        if (e.detail.trackId) setSelectedTrack(e.detail.trackId);
      }
    };
    window.addEventListener('fadiking-audio-state-changed', handleAudioEvent);
    return () => window.removeEventListener('fadiking-audio-state-changed', handleAudioEvent);
  }, []);

  const togglePlay = () => {
    playClickSound();
    if (playing) {
      stopAmbientTune();
      setPlaying(false);
    } else {
      speakFeature(
        'Background Sad Music Player',
        'Mera kaam website ke background mein relaxing sad instrumental music bajana hai.'
      );
      playAmbientTune(selectedTrack, isMuted ? 0 : volume, config.audio.customTrackUrl);
      setPlaying(true);
    }
  };

  const handleSelectTrack = (trackId: string) => {
    playClickSound();
    setSelectedTrack(trackId);
    if (playing) {
      playAmbientTune(trackId, isMuted ? 0 : volume, config.audio.customTrackUrl);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setVolume(val);
    if (isMuted && val > 0) setIsMuted(false);
    setAmbientVolume(val);
  };

  const toggleMute = () => {
    playClickSound();
    if (isMuted) {
      setIsMuted(false);
      setAmbientVolume(volume);
    } else {
      setIsMuted(true);
      setAmbientVolume(0);
    }
  };

  if (!config.audio.bgMusicEnabled || !config.audio.showFloatingPlayer) {
    return null;
  }

  const currentTrackObj = HOBBY_TRACKS.find((t) => t.id === selectedTrack) || HOBBY_TRACKS[0];

  // If minimized into floating icon pill
  if (isMinimized) {
    return (
      <div className="fixed bottom-5 left-4 sm:left-6 z-40 transition-all duration-300">
        <button
          onClick={() => {
            playClickSound();
            setIsMinimized(false);
          }}
          className={`w-11 h-11 rounded-full flex items-center justify-center shadow-xl backdrop-blur-xl border transition-all cursor-pointer group active:scale-95 ${
            playing
              ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-amber-500/30 ring-2 ring-amber-400/50 animate-pulse'
              : 'bg-[#0b101d]/90 border-slate-700 text-slate-300 hover:text-amber-400 hover:border-amber-400/50'
          }`}
          title="Open Music Player"
          aria-label="Open Music Player"
        >
          {playing ? (
            <Disc3 className="w-5 h-5 animate-spin text-amber-400" />
          ) : (
            <Music2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
          )}
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-5 left-4 sm:left-6 z-40 transition-all duration-300 max-w-[calc(100vw-32px)]">
      <div className="bg-[#0b101d]/95 border border-amber-500/35 rounded-2xl shadow-2xl shadow-black/90 backdrop-blur-xl p-2.5 sm:p-3 text-slate-100 flex flex-col gap-2 w-64 sm:w-72 transition-all">
        {/* Main Bar */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 truncate flex-1 min-w-0">
            <button
              onClick={togglePlay}
              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-transform active:scale-95 cursor-pointer shadow-md ${
                playing
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black animate-pulse ring-1 ring-amber-400/60'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
              title={playing ? 'Pause Music' : 'Play Background Music'}
            >
              {playing ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
            </button>

            <div className="truncate text-left flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-[9px] uppercase font-bold tracking-wider text-amber-400 block leading-tight">
                  {playing ? 'Now Playing' : 'Audio Player'}
                </span>
                {playing && (
                  <span className="flex items-end gap-0.5 h-2">
                    <span className="w-0.5 h-full bg-amber-400 animate-pulse" />
                    <span className="w-0.5 h-1.5 bg-amber-400 animate-pulse delay-75" />
                    <span className="w-0.5 h-2 bg-amber-400 animate-pulse delay-150" />
                  </span>
                )}
              </div>
              <p className="text-[11px] font-bold text-white truncate">
                {currentTrackObj.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-0.5 shrink-0">
            {/* Mute button */}
            <button
              onClick={toggleMute}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || volume === 0 ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {/* Expand / Collapse tracks list */}
            <button
              onClick={() => {
                playClickSound();
                setExpanded(!expanded);
              }}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              title={expanded ? 'Collapse Tracks' : 'Select Track'}
            >
              {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>

            {/* Close / Minimize Button */}
            <button
              onClick={() => {
                playClickSound();
                setIsMinimized(true);
              }}
              className="p-1 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              title="Close Player"
              aria-label="Close Player"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Expandable Controls & Track List */}
        {expanded && (
          <div className="pt-2 border-t border-slate-800 space-y-2 animate-in fade-in duration-150">
            {/* Volume Slider */}
            <div className="flex items-center gap-2 px-1">
              <span className="text-[10px] text-slate-400 font-mono">Vol</span>
              <input
                type="range"
                min="0"
                max="100"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <span className="text-[10px] font-mono text-slate-300 w-6 text-right">
                {isMuted ? '0%' : `${volume}%`}
              </span>
            </div>

            {/* Track Selector List */}
            <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
              {HOBBY_TRACKS.map((track) => (
                <button
                  key={track.id}
                  onClick={() => handleSelectTrack(track.id)}
                  className={`w-full text-left p-1.5 rounded-lg text-xs flex items-center justify-between transition-colors cursor-pointer ${
                    selectedTrack === track.id
                      ? 'bg-amber-400/15 text-amber-300 font-semibold border border-amber-400/30'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="truncate">{track.name}</span>
                  <span className="text-[9px] font-mono opacity-60 ml-1 shrink-0">{track.genre}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
