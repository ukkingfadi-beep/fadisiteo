import React, { useState } from 'react';
import {
  Download,
  Play,
  QrCode,
  Music,
  Video,
  Image as ImageIcon,
  Check,
  Share2,
  Clock,
  User,
  Loader2,
  Crown,
  Sparkles,
  Zap,
  X,
  AlertTriangle,
} from 'lucide-react';
import type { VideoInfoResponse, VideoFormatOption } from '../types/downloader';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';
import { QrModal } from './QrModal';
import { playClickSound } from '../utils/sound';
import { canDownload, consumeDownload } from '../utils/quotaManager';

interface VideoResultCardProps {
  info: VideoInfoResponse;
  lang: Language;
  onDownloadStarted: (info: VideoInfoResponse, format: VideoFormatOption) => void;
  hasJoinedWhatsapp: boolean;
  onRequireWhatsappJoin: (pendingFormat: VideoFormatOption) => void;
  onOpenStudio?: () => void;
  onRequireUpgrade?: () => void;
}

export const VideoResultCard: React.FC<VideoResultCardProps> = ({
  info,
  lang,
  onDownloadStarted,
  hasJoinedWhatsapp,
  onRequireWhatsappJoin,
  onOpenStudio,
  onRequireUpgrade,
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'audio' | 'thumbnail'>('video');
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [previewError, setPreviewError] = useState(false);
  const [downloadingFormatId, setDownloadingFormatId] = useState<string | null>(null);
  const [downloadProgressText, setDownloadProgressText] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [qrModalUrl, setQrModalUrl] = useState<string | null>(null);

  const t = translations[lang];

  const videoFormats = info.formats.filter((f) => f.hasVideo);
  const audioFormats = info.formats.filter((f) => f.isAudioOnly || (!f.hasVideo && f.hasAudio));
  const imageFormats = info.formats.filter((f) => !f.hasVideo && !f.hasAudio && !f.isAudioOnly);

  // Dedicated High Quality & Normal Quality format resolution
  const highQualityFormat =
    info.formats.find(
      (f) =>
        f.qualityLabel.toLowerCase().includes('high') ||
        f.formatId.includes('1080') ||
        f.formatId.includes('hd') ||
        f.formatId.includes('orig')
    ) ||
    videoFormats[0] ||
    info.formats[0];

  const normalQualityFormat =
    info.formats.find(
      (f) =>
        f.qualityLabel.toLowerCase().includes('normal') ||
        f.formatId.includes('720') ||
        f.formatId.includes('sd') ||
        f.formatId.includes('normal')
    ) ||
    videoFormats[1] ||
    videoFormats[0] ||
    info.formats[1] ||
    info.formats[0];

  const primaryAudioFormat =
    audioFormats[0] || info.formats.find((f) => f.isAudioOnly || f.hasAudio);

  const getDirectDownloadUrl = (format: VideoFormatOption): string => {
    const cleanTitle = (info.title || 'video')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .substring(0, 50);
    const filename = `FADI_KING_${cleanTitle}_${format.qualityLabel.replace(/[\s\/\\]+/g, '_')}.${format.ext}`;

    if (format.directUrl) {
      return `/api/proxy-stream?url=${encodeURIComponent(format.directUrl)}&filename=${encodeURIComponent(filename)}`;
    }
    return `/api/download?url=${encodeURIComponent(info.originalUrl)}&formatId=${encodeURIComponent(format.formatId)}`;
  };

  const handleDownload = async (format: VideoFormatOption) => {
    // 1. Verify WhatsApp group membership first!
    if (!hasJoinedWhatsapp) {
      onRequireWhatsappJoin(format);
      return;
    }

    // 2. Enforce 5 video free download limit!
    if (!canDownload()) {
      if (onRequireUpgrade) {
        onRequireUpgrade();
      }
      return;
    }

    // Consume 1 credit from free quota (if not lifetime)
    consumeDownload();

    setDownloadingFormatId(format.formatId);
    setDownloadProgressText(lang === 'ur' ? 'VIP Speed Shuru...' : 'Preparing VIP Download...');
    onDownloadStarted(info, format);

    const cleanTitle = (info.title || 'video')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .substring(0, 50);
    const filename = `FADI_KING_${cleanTitle}_${format.qualityLabel.replace(/[\s\/\\]+/g, '_')}.${format.ext}`;

    try {
      const downloadLink = getDirectDownloadUrl(format);
      setDownloadProgressText(lang === 'ur' ? 'VIP Speed Shuru...' : 'Starting VIP Download...');

      // Direct native browser download anchor (Hands over to native Mobile & Desktop Download Manager)
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = downloadLink;
      a.setAttribute('download', filename);
      a.setAttribute('target', '_self');
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        try {
          if (document.body.contains(a)) {
            document.body.removeChild(a);
          }
        } catch {}
      }, 3000);
    } catch (err: any) {
      console.error('Download error:', err);
      const fallbackUrl = getDirectDownloadUrl(format);
      window.location.href = fallbackUrl;
    } finally {
      setTimeout(() => {
        setDownloadingFormatId(null);
        setDownloadProgressText('');
      }, 2500);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(info.originalUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const openQr = (format: VideoFormatOption) => {
    const downloadLink = `${window.location.origin}${getDirectDownloadUrl(format)}`;
    setQrModalUrl(downloadLink);
  };

  const previewStreamUrl = info.previewVideoUrl
    ? `/api/proxy-stream?url=${encodeURIComponent(info.previewVideoUrl)}&inline=true`
    : '';

  return (
    <div className="w-full max-w-4xl mx-auto mt-8 bg-slate-900/95 border-2 border-amber-500/30 rounded-3xl p-5 sm:p-7 vip-card-shadow backdrop-blur-2xl relative overflow-hidden">
      {/* Golden top decorative bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-500" />

      {/* Top Media & Meta layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start pb-6 border-b border-slate-800">
        {/* Media Preview Column */}
        <div className="md:col-span-5 relative rounded-2xl overflow-hidden bg-slate-950 aspect-video md:aspect-[4/3] border border-amber-500/20 shadow-xl group">
          {isPlayingPreview && previewStreamUrl && !previewError ? (
            <div className="relative w-full h-full bg-black flex items-center justify-center">
              <video
                src={previewStreamUrl}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-contain"
                onError={() => setPreviewError(true)}
              />
              <button
                onClick={() => {
                  setIsPlayingPreview(false);
                  setPreviewError(false);
                }}
                className="absolute top-3 right-3 p-1.5 rounded-full bg-slate-900/80 text-white hover:bg-slate-800 z-20 border border-slate-700 cursor-pointer shadow-lg"
                title="Close Preview"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <img
                src={info.thumbnailUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800'}
                alt={info.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30" />

              {info.previewVideoUrl && !previewError && (
                <button
                  onClick={() => {
                    setPreviewError(false);
                    setIsPlayingPreview(true);
                  }}
                  className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center shadow-xl shadow-amber-500/30 hover:scale-110 active:scale-95 transition-all cursor-pointer group-hover:shadow-amber-500/60"
                  title="Play Preview"
                >
                  <Play className="w-6 h-6 fill-slate-950 ml-0.5" />
                </button>
              )}

              {previewError && (
                <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center p-4 text-center">
                  <AlertTriangle className="w-8 h-8 text-amber-400 mb-2" />
                  <p className="text-xs text-slate-200 font-bold">
                    {lang === 'ur'
                      ? 'Live preview blocked hai, direct download ready hai:'
                      : 'Preview stream unavailable, direct download ready:'}
                  </p>
                  <button
                    onClick={() => {
                      if (videoFormats[0]) handleDownload(videoFormats[0]);
                    }}
                    className="mt-3 px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shadow-md"
                  >
                    Download Video Now
                  </button>
                </div>
              )}

              {info.durationFormatted && (
                <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-slate-200 flex items-center gap-1 shadow">
                  <Clock className="w-3 h-3 text-amber-400" />
                  {info.durationFormatted}
                </span>
              )}

              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-slate-950/80 border border-amber-500/40 text-[11px] font-bold text-amber-300 flex items-center gap-1 shadow">
                <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                {info.platformName}
              </span>
            </>
          )}
        </div>

        {/* Video Info Column */}
        <div className="md:col-span-7 flex flex-col justify-between h-full">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-[11px] font-black text-amber-400 uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {info.platform} VIP Ready
              </span>
              {info.isDirectStreamingAvailable && (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                  <Zap className="w-3 h-3 fill-emerald-400" />
                  Ultra Fast
                </span>
              )}
            </div>

            <h3 className="text-lg sm:text-xl font-black text-white line-clamp-2 leading-snug mb-3 hover:text-amber-300 transition-colors">
              {info.title}
            </h3>

            {info.author && (
              <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                <User className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-slate-300 font-semibold">{info.author}</span>
              </div>
            )}

            {info.description && (
              <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                {info.description}
              </p>
            )}
          </div>

          {/* Quick Actions Bar */}
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-800">
            <button
              onClick={handleCopyLink}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-bold">{t.linkCopied}</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>{t.copyLink}</span>
                </>
              )}
            </button>

            <a
              href={info.originalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-all"
            >
              <span>Original Post</span>
            </a>

            {onOpenStudio && (
              <button
                onClick={() => {
                  playClickSound();
                  onOpenStudio();
                }}
                className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-xs font-bold text-cyan-300 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Music className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open in Audio Studio</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Format Selection Tabs */}
      <div className="mt-6">
        <div className="flex items-center gap-2 p-1 rounded-2xl bg-slate-950 border border-slate-800 max-w-md mx-auto mb-6">
          <button
            onClick={() => setActiveTab('video')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'video'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>{videoFormats.length > 0 ? t.tabs.video : 'Media / Photo'}</span>
          </button>

          <button
            onClick={() => setActiveTab('audio')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'audio'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Music className="w-4 h-4" />
            <span>{t.tabs.audio}</span>
          </button>

          <button
            onClick={() => setActiveTab('thumbnail')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'thumbnail'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>{t.tabs.thumbnail}</span>
          </button>
        </div>

        {/* Tab 1: Video or Visual Media Formats List */}
        {activeTab === 'video' && (
          <div className="space-y-3">
            {(videoFormats.length > 0 ? videoFormats : imageFormats.length > 0 ? imageFormats : info.formats).map((format) => (
              <div
                key={format.formatId}
                className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-all gap-3 group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                    {format.qualityLabel.toLowerCase().includes('high') || format.formatId.includes('high') ? (
                      <Crown className="w-5 h-5 fill-amber-400/20" />
                    ) : (
                      <Zap className="w-5 h-5 fill-amber-400/20" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-sm sm:text-base">
                        {format.qualityLabel}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {format.ext.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-amber-300/80 font-medium">
                      {format.formatNote || '👑 FADI KING VIP High Quality'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 justify-end">
                  <button
                    onClick={() => openQr(format)}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 text-xs transition-colors cursor-pointer"
                    title="Download on Mobile with QR"
                  >
                    <QrCode className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleDownload(format)}
                    disabled={downloadingFormatId === format.formatId}
                    className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all cursor-pointer min-w-[130px]"
                  >
                    {downloadingFormatId === format.formatId ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>{downloadProgressText}</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4 stroke-[2.5]" />
                        <span>{t.action}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Audio Formats List */}
        {activeTab === 'audio' && (
          <div className="space-y-3">
            {audioFormats.length > 0 ? (
              audioFormats.map((format) => (
                <div
                  key={format.formatId}
                  className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-all gap-3 group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                      <Music className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white text-sm sm:text-base">
                          {format.qualityLabel}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          MP3 HD
                        </span>
                      </div>
                      <p className="text-xs text-slate-400">
                        {format.formatNote || 'Studio Quality Extracted Sound'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 justify-end">
                    <button
                      onClick={() => handleDownload(format)}
                      disabled={downloadingFormatId === format.formatId}
                      className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-green-500 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer min-w-[130px]"
                    >
                      {downloadingFormatId === format.formatId ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>{downloadProgressText}</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4 stroke-[2.5]" />
                          <span>Download MP3</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-slate-400 text-sm">
                No audio tracks found.
              </div>
            )}
          </div>
        )}

        {/* Tab 3: HD Thumbnail */}
        {activeTab === 'thumbnail' && (
          <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
            {info.thumbnailUrl ? (
              <div className="max-w-md mx-auto space-y-4">
                <img
                  src={info.thumbnailUrl}
                  alt={info.title}
                  className="w-full rounded-2xl border border-slate-800 shadow-xl"
                />
                <a
                  href={info.thumbnailUrl}
                  download="FADI_KING_thumbnail.jpg"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs sm:text-sm shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Full HD Cover</span>
                </a>
              </div>
            ) : (
              <p className="text-slate-400 text-sm">No thumbnail available</p>
            )}
          </div>
        )}
      </div>

      {/* QR Modal for mobile scanning */}
      {qrModalUrl && (
        <QrModal
          isOpen={true}
          downloadUrl={qrModalUrl}
          title={info.title}
          lang={lang}
          onClose={() => setQrModalUrl(null)}
        />
      )}
    </div>
  );
};
