import React from 'react';
import { Copy, Sparkles, Download, Smartphone } from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';

interface HowItWorksProps {
  lang: Language;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ lang }) => {
  const t = translations[lang];

  const steps = [
    {
      num: '01',
      icon: <Copy className="w-5 h-5 text-emerald-400" />,
      title: t.howStep1Title,
      desc: t.howStep1Desc,
    },
    {
      num: '02',
      icon: <Sparkles className="w-5 h-5 text-teal-400" />,
      title: t.howStep2Title,
      desc: t.howStep2Desc,
    },
    {
      num: '03',
      icon: <Download className="w-5 h-5 text-cyan-400" />,
      title: t.howStep3Title,
      desc: t.howStep3Desc,
    },
  ];

  return (
    <section id="how-it-works" className="w-full max-w-5xl mx-auto mt-20 px-4">
      <div className="text-center mb-10">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
          {t.howItWorks}
        </h2>
        <p className="text-slate-400 text-sm max-w-xl mx-auto">
          Fast, effortless downloads in 3 simple steps on any phone or computer.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {steps.map((step) => (
          <div
            key={step.num}
            className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 relative flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
                  {step.icon}
                </div>
                <span className="text-2xl font-black text-slate-700 font-mono">
                  {step.num}
                </span>
              </div>
              <h3 className="text-base font-bold text-white mb-2">{step.title}</h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
