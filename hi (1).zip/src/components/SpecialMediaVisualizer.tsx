import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Zap,
  Activity,
  Cpu,
  Radio,
  Sliders,
  CheckCircle2,
  Shield,
  Layers,
  Crown,
  Server,
  Globe2,
  Wifi,
} from 'lucide-react';
import { playClickSound } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

interface SpecialMediaVisualizerProps {
  isAnalyzing: boolean;
  hasVideoInfo: boolean;
  videoTitle?: string;
  platform?: string;
}

type VisualizerMode = 'quantum' | 'hyper_stream' | 'satellite_radar' | 'neural_matrix';

export const SpecialMediaVisualizer: React.FC<SpecialMediaVisualizerProps> = ({
  isAnalyzing,
  hasVideoInfo,
  videoTitle,
  platform,
}) => {
  const [mode, setMode] = useState<VisualizerMode>('quantum');
  const [downloadSpeed, setDownloadSpeed] = useState(134.8);
  const [activeServer, setActiveServer] = useState<'sg' | 'de' | 'jp'>('sg');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Speed jitter simulation for high-end look
  useEffect(() => {
    const timer = setInterval(() => {
      setDownloadSpeed(+(125 + Math.random() * 40).toFixed(1));
    }, 1100);
    return () => clearInterval(timer);
  }, []);

  // Premium Canvas visualizer loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;
    const numBars = 54;
    const particles: Array<{ x: number; y: number; vx: number; vy: number; size: number; alpha: number; color: string }> = [];

    // Initialize cosmic fiber particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * 850,
        y: Math.random() * 120,
        vx: 1.2 + Math.random() * 2.2,
        vy: (Math.random() - 0.5) * 0.4,
        size: 1 + Math.random() * 2.2,
        alpha: 0.3 + Math.random() * 0.7,
        color: i % 3 === 0 ? '#ffffff' : i % 3 === 1 ? '#38bdf8' : '#34d399',
      });
    }

    const render = () => {
      tick++;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Deep frosted crystal canvas background
      const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
      bgGrad.addColorStop(0, 'rgba(10, 10, 14, 0.95)');
      bgGrad.addColorStop(1, 'rgba(5, 5, 8, 0.98)');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Isometric cyber grid floor
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      for (let y = 15; y < height; y += 18) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
      for (let x = 0; x < width; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      const intensity = isAnalyzing ? 2.4 : 1.0;

      if (mode === 'quantum') {
        // Holographic Dual Sine Spectrum with glowing reflection floor
        const barWidth = width / numBars - 2.5;

        for (let i = 0; i < numBars; i++) {
          const freq = (i / numBars) * Math.PI * 4;
          const sine = Math.sin(freq + tick * 0.05 * intensity);
          const cosine = Math.cos(freq * 1.8 - tick * 0.03 * intensity);
          let h = Math.abs(sine * 0.65 + cosine * 0.35) * (height * 0.65) * (isAnalyzing ? 1.2 : 0.85) + 6;
          h = Math.min(height - 10, h);

          const x = i * (barWidth + 2.5) + 4;
          const y = height - h - 5;

          // Multi-layer frosted glass equalizer bar
          const grad = ctx.createLinearGradient(0, y, 0, height);
          grad.addColorStop(0, '#ffffff');
          grad.addColorStop(0.3, 'rgba(255, 255, 255, 0.9)');
          grad.addColorStop(0.7, 'rgba(255, 255, 255, 0.4)');
          grad.addColorStop(1, 'rgba(255, 255, 255, 0.05)');

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, h, [3, 3, 0, 0]);
          ctx.fill();

          // High-light cap
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = '#ffffff';
          ctx.shadowBlur = isAnalyzing ? 8 : 3;
          ctx.fillRect(x, Math.max(2, y - 2.5), barWidth, 1.5);
          ctx.shadowBlur = 0;
        }

        // Smooth neon laser ribbon passing over bars
        ctx.beginPath();
        ctx.strokeStyle = isAnalyzing ? 'rgba(56, 189, 248, 0.9)' : 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 1.8;
        for (let x = 0; x < width; x += 8) {
          const y = height * 0.45 + Math.sin(x * 0.02 + tick * 0.06 * intensity) * 18;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      } else if (mode === 'hyper_stream') {
        // High-Speed Fiber Stream Accelerator with rocket photon packets
        particles.forEach((p) => {
          p.x += p.vx * intensity * 2;
          p.y += p.vy * intensity;

          if (p.x > width + 20) {
            p.x = -20;
            p.y = Math.random() * height;
          }

          // Photon streak trail
          const trailLength = 35 * (p.vx / 2) * (isAnalyzing ? 1.6 : 1.0);
          const streak = ctx.createLinearGradient(p.x - trailLength, p.y, p.x, p.y);
          streak.addColorStop(0, 'rgba(255, 255, 255, 0)');
          streak.addColorStop(0.7, p.color);
          streak.addColorStop(1, '#ffffff');

          ctx.strokeStyle = streak;
          ctx.lineWidth = p.size;
          ctx.beginPath();
          ctx.moveTo(p.x - trailLength, p.y);
          ctx.lineTo(p.x, p.y);
          ctx.stroke();

          // Particle tip burst
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.8, 0, Math.PI * 2);
          ctx.fill();
        });
      } else if (mode === 'satellite_radar') {
        // Orbital Satellite Scanner with sweeping beam
        const centerX = width / 2;
        const centerY = height / 2;
        const sweepAngle = (tick * 0.04 * intensity) % (Math.PI * 2);

        // Radar concentric circles
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
        ctx.lineWidth = 1;
        for (let r = 20; r <= 140; r += 28) {
          ctx.beginPath();
          ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Radar sweep pie
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, 150, sweepAngle - 0.45, sweepAngle);
        ctx.closePath();
        const sweepGrad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 150);
        sweepGrad.addColorStop(0, 'rgba(56, 189, 248, 0.4)');
        sweepGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
        ctx.fillStyle = sweepGrad;
        ctx.fill();
        ctx.restore();

        // Beam radius line
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + Math.cos(sweepAngle) * 150, centerY + Math.sin(sweepAngle) * 150);
        ctx.stroke();
      } else if (mode === 'neural_matrix') {
        // 3D Neural Matrix Wave Lattice
        const cols = 28;
        const rows = 6;
        for (let i = 0; i < cols; i++) {
          for (let j = 0; j < rows; j++) {
            const x = (i / cols) * width + 15;
            const waveY =
              Math.sin(i * 0.35 + tick * 0.05 * intensity) *
              Math.cos(j * 0.5 + tick * 0.04) *
              22;
            const y = (j / rows) * (height - 30) + 20 + waveY;

            ctx.fillStyle = isAnalyzing ? '#38bdf8' : '#ffffff';
            ctx.beginPath();
            ctx.arc(x, y, 1.8, 0, Math.PI * 2);
            ctx.fill();

            // Connect neighboring lattice nodes
            if (i > 0) {
              const prevWaveY =
                Math.sin((i - 1) * 0.35 + tick * 0.05 * intensity) *
                Math.cos(j * 0.5 + tick * 0.04) *
                22;
              const prevX = ((i - 1) / cols) * width + 15;
              const prevY = (j / rows) * (height - 30) + 20 + prevWaveY;

              ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
              ctx.lineWidth = 0.8;
              ctx.beginPath();
              ctx.moveTo(prevX, prevY);
              ctx.lineTo(x, y);
              ctx.stroke();
            }
          }
        }
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [mode, isAnalyzing]);

  return (
    <div className="w-full max-w-4xl my-3 relative z-10 transition-all duration-300">
      <div className="bg-neutral-900/60 backdrop-blur-3xl border border-white/10 rounded-3xl p-4 sm:p-5 shadow-2xl relative overflow-hidden">
        {/* Subtle Ambient Reflections */}
        <div className="absolute top-0 right-1/4 w-80 h-32 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-80 h-32 bg-neutral-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header Controls & Live Server Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3.5">
          <div
            onClick={() => {
              speakFeature(
                'VIP Ultra Server Engine',
                'Mera kaam high-speed multi-threaded proxy servers ke zariye Facebook, YouTube aur social media videos ko fastest rate par process karna hai.'
              );
            }}
            className="flex items-center gap-2.5 cursor-pointer"
          >
            <div className="w-9 h-9 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-lg shrink-0">
              <Server className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xs sm:text-sm text-white tracking-wide uppercase">
                  FADI KING VIP SERVER CLUSTER
                </span>
                <span
                  className={`px-2 py-0.5 text-[9px] font-extrabold rounded-full border ${
                    isAnalyzing
                      ? 'bg-white/20 text-white border-white/40 animate-pulse'
                      : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  }`}
                >
                  {isAnalyzing ? '⚡ ULTRA PROCESSING' : '● ACTIVE 8K PIPELINE'}
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-white/50">
                Multi-threaded zero-watermark engine · 100% Guaranteed DRM Bypass
              </p>
            </div>
          </div>

          {/* Animation Mode Switcher Tabs */}
          <div className="flex items-center gap-1 p-1 rounded-full bg-neutral-950/70 border border-white/10">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                speakFeature('Quantum Wave', 'Mera kaam real-time audio frequency visualizer dikhana hai.');
                setMode('quantum');
              }}
              className={`px-3 py-1 rounded-full text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
                mode === 'quantum'
                  ? 'bg-white text-slate-950 shadow-md font-black'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Quantum Wave
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setMode('hyper_stream');
              }}
              className={`px-3 py-1 rounded-full text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
                mode === 'hyper_stream'
                  ? 'bg-white text-slate-950 shadow-md font-black'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Hyper Stream
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setMode('satellite_radar');
              }}
              className={`px-3 py-1 rounded-full text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
                mode === 'satellite_radar'
                  ? 'bg-white text-slate-950 shadow-md font-black'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Radar Sweep
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setMode('neural_matrix');
              }}
              className={`px-3 py-1 rounded-full text-[10px] sm:text-[11px] font-bold transition-all cursor-pointer ${
                mode === 'neural_matrix'
                  ? 'bg-white text-slate-950 shadow-md font-black'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Neural Grid
            </button>
          </div>
        </div>

        {/* Live Visualizer Canvas Display */}
        <div className="relative w-full h-24 sm:h-28 rounded-2xl overflow-hidden border border-white/10 bg-neutral-950/80 shadow-inner">
          <canvas
            ref={canvasRef}
            width={820}
            height={112}
            className="w-full h-full block object-cover"
          />

          {/* Overdrive HUD Overlay during analysis */}
          {isAnalyzing && (
            <div className="absolute inset-0 bg-neutral-950/65 backdrop-blur-[2px] flex items-center justify-center p-3">
              <div className="flex items-center gap-3 px-4 py-2 rounded-full bg-neutral-900/90 border border-white/30 shadow-xl text-white text-xs">
                <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
                <span className="font-mono font-bold text-white">
                  SERVER HIGH ACCELERATION ACTIVE · BYPASSING BOT BARRIER
                </span>
              </div>
            </div>
          )}

          {/* Real-time telemetry badges floating over canvas */}
          <div className="absolute bottom-2 left-3 flex items-center gap-2 pointer-events-none text-[10px] text-white/80 font-mono">
            <span className="px-2 py-0.5 rounded-full bg-black/60 border border-white/15">
              SPEED: {downloadSpeed} MB/s
            </span>
            <span className="px-2 py-0.5 rounded-full bg-black/60 border border-white/15">
              LATENCY: 11ms
            </span>
          </div>

          <div className="absolute bottom-2 right-3 flex items-center gap-2 pointer-events-none text-[10px] text-white/80 font-mono">
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300">
              ✓ ZERO WATERMARK 8K STREAM
            </span>
          </div>
        </div>

        {/* High-Performance Server Nodes Bar */}
        <div className="mt-3 pt-3 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setActiveServer('sg');
            }}
            className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
              activeServer === 'sg'
                ? 'bg-white text-slate-950 border-white font-bold shadow-lg'
                : 'bg-neutral-950/50 border-white/10 text-white hover:border-white/30'
            }`}
          >
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider opacity-70">Node SG-1 (Active)</p>
              <p className="font-black text-xs mt-0.5">Singapore 8K Ultra Core</p>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-full ${activeServer === 'sg' ? 'bg-slate-950 text-white' : 'bg-emerald-500/20 text-emerald-400'}`}>
              12ms
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setActiveServer('de');
            }}
            className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
              activeServer === 'de'
                ? 'bg-white text-slate-950 border-white font-bold shadow-lg'
                : 'bg-neutral-950/50 border-white/10 text-white hover:border-white/30'
            }`}
          >
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider opacity-70">Node DE-2 (High-Speed)</p>
              <p className="font-black text-xs mt-0.5">Frankfurt 4K Pipeline</p>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-full ${activeServer === 'de' ? 'bg-slate-950 text-white' : 'bg-emerald-500/20 text-emerald-400'}`}>
              24ms
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setActiveServer('jp');
            }}
            className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
              activeServer === 'jp'
                ? 'bg-white text-slate-950 border-white font-bold shadow-lg'
                : 'bg-neutral-950/50 border-white/10 text-white hover:border-white/30'
            }`}
          >
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider opacity-70">Node JP-3 (Bypass VIP)</p>
              <p className="font-black text-xs mt-0.5">Tokyo Bot-Bypass Server</p>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded-full ${activeServer === 'jp' ? 'bg-slate-950 text-white' : 'bg-emerald-500/20 text-emerald-400'}`}>
              18ms
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
