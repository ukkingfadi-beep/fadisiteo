import React, { useState } from 'react';
import {
  Crown,
  Volume2,
  VolumeX,
  ExternalLink,
  Layers,
  Sparkles,
  HelpCircle,
  ListOrdered,
  Music2,
  Lock,
  MessageCircle,
  Sun,
  Moon,
  Bell,
  Menu,
  X,
  ShieldCheck,
  Flame,
  Gem,
  Star,
  Rocket,
  Trophy,
  Zap,
} from 'lucide-react';
import type { Language } from '../utils/translations';
import { translations, WHATSAPP_CHANNEL_LINK } from '../utils/translations';
import { playClickSound } from '../utils/sound';
import { ItemIconsConfig } from '../utils/themeAndConfigManager';
import { speakFeature } from '../utils/voiceGuide';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onNavigateSection: (sectionId: string) => void;
  activeMode: 'single' | 'batch' | 'studio';
  onModeChange: (mode: 'single' | 'batch' | 'studio') => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenGateModal: () => void;
  onOpenUpgrade: () => void;
  onOpenAdmin: () => void;
  onOpenChat: () => void;
  onlineCount?: number;
  quotaRemaining: number;
  isLifetime: boolean;
  isWhiteGlass?: boolean;
  onToggleGlassTheme?: () => void;
  unreadAlertCount?: number;
  isBellRinging?: boolean;
  onOpenAlerts?: () => void;
  itemIcons?: ItemIconsConfig;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  onNavigateSection,
  activeMode,
  onModeChange,
  soundEnabled,
  onToggleSound,
  onOpenGateModal,
  onOpenUpgrade,
  onOpenAdmin,
  onOpenChat,
  onlineCount = 1,
  quotaRemaining,
  isLifetime,
  isWhiteGlass = false,
  onToggleGlassTheme,
  unreadAlertCount = 0,
  isBellRinging = false,
  onOpenAlerts,
  itemIcons,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const t = translations[lang];

  return (
    <header
      className={`border-b sticky top-0 z-40 transition-colors shadow-xl ${
        isWhiteGlass
          ? 'bg-white/80 border-slate-200/80 shadow-slate-200/40 backdrop-blur-3xl text-slate-900'
          : 'border-white/10 bg-neutral-950/65 backdrop-blur-3xl shadow-black/50 text-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1: Modern Wordmark with Monochrome Emblem matching Image 2 */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={() => {
              playClickSound();
              onModeChange('single');
              setIsMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 sm:gap-3 text-left group cursor-pointer"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white text-slate-950 flex items-center justify-center shadow-md font-black relative group-hover:scale-105 transition-transform shrink-0 border border-white/20">
              {itemIcons?.logoCustomUrl ? (
                <img src={itemIcons.logoCustomUrl} alt="Logo" className="w-6 h-6 object-contain rounded-md" />
              ) : itemIcons?.logoIcon === 'shield' ? (
                <ShieldCheck className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'flame' ? (
                <Flame className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'diamond' ? (
                <Gem className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'star' ? (
                <Star className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'rocket' ? (
                <Rocket className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'trophy' ? (
                <Trophy className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : itemIcons?.logoIcon === 'zap' ? (
                <Zap className="w-5 h-5 text-slate-950 fill-slate-950" />
              ) : (
                <Crown className="w-5 h-5 text-slate-950 fill-slate-950" strokeWidth={2.5} />
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="font-black text-base sm:text-xl tracking-tight text-white whitespace-nowrap">
                  FADI KING
                </span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-white/10 text-slate-200 border border-white/15 shadow-sm">
                  VIP
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-amber-200/70 font-mono hidden md:flex">
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  8K ULTRA HDR
                </span>
                <span>·</span>
                <span className="text-slate-400">Zero Watermark</span>
                <span>·</span>
                <span className="text-amber-400/90 font-medium">SG-VIP Node</span>
              </div>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Desktop only) */}
        <nav className="hidden lg:flex items-center gap-5 text-xs sm:text-sm font-semibold text-slate-300">
          <button
            onClick={() => {
              playClickSound();
              onModeChange('single');
            }}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-amber-400 flex items-center gap-1.5 cursor-pointer ${
              activeMode === 'single' ? 'text-amber-400' : 'text-slate-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.singleModeTab}</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              onModeChange('batch');
            }}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-emerald-400 flex items-center gap-1.5 cursor-pointer ${
              activeMode === 'batch' ? 'text-emerald-400' : 'text-slate-300'
            }`}
          >
            <ListOrdered className="w-3.5 h-3.5" />
            <span>{t.batchModeTab}</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              onModeChange('studio');
            }}
            className={`transition-colors whitespace-nowrap shrink-0 hover:text-cyan-400 flex items-center gap-1.5 cursor-pointer ${
              activeMode === 'studio' ? 'text-cyan-400' : 'text-slate-300'
            }`}
          >
            <Music2 className="w-3.5 h-3.5" />
            <span>Studio Audio</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              onNavigateSection('supported');
            }}
            className="transition-colors whitespace-nowrap shrink-0 text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Platforms</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              onNavigateSection('faq');
            }}
            className="transition-colors whitespace-nowrap shrink-0 text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>FAQ</span>
          </button>
        </nav>

        {/* Zone 3: Desktop Actions & Controls (hidden on small mobile screens) */}
        <div className="hidden sm:flex items-center gap-2 shrink-0">
          {/* Real-time Live Online Visitor Counter Badge */}
          <div
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-xs font-bold shrink-0 shadow-sm"
            title="Real-Time Active Visitors Connected to FADI KING"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
            </span>
            <span className="font-mono">{onlineCount}</span>
            <span className="hidden md:inline">Active Online</span>
            <span className="md:hidden">Live</span>
          </div>

          {/* Quota Badge & Upgrade CTA */}
          {isLifetime ? (
            <button
              onClick={() => {
                playClickSound();
                onOpenUpgrade();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/10 border border-amber-400/40 text-amber-300 text-xs font-bold transition-all hover:bg-amber-500/20 active:scale-95 cursor-pointer whitespace-nowrap"
              title="Click to view Lifetime VIP status"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>VIP Lifetime</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  playClickSound();
                  onOpenUpgrade();
                }}
                className={`text-xs px-2.5 py-1.5 rounded-xl border font-mono font-semibold transition-colors cursor-pointer ${
                  quotaRemaining <= 1
                    ? 'bg-red-950/40 border-red-500/40 text-red-300'
                    : 'bg-slate-900 border-slate-700 text-slate-300'
                }`}
                title="Free downloads remaining out of 5"
              >
                {quotaRemaining}/5 Left
              </button>
              <button
                onClick={() => {
                  playClickSound();
                  onOpenUpgrade();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold transition-all shadow-md shadow-amber-950/40 active:scale-95 cursor-pointer whitespace-nowrap"
              >
                <Crown className="w-3.5 h-3.5 fill-current" />
                <span className="hidden md:inline">Upgrade (250 PKR)</span>
                <span className="md:hidden">Upgrade</span>
              </button>
            </div>
          )}


          {/* Live Chat Board Launcher */}
          <button
            onClick={() => {
              playClickSound();
              speakFeature('Live Chat Board', 'Mera kaam real-time live support aur community chat open karna hai.');
              onOpenChat();
            }}
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/20 to-amber-500/15 hover:from-amber-500/25 hover:to-yellow-500/30 border border-amber-400/40 text-amber-300 text-xs font-bold transition-all shadow-md shadow-amber-950/40 active:scale-95 cursor-pointer whitespace-nowrap"
            title="Open Live Support & Community Chat"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Live Chat</span>
          </button>

          {/* Alert Notification Bell */}
          <button
            onClick={() => {
              playClickSound();
              speakFeature('Notification Bell', 'Mera kaam website ki latest updates aur announcements dikhana hai.');
              onOpenAlerts?.();
            }}
            className={`relative p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
              isBellRinging
                ? 'bg-amber-500/30 border-amber-400 text-amber-300 ring-2 ring-amber-400 shadow-lg shadow-amber-500/50'
                : unreadAlertCount > 0
                ? 'bg-amber-500/20 border-amber-400/40 text-amber-300 hover:bg-amber-500/30'
                : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:text-amber-400 hover:border-slate-700'
            }`}
            title="Official Announcements & Alert Notifications"
            aria-label="Alert Notifications"
          >
            <Bell
              className={`w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 ${
                isBellRinging ? 'animate-bell-ring fill-amber-400' : unreadAlertCount > 0 ? 'fill-amber-400/40' : ''
              }`}
            />
            {unreadAlertCount > 0 && (
              <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-gradient-to-r from-red-600 to-rose-600 text-white text-[10px] font-black flex items-center justify-center shadow-md font-mono animate-pulse border border-red-300/40">
                {unreadAlertCount > 9 ? '9+' : unreadAlertCount}
              </span>
            )}
          </button>

          {/* Dark Glass / White Crystal Glass Toggle */}
          {onToggleGlassTheme && (
            <button
              onClick={() => {
                playClickSound();
                speakFeature('Theme Switcher', 'Mera kaam Royal Obsidian Gold aur White Crystal Glass theme switch karna hai.');
                onToggleGlassTheme();
              }}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                isWhiteGlass
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-600 hover:bg-amber-500/20'
                  : 'bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-800 hover:border-amber-500/30'
              }`}
              title={isWhiteGlass ? 'Switch to Dark Glass' : 'Switch to White Crystal Glass'}
              aria-label="Toggle Glass Theme"
            >
              {isWhiteGlass ? <Moon className="w-4 h-4 text-indigo-600" /> : <Sun className="w-4 h-4 text-amber-400" />}
            </button>
          )}

          {/* Discreet Admin Lock Button */}
          <button
            onClick={() => {
              playClickSound();
              speakFeature('Admin Master Control', 'Mera kaam website ke admin panel ko password se open karna hai jahan se aap background, videos, photos aur icons badal sakte hain.');
              onOpenAdmin();
            }}
            className="p-1.5 rounded-lg bg-slate-900/90 border border-slate-800 text-slate-400 hover:text-pink-400 hover:border-pink-500/40 transition-colors cursor-pointer"
            title="Admin Control Center"
            aria-label="Admin Portal"
          >
            <Lock className="w-4 h-4" />
          </button>

          {/* Sound Synthesizer Toggle */}
          <button
            onClick={() => {
              playClickSound();
              onToggleSound();
            }}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-slate-900 border-amber-500/30 text-amber-400 hover:bg-slate-800'
                : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
            }`}
            title={soundEnabled ? 'Mute Sounds' : 'Unmute Sounds'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Re-Open Gate Modal button */}
          <button
            onClick={() => {
              playClickSound();
              onOpenGateModal();
            }}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-amber-300 hover:border-amber-500/30 transition-colors cursor-pointer"
            title="View VIP Channel Access Gate"
          >
            <Crown className="w-4 h-4 text-amber-400" />
          </button>

          {/* Language Selector Dropdown */}
          <div className="flex items-center bg-slate-900/90 border border-amber-500/25 rounded-xl p-0.5 text-xs">
            {(['en', 'ur', 'hi', 'ar'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => {
                  playClickSound();
                  onLanguageChange(l);
                }}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  lang === l
                    ? 'bg-amber-400 text-slate-950 font-black shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {l === 'en' ? 'EN' : l === 'ur' ? 'اردو' : l === 'hi' ? 'हिं' : 'عر'}
              </button>
            ))}
          </div>
        </div>

        {/* Zone 4: Mobile Top Controls (Single Clean Row) */}
        <div className="flex sm:hidden items-center gap-1.5 shrink-0">
          {/* Mobile Quota / Upgrade Quick Pill */}
          {isLifetime ? (
            <button
              onClick={() => {
                playClickSound();
                onOpenUpgrade();
              }}
              className="px-2 py-1 rounded-lg bg-gradient-to-r from-amber-500/25 to-yellow-500/20 border border-amber-400/50 text-amber-300 text-[11px] font-black flex items-center gap-1 active:scale-95"
            >
              <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>VIP</span>
            </button>
          ) : (
            <button
              onClick={() => {
                playClickSound();
                onOpenUpgrade();
              }}
              className={`px-2 py-1 rounded-lg border text-[11px] font-mono font-bold flex items-center gap-1 active:scale-95 ${
                quotaRemaining <= 1
                  ? 'bg-red-950/60 border-red-500/50 text-red-300'
                  : 'bg-slate-900 border-amber-500/40 text-amber-300'
              }`}
            >
              <span>{quotaRemaining}/5</span>
            </button>
          )}

          {/* Mobile Notification Bell */}
          <button
            onClick={() => {
              playClickSound();
              onOpenAlerts?.();
            }}
            className={`relative p-2 rounded-lg border transition-all active:scale-95 ${
              isBellRinging
                ? 'bg-amber-500/30 border-amber-400 text-amber-300 ring-2 ring-amber-400'
                : unreadAlertCount > 0
                ? 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-300'
            }`}
            aria-label="Alerts"
          >
            <Bell
              className={`w-4 h-4 text-amber-400 ${
                isBellRinging ? 'animate-bell-ring fill-amber-400' : unreadAlertCount > 0 ? 'fill-amber-400/40' : ''
              }`}
            />
            {unreadAlertCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-0.5 rounded-full bg-red-600 text-white text-[9px] font-black flex items-center justify-center font-mono">
                {unreadAlertCount > 9 ? '9+' : unreadAlertCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Hamburger Button */}
          <button
            onClick={() => {
              playClickSound();
              setIsMobileMenuOpen(!isMobileMenuOpen);
            }}
            className="p-2 rounded-lg bg-slate-900 border border-amber-500/40 text-amber-400 hover:bg-slate-800 active:scale-95 transition-all"
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Dropdown Menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden border-t border-[#d4af37]/30 bg-[#160e08]/98 backdrop-blur-2xl px-4 py-4 space-y-4 max-h-[calc(100vh-3.5rem)] overflow-y-auto animate-in slide-in-from-top duration-200 shadow-2xl">
          {/* Header row in drawer: Live Visitors & Tag */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-xs font-bold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
              </span>
              <span className="font-mono">{onlineCount}</span>
              <span>Active Online</span>
            </div>

            <div className="text-[11px] text-amber-200/90 font-mono font-semibold">
              👑 8K ULTRA HDR · SG-VIP
            </div>
          </div>

          {/* Mode Navigation */}
          <div className="space-y-1">
            <div className="text-[10px] uppercase font-bold tracking-wider text-amber-400/80 px-1 mb-1">
              Modes & Tools
            </div>
            <button
              onClick={() => {
                playClickSound();
                onModeChange('single');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all ${
                activeMode === 'single'
                  ? 'bg-amber-400/15 text-amber-300 border border-amber-400/30'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>{t.singleModeTab}</span>
              </span>
              {activeMode === 'single' && <span className="text-[10px] text-amber-400 font-mono">● Active</span>}
            </button>

            <button
              onClick={() => {
                playClickSound();
                onModeChange('batch');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all ${
                activeMode === 'batch'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              <span className="flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-emerald-400" />
                <span>{t.batchModeTab}</span>
              </span>
              {activeMode === 'batch' && <span className="text-[10px] text-emerald-400 font-mono">● Active</span>}
            </button>

            <button
              onClick={() => {
                playClickSound();
                onModeChange('studio');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all ${
                activeMode === 'studio'
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              <span className="flex items-center gap-2">
                <Music2 className="w-4 h-4 text-cyan-400" />
                <span>Studio Audio (Extract & Convert)</span>
              </span>
              {activeMode === 'studio' && <span className="text-[10px] text-cyan-400 font-mono">● Active</span>}
            </button>

            <button
              onClick={() => {
                playClickSound();
                onNavigateSection('supported');
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-900"
            >
              <Layers className="w-4 h-4 text-slate-400" />
              <span>Supported Platforms</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                onNavigateSection('faq');
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-900"
            >
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span>FAQ & Help</span>
            </button>
          </div>

          {/* Quick Actions (Upgrade & Live Chat) */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
            <button
              onClick={() => {
                playClickSound();
                onOpenUpgrade();
                setIsMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-lg active:scale-95 transition-transform"
            >
              <Crown className="w-4 h-4 fill-slate-950" />
              <span>Upgrade VIP</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                onOpenChat();
                setIsMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 text-amber-300 font-black text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
            >
              <MessageCircle className="w-4 h-4 text-amber-400" />
              <span>Live Chat</span>
            </button>
          </div>


          {/* Language Selection */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="text-[10px] uppercase font-bold tracking-wider text-amber-400/80 px-1 mb-2">
              Language / زبان
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {(['en', 'ur', 'hi', 'ar'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => {
                    playClickSound();
                    onLanguageChange(l);
                  }}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    lang === l
                      ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {l === 'en' ? 'EN' : l === 'ur' ? 'اردو' : l === 'hi' ? 'हिन्दी' : 'العربية'}
                </button>
              ))}
            </div>
          </div>

          {/* Utilities: Sound, Theme, Gate, Admin */}
          <div className="pt-2 border-t border-slate-800/80 grid grid-cols-3 gap-1.5 text-xs">
            <button
              onClick={() => {
                playClickSound();
                onToggleSound();
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-amber-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
              <span className="text-[11px] font-semibold">{soundEnabled ? 'Mute' : 'Sound'}</span>
            </button>

            {onToggleGlassTheme ? (
              <button
                onClick={() => {
                  playClickSound();
                  onToggleGlassTheme();
                }}
                className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400"
              >
                {isWhiteGlass ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
                <span className="text-[11px] font-semibold">{isWhiteGlass ? 'Dark' : 'Light'}</span>
              </button>
            ) : <div />}

            <button
              onClick={() => {
                playClickSound();
                onOpenAdmin();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-pink-400"
            >
              <Lock className="w-3.5 h-3.5" />
              <span className="text-[11px] font-semibold">Admin</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
