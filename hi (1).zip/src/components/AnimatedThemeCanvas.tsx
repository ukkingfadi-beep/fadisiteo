import React from 'react';
import { ThemeDefinition, AnimationThemeType } from '../utils/themeAndConfigManager';

interface AnimatedThemeCanvasProps {
  theme: ThemeDefinition;
}

export const AnimatedThemeCanvas: React.FC<AnimatedThemeCanvasProps> = ({ theme }) => {
  const {
    bgType,
    bgMediaUrl,
    bgOverlayOpacity = 0.85,
    bgBlur = 2,
    animationTheme = 'royal_gold_shimmer',
    primaryColor = '#eab308',
    accentColor = '#10b981',
    backgroundColor = '#070a12',
  } = theme;

  // Smart fallback: if URL is an MP4/WebM video file, treat as video
  const isVideoSource = bgType === 'video' || (bgMediaUrl && /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(bgMediaUrl));
  const isImageSource = !isVideoSource && (bgType === 'image' || Boolean(bgMediaUrl));

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden transition-all duration-700"
      style={{ backgroundColor }}
    >
      {/* 1. Background Video Mode */}
      {isVideoSource && bgMediaUrl && (
        <video
          key={bgMediaUrl}
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700"
          style={{ filter: bgBlur > 0 ? `blur(${bgBlur}px)` : undefined }}
          src={bgMediaUrl}
        />
      )}

      {/* 2. Background Image Mode (Custom or Default Natural Architectural Blur as shown in Image 2) */}
      {isImageSource && bgMediaUrl ? (
        <div
          key={bgMediaUrl}
          className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat transition-all duration-700"
          style={{
            backgroundImage: `url('${bgMediaUrl}')`,
            filter: bgBlur > 0 ? `blur(${bgBlur}px)` : undefined,
          }}
        />
      ) : !isVideoSource && (
        <div
          className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat transition-all duration-700 scale-105"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=80')`,
            filter: 'blur(16px)',
          }}
        />
      )}

      {/* 3. Dark Frosted Acrylic Tint Layer to Ensure 100% Contrast & High-End Look */}
      <div
        className="absolute inset-0 transition-all duration-500"
        style={{
          backgroundColor: '#0a0b10',
          opacity: bgMediaUrl ? Math.max(0.2, Math.min(0.92, bgOverlayOpacity)) : 0.65,
        }}
      />

      {/* 4. Active Animation Theme Shaders */}
      {animationTheme === 'cyber_matrix' && (
        <div className="absolute inset-0">
          {/* Cyberpunk Grid */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#06b6d412_1px,transparent_1px),linear-gradient(to_bottom,#06b6d412_1px,transparent_1px)] bg-[size:32px_32px] [mask-image:radial-gradient(ellipse_80%_60%_at_50%_0%,#000_70%,transparent_100%)]" />
          {/* Neon Cyber Glow Orbs */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-[100px] animate-pulse duration-1000" />
          <div className="absolute top-1/3 right-1/4 w-[420px] h-[420px] bg-blue-600/12 rounded-full blur-[120px]" />
          {/* Matrix vertical scanlines */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px] pointer-events-none opacity-40" />
        </div>
      )}

      {animationTheme === 'royal_gold_shimmer' && (
        <div className="absolute inset-0">
          {/* Royal Ambient Radial Gradient with Rich Espresso & Cognac Glow */}
          <div
            className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[720px]"
            style={{
              background: `radial-gradient(ellipse 85% 65% at 50% -8%, rgba(212,175,55,0.22), rgba(198,134,66,0.18), rgba(35,21,13,0.45), transparent)`,
            }}
          />
          {/* Shimmering Golden Floating Dust Orbs */}
          <div
            className="absolute top-72 -left-32 w-[480px] h-[480px] rounded-full blur-[130px] animate-pulse duration-1000"
            style={{ backgroundColor: `${primaryColor}22` }}
          />
          <div
            className="absolute top-96 -right-32 w-[520px] h-[520px] rounded-full blur-[140px]"
            style={{ backgroundColor: `${accentColor}20` }}
          />
          {/* Warm Mahogany & Espresso Light Pools */}
          <div className="absolute bottom-10 left-1/3 w-[600px] h-[300px] bg-[#3a2012]/30 rounded-full blur-[140px]" />
          {/* Gold & Bronze Sparkle Field */}
          <div className="absolute inset-0 bg-[radial-gradient(#d4af3715_1px,transparent_1px)] [background-size:26px_26px] opacity-70" />
        </div>
      )}

      {animationTheme === 'cosmic_nebula' && (
        <div className="absolute inset-0">
          {/* Deep Space Cosmic Atmosphere */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[700px] bg-[radial-gradient(ellipse_90%_70%_at_50%_0%,rgba(139,92,246,0.20),rgba(59,130,246,0.15),transparent)] blur-2xl" />
          <div className="absolute top-80 left-10 w-[480px] h-[480px] bg-purple-700/15 rounded-full blur-[130px] animate-pulse duration-700" />
          <div className="absolute bottom-40 right-10 w-[500px] h-[500px] bg-indigo-600/15 rounded-full blur-[140px]" />
          {/* Starlight Dust */}
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:28px_28px] opacity-75" />
        </div>
      )}

      {animationTheme === 'neon_synthwave' && (
        <div className="absolute inset-0">
          {/* Synthwave Horizon Perspective Grid */}
          <div className="absolute bottom-0 left-0 right-0 h-[45vh] bg-[linear-gradient(to_right,#f43f5e18_1px,transparent_1px),linear-gradient(to_bottom,#06b6d418_1px,transparent_1px)] bg-[size:40px_30px] [transform:perspective(500px)_rotateX(60deg)] [transform-origin:bottom_center]" />
          <div className="absolute top-10 left-1/2 -translate-x-1/2 w-80 h-80 bg-gradient-to-t from-rose-500/20 to-amber-500/20 rounded-full blur-[90px] animate-pulse duration-1000" />
        </div>
      )}

      {animationTheme === 'quantum_waves' && (
        <div className="absolute inset-0">
          {/* Quantum Energy Waves & Frequency Radiance */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[650px] bg-[radial-gradient(ellipse_90%_60%_at_50%_0%,rgba(16,185,129,0.22),rgba(6,182,212,0.18),transparent)] blur-2xl" />
          <div className="absolute top-1/4 left-1/3 w-[520px] h-[520px] bg-emerald-500/15 rounded-full blur-[140px] animate-pulse duration-700" />
          <div className="absolute top-1/2 right-1/4 w-[480px] h-[480px] bg-cyan-600/15 rounded-full blur-[130px] animate-pulse duration-1000" />
          {/* Quantum Wave Rib Lines */}
          <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_20px,rgba(16,185,129,0.04)_20px,rgba(16,185,129,0.04)_40px)] pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(#10b98122_1px,transparent_1px)] [background-size:24px_24px] opacity-80" />
        </div>
      )}

      {animationTheme === 'crystal_aurora' && (
        <div className="absolute inset-0">
          {/* Aurora Borealis & Prismatic Shifting Caustics */}
          <div className="absolute top-0 left-0 right-0 h-[600px] bg-[radial-gradient(ellipse_100%_80%_at_50%_-10%,rgba(56,189,248,0.25),rgba(168,85,247,0.20),rgba(52,211,153,0.15),transparent)] blur-3xl animate-pulse duration-1000" />
          <div className="absolute top-60 -left-20 w-[550px] h-[550px] bg-cyan-400/18 rounded-full blur-[150px]" />
          <div className="absolute top-80 -right-20 w-[580px] h-[580px] bg-fuchsia-500/15 rounded-full blur-[160px] animate-pulse duration-700" />
          {/* Prismatic Stardust Shimmer */}
          <div className="absolute inset-0 bg-[radial-gradient(#38bdf822_1px,transparent_1px)] [background-size:30px_30px] opacity-85" />
        </div>
      )}

      {animationTheme === 'clean_slate' && (
        <div className="absolute inset-0">
          <div
            className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-[500px]"
            style={{
              background: `radial-gradient(ellipse 70% 50% at 50% 0%, ${primaryColor}14, transparent)`,
            }}
          />
        </div>
      )}

      {/* 5. Four-Corner Luxury Lighting & Side Edge Animation System ("Charon Konon Mein Lighting Animation") */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Corner 1: Top-Left Luxury Gold/Amber Bloom & Corner Bracket Flare */}
        <div className="absolute -top-12 -left-12 w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-br from-amber-400/25 via-yellow-500/15 to-transparent rounded-full blur-3xl animate-pulse duration-1000" />
        <div className="absolute top-0 left-0 w-28 h-28 border-t-2 border-l-2 border-amber-400/50 rounded-tl-2xl shadow-[0_0_18px_rgba(251,191,36,0.35)]" />
        <div className="absolute top-2 left-2 w-2 h-2 rounded-full bg-amber-400 animate-ping" />

        {/* Corner 2: Top-Right Luxury Emerald/Cyan Bloom & Corner Bracket Flare */}
        <div className="absolute -top-12 -right-12 w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-bl from-emerald-400/25 via-cyan-500/15 to-transparent rounded-full blur-3xl animate-pulse duration-700" />
        <div className="absolute top-0 right-0 w-28 h-28 border-t-2 border-r-2 border-emerald-400/50 rounded-tr-2xl shadow-[0_0_18px_rgba(16,185,129,0.35)]" />
        <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping delay-150" />

        {/* Corner 3: Bottom-Left Luxury Rose/Amber Bloom & Corner Bracket Flare */}
        <div className="absolute -bottom-12 -left-12 w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-tr from-amber-500/20 via-orange-500/15 to-transparent rounded-full blur-3xl animate-pulse duration-1000" />
        <div className="absolute bottom-0 left-0 w-28 h-28 border-b-2 border-l-2 border-amber-500/50 rounded-bl-2xl shadow-[0_0_18px_rgba(245,158,11,0.35)]" />
        <div className="absolute bottom-2 left-2 w-2 h-2 rounded-full bg-amber-400 animate-ping delay-300" />

        {/* Corner 4: Bottom-Right Luxury Purple/Cyan Bloom & Corner Bracket Flare */}
        <div className="absolute -bottom-12 -right-12 w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-tl from-cyan-400/25 via-purple-600/15 to-transparent rounded-full blur-3xl animate-pulse duration-700" />
        <div className="absolute bottom-0 right-0 w-28 h-28 border-b-2 border-r-2 border-cyan-400/50 rounded-br-2xl shadow-[0_0_18px_rgba(6,182,212,0.35)]" />
        <div className="absolute bottom-2 right-2 w-2 h-2 rounded-full bg-cyan-400 animate-ping delay-75" />

        {/* Side Edge Beams: Vertical ambient light breathing along screen edges */}
        <div className="absolute top-1/4 bottom-1/4 left-0 w-[2px] bg-gradient-to-b from-transparent via-amber-400/60 to-transparent opacity-80 animate-pulse duration-1000" />
        <div className="absolute top-1/4 bottom-1/4 right-0 w-[2px] bg-gradient-to-b from-transparent via-emerald-400/60 to-transparent opacity-80 animate-pulse duration-700" />
      </div>
    </div>
  );
};
