import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  X,
  Send,
  Sparkles,
  Music2,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Clock,
  Heart,
  Crown,
  Flame,
  CheckCircle2,
  Zap,
  ListMusic,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  HOBBY_TRACKS,
  HobbyTrack,
} from '../utils/themeAndConfigManager';
import {
  playAmbientTune,
  stopAmbientTune,
  setAmbientVolume,
  isAmbientPlaying,
  getCurrentTrackId,
  setSleepTimer,
  cancelSleepTimer,
  getSleepTimerSeconds,
} from '../utils/ambientMusicPlayer';
import { playClickSound, playSuccessChime } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  suggestedTrackId?: string;
  actions?: { label: string; action: string; trackId?: string }[];
}

interface FadiKingChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
  isGoodNightActive: boolean;
  onToggleGoodNight: (active: boolean) => void;
  onSwitchMode: (mode: 'single' | 'batch' | 'studio') => void;
  onOpenUpgrade: () => void;
}

export const FadiKingChatbotModal: React.FC<FadiKingChatbotModalProps> = ({
  isOpen,
  onClose,
  isGoodNightActive,
  onToggleGoodNight,
  onSwitchMode,
  onOpenUpgrade,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text: '👑 Salam! Main hoon FADI KING VIP AI Assistant & Song Master. Main aapko 8K videos download karne, relaxing sad/lofi songs bajane aur Good Night mode chalane mein madad kar sakta hoon. Aaj main aapke liye kaunsa gana bajaoon?',
      timestamp: 'Just now',
      actions: [
        { label: '🌙 Turn On Good Night Mode', action: 'toggle_good_night' },
        { label: '🎵 Play Sleep Lo-Fi Song', action: 'play_track', trackId: 'good_night_lofi' },
        { label: '😢 Play Sad Pashto Rubab', action: 'play_track', trackId: 'pakistani_sad_rubab' },
        { label: '⚡ How to Download in 8K?', action: 'ask_how_download' },
      ],
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Audio Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackId, setCurrentTrackId] = useState<string>('good_night_lofi');
  const [volume, setVolume] = useState<number>(35);
  const [isMuted, setIsMuted] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(false);

  // Sleep Timer State (minutes)
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number>(0);
  const [sleepSecondsLeft, setSleepSecondsLeft] = useState<number>(0);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Sync with global audio state
  useEffect(() => {
    setIsPlaying(isAmbientPlaying());
    const curr = getCurrentTrackId();
    if (curr) setCurrentTrackId(curr);

    const handleAudioChange = (e: any) => {
      if (e.detail) {
        setIsPlaying(e.detail.isPlaying);
        if (e.detail.trackId) setCurrentTrackId(e.detail.trackId);
      }
    };

    window.addEventListener('fadiking-audio-state-changed', handleAudioChange);
    return () => window.removeEventListener('fadiking-audio-state-changed', handleAudioChange);
  }, []);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Audio Play / Pause
  const handleTogglePlay = (trackIdToPlay?: string) => {
    playClickSound();
    const track = trackIdToPlay || currentTrackId;

    if (isPlaying && track === currentTrackId) {
      stopAmbientTune();
      setIsPlaying(false);
    } else {
      setCurrentTrackId(track);
      playAmbientTune(track, isMuted ? 0 : volume);
      setIsPlaying(true);
    }
  };

  // Change Track
  const handleSelectTrack = (trackId: string) => {
    playClickSound();
    setCurrentTrackId(trackId);
    playAmbientTune(trackId, isMuted ? 0 : volume);
    setIsPlaying(true);
  };

  const handleNextTrack = () => {
    playClickSound();
    const currentIndex = HOBBY_TRACKS.findIndex((t) => t.id === currentTrackId);
    const nextIndex = (currentIndex + 1) % HOBBY_TRACKS.length;
    handleSelectTrack(HOBBY_TRACKS[nextIndex].id);
  };

  const handlePrevTrack = () => {
    playClickSound();
    const currentIndex = HOBBY_TRACKS.findIndex((t) => t.id === currentTrackId);
    const prevIndex = (currentIndex - 1 + HOBBY_TRACKS.length) % HOBBY_TRACKS.length;
    handleSelectTrack(HOBBY_TRACKS[prevIndex].id);
  };

  // Sleep Timer Handler
  const handleSetTimer = (minutes: number) => {
    playClickSound();
    setSleepTimerMinutes(minutes);
    if (minutes === 0) {
      cancelSleepTimer();
      setSleepSecondsLeft(0);
      return;
    }

    setSleepTimer(
      minutes,
      (left) => setSleepSecondsLeft(left),
      () => {
        setIsPlaying(false);
        setSleepTimerMinutes(0);
        setSleepSecondsLeft(0);
        addBotMessage('💤 Sleep Timer mukammal ho gaya hai aur audio aahista band ho gaya hai. Shubh ratri aur sweet dreams!');
      }
    );
  };

  // Toggle Good Night Mode
  const handleToggleNight = () => {
    playClickSound();
    const next = !isGoodNightActive;
    onToggleGoodNight(next);

    if (next) {
      // Automatically start soothing lofi / rain music and default 30 min timer
      handleSelectTrack('good_night_lofi');
      handleSetTimer(30);
      addBotMessage(
        '🌙 Good Night Mode active ho gaya hai! Website ko dim kar diya gaya hai, soothing lofi dhun shuru kar di gayi hai aur 30 minutes ka sleep timer set hai. Pur-sukoon neend lijiye!'
      );
    } else {
      cancelSleepTimer();
      setSleepTimerMinutes(0);
      addBotMessage('☀️ Good Night Mode band kar diya gaya hai. Website normal state mein aa gayi hai.');
    }
  };

  const addBotMessage = (text: string, suggestedTrackId?: string, actions?: any[]) => {
    setMessages((prev) => [
      ...prev,
      {
        id: `bot_${Date.now()}`,
        sender: 'bot',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedTrackId,
        actions,
      },
    ]);
  };

  // Send Chat message to backend AI route
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    playClickSound();
    setInputText('');

    const userMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    try {
      const response = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-6).map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            parts: [{ text: m.text }],
          })),
        }),
      });

      const data = await response.json();
      setIsTyping(false);

      if (data.reply) {
        addBotMessage(data.reply, data.suggestedTrackId, data.suggestedActions);

        // Auto trigger track if bot strongly suggested
        if (data.suggestedTrackId) {
          handleSelectTrack(data.suggestedTrackId);
        }
        if (data.triggerGoodNight && !isGoodNightActive) {
          onToggleGoodNight(true);
        }
      }
    } catch {
      setIsTyping(false);
      addBotMessage(
        'Main aapke sath hoon! Relaxing music chalana ho ya 8K downloader ki info chahiye ho, bas batayein.',
        'good_night_lofi',
        [
          { label: '🌙 Turn On Good Night Mode', action: 'toggle_good_night' },
          { label: '🎵 Play Sleep Lo-Fi Song', action: 'play_track', trackId: 'good_night_lofi' },
        ]
      );
    }
  };

  // Execute Action from Bot
  const handleActionClick = (action: string, trackId?: string) => {
    playClickSound();
    if (action === 'toggle_good_night') {
      handleToggleNight();
    } else if (action === 'play_track' && trackId) {
      handleSelectTrack(trackId);
    } else if (action === 'set_timer_30') {
      handleSetTimer(30);
    } else if (action === 'switch_mode_single') {
      onSwitchMode('single');
      onClose();
    } else if (action === 'switch_mode_batch') {
      onSwitchMode('batch');
      onClose();
    } else if (action === 'switch_mode_studio') {
      onSwitchMode('studio');
      onClose();
    } else if (action === 'open_vip') {
      onOpenUpgrade();
      onClose();
    } else if (action === 'ask_how_download') {
      handleSendMessage('How to download videos in 8K?');
    }
  };

  if (!isOpen) return null;

  const currentTrack = HOBBY_TRACKS.find((t) => t.id === currentTrackId) || HOBBY_TRACKS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-xl animate-in fade-in select-none">
      {/* Dynamic Starry Night Ambiance when Good Night mode is active */}
      {isGoodNightActive && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-10 right-20 w-32 h-32 rounded-full bg-cyan-200/10 blur-3xl animate-pulse" />
          <div className="absolute top-1/3 left-10 w-48 h-48 rounded-full bg-amber-400/10 blur-3xl animate-pulse" />
          <div className="absolute inset-0 opacity-40 bg-[radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        </div>
      )}

      {/* Main Glassmorphic Modal Container */}
      <div className="relative w-full max-w-2xl h-[92vh] max-h-[820px] rounded-3xl bg-[#070b14]/95 border border-amber-500/40 shadow-[0_0_60px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden text-slate-100">
        {/* Header Bar */}
        <div className="p-4 sm:p-4.5 border-b border-white/10 bg-gradient-to-r from-neutral-950 via-[#0d1424] to-neutral-950 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center text-slate-950 font-black">
                {isGoodNightActive ? (
                  <Moon className="w-5 h-5 text-slate-950 fill-slate-950 animate-pulse" />
                ) : (
                  <Bot className="w-5 h-5 text-slate-950" />
                )}
              </div>
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950 ring-1 ring-emerald-400" />
            </div>

            <div className="text-left">
              <div className="flex items-center gap-2">
                <span className="font-black text-base sm:text-lg text-white tracking-wide">
                  FADI KING AI VIP
                </span>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-amber-400 text-slate-950 uppercase tracking-wider">
                  SONG & CHAT MASTER
                </span>
              </div>
              <p className="text-[11px] text-amber-200/70 font-medium">
                {isGoodNightActive ? '🌙 Good Night Sleep Mode Active' : '🎵 Online · Music & 8K Media AI'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* 1-Tap Good Night Mode Toggle */}
            <button
              type="button"
              onClick={handleToggleNight}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shadow-md active:scale-95 ${
                isGoodNightActive
                  ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-cyan-500/40 font-black ring-2 ring-cyan-400/50'
                  : 'bg-neutral-900/90 text-amber-300 border-amber-500/40 hover:bg-neutral-800'
              }`}
              title="Toggle Good Night Mode"
            >
              <Moon className={`w-3.5 h-3.5 ${isGoodNightActive ? 'fill-slate-950' : 'text-amber-400'}`} />
              <span className="hidden sm:inline">
                {isGoodNightActive ? 'Good Night ON' : 'Good Night'}
              </span>
            </button>

            {/* Close Modal Button */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="w-9 h-9 rounded-2xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors border border-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Integrated Song Player Strip ("Song Wala") */}
        <div className="px-4 py-2.5 bg-neutral-950/90 border-b border-white/10 shrink-0">
          <div className="flex items-center justify-between gap-3">
            {/* Track Info & Visualizer */}
            <div className="flex items-center gap-2.5 min-w-0 flex-1">
              <button
                type="button"
                onClick={() => handleTogglePlay()}
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-transform active:scale-90 cursor-pointer shadow-md ${
                  isPlaying
                    ? 'bg-amber-400 text-slate-950 font-black ring-2 ring-amber-300 animate-pulse'
                    : 'bg-slate-800 text-slate-200 hover:text-white'
                }`}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>

              {/* Pulsing Visualizer wave bars */}
              <div className="flex items-end gap-0.5 h-4 shrink-0">
                <span className={`w-1 bg-amber-400 rounded-full transition-all ${isPlaying ? 'h-4 animate-bounce' : 'h-1.5'}`} style={{ animationDuration: '0.6s' }} />
                <span className={`w-1 bg-yellow-400 rounded-full transition-all ${isPlaying ? 'h-3 animate-bounce' : 'h-2'}`} style={{ animationDuration: '0.4s' }} />
                <span className={`w-1 bg-amber-300 rounded-full transition-all ${isPlaying ? 'h-4.5 animate-bounce' : 'h-1'}`} style={{ animationDuration: '0.8s' }} />
              </div>

              <div className="min-w-0 flex-1 text-left">
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-bold text-white truncate">{currentTrack.name}</p>
                </div>
                <p className="text-[10px] text-amber-300/80 truncate">{currentTrack.mood}</p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handlePrevTrack}
                className="w-7 h-7 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                title="Previous Song"
              >
                <SkipBack className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleNextTrack}
                className="w-7 h-7 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                title="Next Song"
              >
                <SkipForward className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setShowPlaylist(!showPlaylist);
                }}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer border ${
                  showPlaylist
                    ? 'bg-amber-400 text-slate-950 border-amber-300 font-extrabold'
                    : 'bg-neutral-900 text-slate-300 border-white/10 hover:text-white'
                }`}
                title="Playlist"
              >
                <ListMusic className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Songs</span>
              </button>
            </div>
          </div>

          {/* Sleep Timer Bar when Good Night or timer is running */}
          {(isGoodNightActive || sleepTimerMinutes > 0) && (
            <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-amber-200/90">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sleep Timer:</span>
                <span className="font-mono font-bold text-cyan-300">
                  {sleepSecondsLeft > 0
                    ? `${Math.floor(sleepSecondsLeft / 60)}m ${sleepSecondsLeft % 60}s`
                    : 'Off'}
                </span>
              </div>

              <div className="flex items-center gap-1">
                {[15, 30, 45, 60].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => handleSetTimer(mins)}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                      sleepTimerMinutes === mins
                        ? 'bg-cyan-500 text-slate-950 font-black'
                        : 'bg-neutral-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
                {sleepTimerMinutes > 0 && (
                  <button
                    type="button"
                    onClick={() => handleSetTimer(0)}
                    className="text-[10px] text-rose-400 hover:text-rose-300 px-1 font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Collapsible Playlist Drawer */}
        {showPlaylist && (
          <div className="max-h-48 overflow-y-auto bg-neutral-950/95 border-b border-amber-500/20 p-2 divide-y divide-white/5 shrink-0">
            {HOBBY_TRACKS.map((track) => {
              const isSelected = track.id === currentTrackId;
              return (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => handleSelectTrack(track.id)}
                  className={`w-full p-2 rounded-xl text-left flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'hover:bg-white/5 text-slate-300'
                  }`}
                >
                  <div className="truncate">
                    <p className="text-xs font-bold text-white truncate">{track.name}</p>
                    <p className="text-[10px] text-slate-400">{track.genre}</p>
                  </div>
                  {isSelected && isPlaying && (
                    <span className="text-[10px] font-bold text-amber-400 flex items-center gap-1 shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping inline-block" />
                      PLAYING
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* Chat Message Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 scroll-smooth">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-[78%] p-3.5 rounded-3xl text-sm leading-relaxed shadow-lg ${
                    isBot
                      ? 'bg-neutral-900/90 border border-amber-500/30 text-slate-100 rounded-tl-sm'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-medium rounded-tr-sm shadow-amber-500/20'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Action Buttons if Bot proposed any */}
                  {msg.actions && msg.actions.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/10 flex flex-wrap gap-1.5">
                      {msg.actions.map((act, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => handleActionClick(act.action, act.trackId)}
                          className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 hover:bg-amber-400 hover:text-slate-950 border border-amber-400/40 transition-all cursor-pointer active:scale-95 shadow-sm"
                        >
                          {act.label}
                        </button>
                      ))}
                    </div>
                  )}

                  <span
                    className={`text-[9px] block text-right mt-1.5 font-mono ${
                      isBot ? 'text-neutral-400' : 'text-slate-900/80'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-neutral-900/80 border border-white/10 w-28 text-slate-400 text-xs">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce [animation-delay:0.4s]" />
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-neutral-950/80 border-t border-white/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          <button
            type="button"
            onClick={() => handleSendMessage('Good Night! Mujhe koi sleep song sunao')}
            className="px-2.5 py-1 rounded-full text-xs font-bold bg-neutral-900 hover:bg-white/10 text-cyan-300 border border-cyan-500/30 whitespace-nowrap cursor-pointer shrink-0"
          >
            🌙 Good Night Mode
          </button>
          <button
            type="button"
            onClick={() => handleSendMessage('Pashto Sad Rubab gana lagao')}
            className="px-2.5 py-1 rounded-full text-xs font-bold bg-neutral-900 hover:bg-white/10 text-amber-300 border border-amber-500/30 whitespace-nowrap cursor-pointer shrink-0"
          >
            😢 Sad Rubab Song
          </button>
          <button
            type="button"
            onClick={() => handleSendMessage('Relaxing Lo-Fi night beats bajao')}
            className="px-2.5 py-1 rounded-full text-xs font-bold bg-neutral-900 hover:bg-white/10 text-slate-300 border border-white/10 whitespace-nowrap cursor-pointer shrink-0"
          >
            🎧 Lo-Fi Beats
          </button>
          <button
            type="button"
            onClick={() => handleSendMessage('How to download in 8K Ultra HD?')}
            className="px-2.5 py-1 rounded-full text-xs font-bold bg-neutral-900 hover:bg-white/10 text-slate-300 border border-white/10 whitespace-nowrap cursor-pointer shrink-0"
          >
            ⚡ 8K Download Help
          </button>
          <button
            type="button"
            onClick={() => handleSendMessage('VIP lifetime upgrade price kya hai?')}
            className="px-2.5 py-1 rounded-full text-xs font-bold bg-neutral-900 hover:bg-white/10 text-slate-300 border border-white/10 whitespace-nowrap cursor-pointer shrink-0"
          >
            👑 VIP Activation
          </button>
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-neutral-950 border-t border-white/10 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about 8K downloads, play songs, or Good Night..."
              className="flex-1 bg-neutral-900 border border-white/10 rounded-2xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="w-11 h-11 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black flex items-center justify-center hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shrink-0 shadow-md shadow-amber-500/20 active:scale-95"
            >
              <Send className="w-4 h-4 ml-0.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
