import React, { useRef, useEffect, useState } from 'react';
import {
  Zap,
  Package,
  Headphones,
  Music2,
  Crown,
  Sparkles,
  Bot,
  Layers,
  Moon,
  Flame,
} from 'lucide-react';
import { playClickSound } from '../utils/sound';
import { speakFeature } from '../utils/voiceGuide';

export type AppNavTab = 'single' | 'batch' | 'studio' | 'chatbot' | 'vip';

interface TabItem {
  id: AppNavTab;
  label: string;
  badge?: string;
  icon: React.ReactNode;
  activeIcon: React.ReactNode;
  subtitle: string;
}

interface FadiKingTabSliderProps {
  activeTab: AppNavTab;
  onChangeTab: (tab: AppNavTab) => void;
  isGoodNightActive?: boolean;
}

export const FadiKingTabSlider: React.FC<FadiKingTabSliderProps> = ({
  activeTab,
  onChangeTab,
  isGoodNightActive = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [sliderStyle, setSliderStyle] = useState<{ left: number; width: number }>({
    left: 0,
    width: 0,
  });

  const tabs: TabItem[] = [
    {
      id: 'single',
      label: 'Direct 8K',
      badge: 'FAST',
      icon: <Zap className="w-4 h-4 text-slate-400 group-hover:text-amber-300" />,
      activeIcon: <Zap className="w-5 h-5 text-slate-950 fill-slate-950" />,
      subtitle: 'Single Link',
    },
    {
      id: 'batch',
      label: 'Batch URLs',
      badge: '10x',
      icon: <Package className="w-4 h-4 text-slate-400 group-hover:text-amber-300" />,
      activeIcon: <Layers className="w-5 h-5 text-slate-950 fill-slate-950" />,
      subtitle: 'Multi Queue',
    },
    {
      id: 'studio',
      label: 'Audio Studio',
      badge: '320k',
      icon: <Headphones className="w-4 h-4 text-slate-400 group-hover:text-amber-300" />,
      activeIcon: <Headphones className="w-5 h-5 text-slate-950 fill-slate-950" />,
      subtitle: 'MP3 Extract',
    },
    {
      id: 'chatbot',
      label: isGoodNightActive ? 'Good Night' : 'AI Song & Bot',
      badge: isGoodNightActive ? '🌙' : 'VIP',
      icon: (
        <div className="relative flex items-center justify-center">
          {isGoodNightActive ? (
            <Moon className="w-4 h-4 text-cyan-300 animate-pulse" />
          ) : (
            <Music2 className="w-4 h-4 text-amber-400" />
          )}
        </div>
      ),
      activeIcon: (
        <div className="relative flex items-center justify-center">
          {isGoodNightActive ? (
            <Moon className="w-5 h-5 text-slate-950 fill-slate-950" />
          ) : (
            <Bot className="w-5 h-5 text-slate-950 fill-slate-950" />
          )}
        </div>
      ),
      subtitle: isGoodNightActive ? 'Sleep Ambience' : 'Song & Chat',
    },
    {
      id: 'vip',
      label: 'VIP Vault',
      badge: 'PRO',
      icon: <Crown className="w-4 h-4 text-amber-400/90 group-hover:text-amber-300" />,
      activeIcon: <Crown className="w-5 h-5 text-slate-950 fill-slate-950" />,
      subtitle: 'Lifetime Pass',
    },
  ];

  // Recalculate slider position matching reference video curved notch
  useEffect(() => {
    const updatePosition = () => {
      if (!containerRef.current) return;
      const activeEl = containerRef.current.querySelector<HTMLElement>(
        `[data-tab-id="${activeTab}"]`
      );
      if (activeEl) {
        const containerRect = containerRef.current.getBoundingClientRect();
        const activeRect = activeEl.getBoundingClientRect();
        setSliderStyle({
          left: activeRect.left - containerRect.left,
          width: activeRect.width,
        });
      }
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);
    return () => window.removeEventListener('resize', updatePosition);
  }, [activeTab]);

  return (
    <div className="w-full max-w-2xl mx-auto my-3 px-2 select-none">
      {/* Outer Shell: High-Tech Dark Carbon Glass Pill */}
      <div
        ref={containerRef}
        className="relative flex items-center justify-between p-1.5 rounded-3xl bg-neutral-950/80 border border-white/10 backdrop-blur-3xl shadow-[0_12px_40px_rgba(0,0,0,0.8)] overflow-hidden"
      >
        {/* Animated Sliding Curved Notch / Pill Highlight matching Video 1 */}
        <div
          className="absolute top-1.5 bottom-1.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 shadow-[0_0_25px_rgba(251,191,36,0.5)] transition-all duration-300 cubic-bezier(0.34, 1.56, 0.64, 1) pointer-events-none z-0"
          style={{
            transform: `translateX(${sliderStyle.left}px)`,
            width: `${sliderStyle.width}px`,
          }}
        >
          {/* Subtle curved inverted notch glow reflection */}
          <div className="absolute inset-0 bg-gradient-to-t from-white/20 via-transparent to-white/40 rounded-2xl" />
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-white/70 blur-[1px]" />
        </div>

        {/* Tab Buttons */}
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              data-tab-id={tab.id}
              type="button"
              onClick={() => {
                if (activeTab === tab.id) return;
                playClickSound();
                speakFeature(
                  tab.label,
                  `Switched to ${tab.label}. ${tab.subtitle}.`
                );
                onChangeTab(tab.id);
              }}
              className={`relative z-10 flex-1 flex flex-col items-center justify-center py-2 px-1 rounded-2xl transition-all duration-200 cursor-pointer group active:scale-95 ${
                isActive
                  ? 'text-slate-950 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Icon Container with subtle floating microinteraction */}
              <div
                className={`relative flex items-center justify-center transition-transform duration-300 ${
                  isActive ? '-translate-y-0.5 scale-110 drop-shadow-sm' : 'group-hover:scale-105'
                }`}
              >
                {isActive ? tab.activeIcon : tab.icon}

                {/* Badge Pill */}
                {tab.badge && (
                  <span
                    className={`absolute -top-2 -right-3 text-[8px] font-black px-1 py-0.2 rounded-full border leading-tight ${
                      isActive
                        ? 'bg-slate-950 text-amber-300 border-slate-800'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </div>

              {/* Title */}
              <span
                className={`text-[11px] sm:text-xs font-bold tracking-tight mt-1 transition-colors leading-tight ${
                  isActive ? 'text-slate-950 font-black' : 'text-slate-300 group-hover:text-white'
                }`}
              >
                {tab.label}
              </span>

              {/* Micro Subtitle (visible on sm screens) */}
              <span
                className={`text-[9px] hidden sm:block font-medium tracking-tighter leading-none mt-0.5 ${
                  isActive ? 'text-slate-900 font-extrabold' : 'text-slate-500'
                }`}
              >
                {tab.subtitle}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
