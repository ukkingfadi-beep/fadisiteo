import React, { useState, useRef, useEffect } from 'react';
import {
  Music2,
  Play,
  Pause,
  Download,
  Volume2,
  VolumeX,
  FastForward,
  RotateCcw,
  Sparkles,
  Sliders,
  Check,
  Disc,
} from 'lucide-react';
import type { VideoInfoResponse, VideoFormatOption } from '../types/downloader';
import type { Language } from '../utils/translations';
import { translations } from '../utils/translations';
import { playClickSound, playSuccessChime } from '../utils/sound';
import { canDownload, consumeDownload } from '../utils/quotaManager';

interface AudioStudioProps {
  lang: Language;
  videoInfo: VideoInfoResponse | null;
  onDownloadStarted: (info: VideoInfoResponse, format: VideoFormatOption) => void;
  hasJoinedWhatsapp: boolean;
  onRequireWhatsappJoin: (pendingFormat: VideoFormatOption) => void;
  onRequireUpgrade?: () => void;
}

export const AudioStudio: React.FC<AudioStudioProps> = ({
  lang,
  videoInfo,
  onDownloadStarted,
  hasJoinedWhatsapp,
  onRequireWhatsappJoin,
  onRequireUpgrade,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [bitrate, setBitrate] = useState<'320' | '256' | '128'>('320');
  const [isMuted, setIsMuted] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const t = translations[lang];

  // Find audio formats from currently loaded videoInfo
  const audioFormats = videoInfo?.formats.filter(
    (f) => f.isAudioOnly || (!f.hasVideo && f.hasAudio) || f.formatId.includes('audio')
  );
  const activeAudioUrl = audioFormats?.[0]?.directUrl;

  useEffect(() => {
    // Waveform canvas visualizer
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const bars = 48;
      const barWidth = canvas.width / bars - 2;

      for (let i = 0; i < bars; i++) {
        const height = isPlaying
          ? Math.sin(phase + i * 0.3) * 16 + Math.cos(phase * 1.5 + i * 0.2) * 8 + 24
          : 6 + (i % 5) * 3;
        const x = i * (barWidth + 2);
        const y = (canvas.height - height) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + height);
        grad.addColorStop(0, '#f59e0b');
        grad.addColorStop(1, '#10b981');

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, height);
      }

      phase += 0.08;
      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying]);

  const togglePlay = () => {
    playClickSound();
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
  };

  const handleSpeedChange = (speed: number) => {
    playClickSound();
    setPlaybackRate(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const formatTime = (sec: number) => {
    if (isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleDownloadAudio = () => {
    if (!videoInfo) return;
    const format = audioFormats?.[0] || {
      formatId: `audio_mp3_${bitrate}k`,
      qualityLabel: `Audio MP3 (${bitrate}kbps Studio)`,
      resolution: 'Audio',
      ext: 'mp3',
      hasVideo: false,
      hasAudio: true,
      isAudioOnly: true,
      directUrl: activeAudioUrl,
    };

    if (!hasJoinedWhatsapp) {
      onRequireWhatsappJoin(format);
      return;
    }

    if (!canDownload()) {
      if (onRequireUpgrade) {
        onRequireUpgrade();
      }
      return;
    }

    consumeDownload();

    playClickSound();
    onDownloadStarted(videoInfo, format);

    const cleanTitle = (videoInfo.title || 'audio')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .substring(0, 50);
    const filename = `FADI_KING_${cleanTitle}_${bitrate}kbps.mp3`;

    const downloadLink = format.directUrl
      ? `/api/proxy-stream?url=${encodeURIComponent(format.directUrl)}&filename=${encodeURIComponent(filename)}`
      : `/api/download?url=${encodeURIComponent(videoInfo.originalUrl)}&formatId=yt_audio_mp3`;

    const a = document.createElement('a');
    a.href = downloadLink;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => document.body.removeChild(a), 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-8 bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative overflow-hidden">
      {/* Top accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-500" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Music2 className="w-6 h-6 text-amber-400" />
            <span>{t.audioStudioTitle}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">{t.audioStudioDesc}</p>
        </div>

        {/* Bitrate Selector */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800 self-start sm:self-auto">
          {(['320', '256', '128'] as const).map((b) => (
            <button
              key={b}
              onClick={() => {
                playClickSound();
                setBitrate(b);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                bitrate === b
                  ? 'bg-gradient-to-r from-amber-400 to-emerald-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {b}kbps
            </button>
          ))}
        </div>
      </div>

      {/* Main Studio Console */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Track Vinyl / Cover Info */}
        <div className="md:col-span-4 flex flex-col items-center text-center p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80">
          <div className="w-28 h-28 rounded-full bg-slate-900 border-4 border-amber-500/30 flex items-center justify-center relative shadow-xl overflow-hidden group">
            {videoInfo?.thumbnailUrl ? (
              <img
                src={videoInfo.thumbnailUrl}
                alt="Audio Cover"
                className={`w-full h-full object-cover rounded-full ${
                  isPlaying ? 'animate-spin' : ''
                }`}
                style={{ animationDuration: '6s' }}
              />
            ) : (
              <Disc className={`w-12 h-12 text-amber-400 ${isPlaying ? 'animate-spin' : ''}`} />
            )}
            <div className="absolute w-6 h-6 rounded-full bg-slate-950 border-2 border-amber-400" />
          </div>

          <h3 className="mt-4 text-xs sm:text-sm font-bold text-white truncate max-w-xs">
            {videoInfo?.title || 'No Audio Track Selected'}
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {videoInfo?.author || 'Analyze a video link above to load audio'}
          </p>
        </div>

        {/* Waveform & Playback Controls */}
        <div className="md:col-span-8 flex flex-col justify-between space-y-4">
          {/* Waveform Canvas */}
          <div className="h-16 w-full bg-slate-950/80 rounded-2xl border border-slate-800 p-2 flex items-center justify-center overflow-hidden">
            <canvas ref={canvasRef} width={480} height={60} className="w-full h-full" />
          </div>

          {/* Time Scrubber */}
          <div className="space-y-1.5">
            <input
              type="range"
              min={0}
              max={duration || 100}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Playback Button Group */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                onClick={togglePlay}
                disabled={!activeAudioUrl}
                className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-lg ${
                  activeAudioUrl
                    ? 'bg-gradient-to-r from-amber-400 to-emerald-400 text-slate-950 hover:scale-105 active:scale-95'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-slate-950" /> : <Play className="w-5 h-5 fill-slate-950 ml-0.5" />}
              </button>

              <button
                onClick={() => {
                  if (audioRef.current) audioRef.current.currentTime = 0;
                  setCurrentTime(0);
                }}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title="Restart Track"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Speed Buttons */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
                {[0.75, 1, 1.25, 1.5].map((s) => (
                  <button
                    key={s}
                    onClick={() => handleSpeedChange(s)}
                    className={`px-2 py-0.5 rounded-lg transition-colors cursor-pointer ${
                      playbackRate === s
                        ? 'bg-amber-400 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </div>

            {/* Download Audio Button */}
            <button
              onClick={handleDownloadAudio}
              disabled={!videoInfo}
              className={`px-5 py-2.5 rounded-xl font-black text-xs transition-all flex items-center gap-2 cursor-pointer ${
                videoInfo
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Download className="w-4 h-4" />
              <span>Download MP3 ({bitrate}k)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Hidden audio element if URL exists */}
      {activeAudioUrl && (
        <audio
          ref={audioRef}
          src={`/api/proxy-stream?url=${encodeURIComponent(activeAudioUrl)}&inline=true`}
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setIsPlaying(false)}
          muted={isMuted}
        />
      )}
    </div>
  );
};
