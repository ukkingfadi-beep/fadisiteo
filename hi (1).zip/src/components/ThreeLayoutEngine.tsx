import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ThreeLayoutEngineProps {
  zDepth?: number;
  perspective?: boolean;
  stackingCount?: number;
  glowShift?: number;
}

export const ThreeLayoutEngine: React.FC<ThreeLayoutEngineProps> = ({
  zDepth = 2.0,
  perspective = true,
  stackingCount = 2,
  glowShift = 0.5,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = mount.clientWidth || 320;
    const height = mount.clientHeight || 240;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0c10, 0.05);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 5, 8);
    camera.lookAt(0, 0, 0);

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    mount.appendChild(renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xfff0c2, 0.9);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffd700, 2.5);
    dirLight.position.set(5, 10, 7);
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0xf59e0b, 3, 15);
    pointLight.position.set(-3, 3, 2);
    scene.add(pointLight);

    // 5. 3D Isometric Golden Grid
    const gridHelper = new THREE.GridHelper(10, 16, 0xd4af37, 0x3d3010);
    gridHelper.position.y = -0.05;
    scene.add(gridHelper);

    // 6. 3D Extruded Layout Panels / Nodes
    const group = new THREE.Group();
    scene.add(group);

    // Golden metallic materials
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.85,
      roughness: 0.25,
      emissive: 0x4a3908,
      emissiveIntensity: 0.2 * (1 + glowShift),
    });

    const darkGoldMat = new THREE.MeshStandardMaterial({
      color: 0x1f1a10,
      metalness: 0.9,
      roughness: 0.4,
      emissive: 0x241a05,
      emissiveIntensity: 0.1,
    });

    const glowGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0xf59e0b,
      metalness: 0.2,
      roughness: 0.1,
      transmission: 0.6,
      thickness: 0.5,
      transparent: true,
      opacity: 0.85,
    });

    // Create stacked 3D planes / cards
    const cardGeom = new THREE.BoxGeometry(2.4, 0.15 * zDepth, 1.6);
    const card1 = new THREE.Mesh(cardGeom, goldMat);
    card1.position.set(-1.4, 0.4 * zDepth, -0.6);
    group.add(card1);

    const cardGeom2 = new THREE.BoxGeometry(1.8, 0.2 * zDepth, 2.2);
    const card2 = new THREE.Mesh(cardGeom2, glowGlassMat);
    card2.position.set(1.4, 0.5 * zDepth, 0.2);
    group.add(card2);

    const cardGeom3 = new THREE.BoxGeometry(1.6, 0.12 * zDepth, 1.2);
    const card3 = new THREE.Mesh(cardGeom3, darkGoldMat);
    card3.position.set(-1.0, 0.2 * zDepth, 1.2);
    group.add(card3);

    // Add extra layers if stacking count > 1
    if (stackingCount >= 2) {
      const topPillGeom = new THREE.CylinderGeometry(0.3, 0.3, 0.6 * zDepth, 16);
      const topPill = new THREE.Mesh(topPillGeom, goldMat);
      topPill.position.set(1.4, 1.0 * zDepth, 0.2);
      group.add(topPill);
    }

    // Pointer interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetRotationX = 0.2;
    let targetRotationY = -0.4;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = mount.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseX = x;
      mouseY = y;
    };

    mount.addEventListener('mousemove', handleMouseMove);

    // Resize handler
    const handleResize = () => {
      if (!mount) return;
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Gentle floating animation
      card1.position.y = 0.4 * zDepth + Math.sin(elapsed * 1.5) * 0.08;
      card2.position.y = 0.5 * zDepth + Math.cos(elapsed * 1.8) * 0.08;
      card3.position.y = 0.2 * zDepth + Math.sin(elapsed * 1.2 + 1) * 0.05;

      // Smooth camera tilt towards mouse
      targetRotationY = -0.4 + mouseX * 0.6;
      targetRotationX = 0.3 - mouseY * 0.4;

      group.rotation.y += (targetRotationY - group.rotation.y) * 0.05;
      group.rotation.x += (targetRotationX - group.rotation.x) * 0.05;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      mount.removeEventListener('mousemove', handleMouseMove);
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [zDepth, perspective, stackingCount, glowShift]);

  return (
    <div className="relative w-full h-full min-h-[220px] rounded-xl overflow-hidden bg-gradient-to-b from-[#0e121a] to-[#07090e] border border-amber-500/25 flex items-center justify-center">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      <div className="absolute top-2 left-2 text-[10px] font-mono text-amber-300/80 bg-black/60 px-2 py-0.5 rounded border border-amber-500/20 backdrop-blur-sm pointer-events-none">
        3D Perspective Grid · Drag to Rotate
      </div>
    </div>
  );
};
