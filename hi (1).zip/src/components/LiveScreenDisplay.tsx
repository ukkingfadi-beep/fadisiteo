import React, { useState, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import {
  LiveScreenNoticeConfig,
  ShowcaseSlide,
  DEFAULT_SHOWCASE_SLIDES,
} from '../utils/themeAndConfigManager';

interface LiveScreenDisplayProps {
  notice: LiveScreenNoticeConfig;
  onlineCount?: number;
  onOpenUpgradeModal?: () => void;
  whatsappUrl?: string;
  whatsappPhone?: string;
}

export const LiveScreenDisplay: React.FC<LiveScreenDisplayProps> = ({
  notice,
}) => {
  const [isMuted, setIsMuted] = useState(true);
  const [videoError, setVideoError] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // If live screen is disabled or media is deleted, render nothing (completely hidden)
  if (
    !notice ||
    notice.enabled === false ||
    !notice.slides ||
    notice.slides.length === 0 ||
    !notice.slides[0]?.mediaUrl
  ) {
    return null;
  }

  const currentSlide = notice.slides[0];
  const isVideo =
    (currentSlide.mediaType === 'video' ||
      /\.(mp4|webm|mov|ogg|m4v)(\?.*)?$/i.test(currentSlide.mediaUrl)) &&
    !videoError;

  return (
    <div className="w-full relative z-30 py-2 sm:py-3 px-3 sm:px-6">
      {/* Pure, Clean Cinematic Canvas without any badges, prices, text or buttons */}
      <div className="max-w-5xl mx-auto relative rounded-3xl overflow-hidden bg-black/80 border border-white/10 shadow-[0_12px_45px_rgba(0,0,0,0.65)] backdrop-blur-2xl">
        <div className="relative w-full h-[220px] sm:h-[300px] md:h-[360px] lg:h-[400px] bg-black overflow-hidden flex items-center justify-center">
          {isVideo ? (
            <video
              ref={videoRef}
              key={currentSlide.mediaUrl}
              src={currentSlide.mediaUrl}
              autoPlay
              loop
              muted={isMuted}
              playsInline
              preload="auto"
              onLoadedData={() => {
                if (videoRef.current) {
                  videoRef.current.play().catch(() => {});
                }
              }}
              onError={() => {
                setVideoError(true);
              }}
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              key={currentSlide.mediaUrl}
              src={
                currentSlide.mediaUrl ||
                'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80'
              }
              alt="Live Screen"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80';
              }}
              className="w-full h-full object-cover"
            />
          )}

          {/* Sound Toggle (Top-Right only when video is active) */}
          {isVideo && (
            <div className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (videoRef.current) {
                    const nextMuted = !isMuted;
                    videoRef.current.muted = nextMuted;
                    setIsMuted(nextMuted);
                    if (!nextMuted) {
                      videoRef.current.play().catch(() => {});
                    }
                  }
                }}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-md border border-white/20 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg hover:scale-105"
                title={isMuted ? 'Turn Sound ON' : 'Mute Sound'}
              >
                {!isMuted ? (
                  <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-300" />
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
