import React, { useState } from 'react';
import {
  Crown,
  LayoutDashboard,
  BarChart3,
  Users,
  FileEdit,
  CreditCard,
  Sliders,
  Settings,
  Headphones,
  Sparkles,
  Download,
  Folder,
  Shield,
  Clock,
  FileText,
  RotateCw,
  Cloud,
  Box,
  Layers,
  Check,
  Send,
  MessageCircle,
  TrendingUp,
  Activity,
  Zap,
  Globe,
  Lock,
  ChevronRight,
  Tv,
  Music,
  Video,
  Eye,
  SlidersHorizontal,
  Flame,
  Radio,
  Share2,
  X,
  AlertCircle,
  Play,
} from 'lucide-react';
import { ThreeLayoutEngine } from './ThreeLayoutEngine';
import { VideoResultCard } from './VideoResultCard';
import { BatchDownloader } from './BatchDownloader';
import { AudioStudio } from './AudioStudio';
import { DownloadHistory } from './DownloadHistory';
import { playClickSound, playSuccessChime } from '../utils/sound';
import type { SiteConfigState } from '../utils/themeAndConfigManager';
import type { Language } from '../utils/translations';
import type { VideoInfoResponse, VideoFormatOption, DownloadHistoryItem } from '../types/downloader';
import { translations, WHATSAPP_CHANNEL_LINK } from '../utils/translations';

interface UltraPremiumDashboardProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  siteConfig: SiteConfigState;
  onUpdateConfig: (cfg: SiteConfigState) => void;
  onlineCount: number;
  quotaRemaining: number;
  isLifetime: boolean;
  onOpenUpgrade: () => void;
  onOpenAdminModal: () => void;
  // Downloader integration
  currentUrl: string;
  onUrlChange: (url: string) => void;
  onAnalyze: (url: string) => void;
  isAnalyzing: boolean;
  videoInfo: VideoInfoResponse | null;
  errorMessage: string | null;
  onClearVideoInfo: () => void;
  hasUnlockedGate: boolean;
  onRequireWhatsappJoin: (pendingFormat: VideoFormatOption) => void;
  onDownloadStarted: (info: VideoInfoResponse, format: VideoFormatOption) => void;
  activeMode: 'single' | 'batch' | 'studio';
  onModeChange: (mode: 'single' | 'batch' | 'studio') => void;
  onSelectPlatform: (platformUrl: string) => void;
  history: DownloadHistoryItem[];
  onReDownload: (item: DownloadHistoryItem) => void;
  onClearHistory: () => void;
  onRequireUpgrade: () => void;
}

export const UltraPremiumDashboard: React.FC<UltraPremiumDashboardProps> = ({
  lang,
  onLanguageChange,
  siteConfig,
  onUpdateConfig,
  onlineCount,
  quotaRemaining,
  isLifetime,
  onOpenUpgrade,
  onOpenAdminModal,
  currentUrl,
  onUrlChange,
  onAnalyze,
  isAnalyzing,
  videoInfo,
  errorMessage,
  onClearVideoInfo,
  hasUnlockedGate,
  onRequireWhatsappJoin,
  onDownloadStarted,
  activeMode,
  onModeChange,
  onSelectPlatform,
  history,
  onReDownload,
  onClearHistory,
  onRequireUpgrade,
}) => {
  // Navigation tab state (Desktop Top Navigation)
  const [activeTab, setActiveTab] = useState<'admin' | 'analytics' | 'users' | 'content' | 'downloader'>('admin');
  const [sidebarItem, setSidebarItem] = useState<string>('home');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // 3D Engine State (Matching Screenshot 2)
  const [zDepth, setZDepth] = useState<number>(2.0);
  const [perspectiveCamera, setPerspectiveCamera] = useState<boolean>(true);
  const [elementStacking, setElementStacking] = useState<boolean>(true);
  const [hapticLevel, setHapticLevel] = useState<'Low' | 'Medium' | 'High'>('High');

  // 3D Icon Studio State (Matching Screenshot 2)
  const [colorShift, setColorShift] = useState<number>(75);
  const [lineWeight, setLineWeight] = useState<number>(1.0);
  const [depthExtrusion, setDepthExtrusion] = useState<number>(85);
  const [icon3DStyle, setIcon3DStyle] = useState<'embossed' | 'chrome' | 'glass' | 'neon'>('embossed');

  // Live UI Customizer State (Matching Screenshot 1 & 4)
  const [customTheme, setCustomTheme] = useState<'deep_gold' | 'gloss' | 'glassmorphism' | 'charcoal'>('deep_gold');
  const [selectedAccentColor, setSelectedAccentColor] = useState<string>('#d4af37');
  const [fontFamily, setFontFamily] = useState<string>('Plus Jakarta Sans');
  const [textSize, setTextSize] = useState<number>(100);
  const [layoutToggle, setLayoutToggle] = useState<'sidebar' | 'topbar'>('sidebar');

  // Modular Feature Toggles (Matching Screenshot 3)
  const [features, setFeatures] = useState({
    globalChat: true,
    realTimeAnalytics: true,
    vipMembership: true,
    liveCustomizer: true,
    downloadAccelerator: true,
    platformSync: true,
    modularityDepth: 1.0,
  });

  // Global Chat state
  const [chatMessages, setChatMessages] = useState([
    { id: '1', user: 'Fadi VIP', avatar: '👑', text: 'Hello, welcome to FADI KING VIP Global Encrypted Network!', time: '10:24', isVip: true },
    { id: '2', user: 'Member #892', avatar: '⚡', text: '8K Ultra HDR Downloader speed is blazing fast today!', time: '10:28', isVip: true },
    { id: '3', user: 'VIP Super Node', avatar: '🛡️', text: 'Singapore SG-01 Proxy connected. Zero buffer active.', time: '10:30', isVip: true },
  ]);
  const [inputChat, setInputChat] = useState('');

  // Mobile Bottom Tab & Stats (Matching Phone in screenshots)
  const [mobileBottomTab, setMobileBottomTab] = useState<'chat' | 'downloads' | 'live' | 'profile'>('downloads');
  const [glowShift, setGlowShift] = useState<number>(65);
  const [apply3DTheme, setApply3DTheme] = useState<boolean>(true);
  const [showAppliedToast, setShowAppliedToast] = useState(false);

  const t = translations[lang];

  const accentColors = [
    '#d4af37', // Gold
    '#f59e0b', // Amber
    '#eab308', // Yellow
    '#b45309', // Dark Gold
    '#fef08a', // Light Gold
    '#f97316', // Orange Glow
    '#10b981', // Emerald
    '#06b6d4', // Cyan
  ];

  const handleApplyChanges = () => {
    playSuccessChime();
    setShowAppliedToast(true);
    setTimeout(() => setShowAppliedToast(false), 2500);
  };

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputChat.trim()) return;
    playClickSound();
    const newMsg = {
      id: Date.now().toString(),
      user: isLifetime ? 'VIP Master (You)' : 'Guest VIP',
      avatar: '👑',
      text: inputChat.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isVip: true,
    };
    setChatMessages((prev) => [...prev, newMsg]);
    setInputChat('');
  };

  return (
    <div className="w-full min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden">
      {/* Golden Toast */}
      {showAppliedToast && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>Configuration Applied to all Devices!</span>
        </div>
      )}

      {/* 1. TOP HEADER: FK FADI KING ADMIN - ULTRA PREMIUM DASHBOARD */}
      <header className="sticky top-0 z-40 border-b border-amber-500/25 bg-[#0a0d14]/95 backdrop-blur-xl shadow-2xl shadow-black/80">
        <div className="max-w-[1720px] mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3 sm:gap-4">
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                playClickSound();
                setActiveTab('admin');
                setSidebarItem('home');
              }}
              className="flex items-center gap-2.5 sm:gap-3 text-left group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#fef08a] via-[#d4af37] to-[#996515] flex items-center justify-center shadow-lg shadow-amber-500/30 text-slate-950 font-black relative group-hover:scale-105 transition-all border border-amber-300/50">
                <Crown className="w-5 h-5 text-slate-950 fill-slate-950 drop-shadow-sm" strokeWidth={2.5} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-base sm:text-lg tracking-tight vip-text-gold drop-shadow-[0_2px_10px_rgba(212,175,55,0.4)]">
                    FADI KING
                  </span>
                  <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded bg-gradient-to-r from-amber-500/30 to-yellow-500/20 text-[#d4af37] border border-[#d4af37]/50 shadow-sm uppercase">
                    Admin
                  </span>
                </div>
                <p className="text-[9px] tracking-wider font-mono uppercase text-amber-300/80 font-bold hidden sm:block">
                  Ultra Premium Dashboard
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Tabs (Matching Screenshots) */}
          <nav className="hidden lg:flex items-center gap-1.5 p-1 rounded-xl bg-[#0e1320] border border-slate-800">
            <button
              onClick={() => {
                playClickSound();
                setActiveTab('admin');
                setSidebarItem('home');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveTab('analytics');
                setSidebarItem('analytics');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Analytics</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveTab('users');
                setSidebarItem('users');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Users</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveTab('content');
                setSidebarItem('content');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'content'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileEdit className="w-3.5 h-3.5" />
              <span>Content</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setActiveTab('downloader');
                setSidebarItem('downloader_direct');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'downloader'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Downloader Engine</span>
            </button>
          </nav>

          {/* Right Header Actions */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Live Online Badge */}
            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-xs font-bold shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
              </span>
              <span className="font-mono">{onlineCount}</span>
              <span>VIP Live</span>
            </div>

            {/* Live Customizer Button (Matching Screenshots) */}
            <button
              onClick={() => {
                playClickSound();
                setActiveTab('admin');
                setSidebarItem('theme');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/25 via-yellow-500/30 to-amber-500/20 hover:from-amber-500/35 hover:to-yellow-500/40 border border-amber-400/50 text-amber-300 text-xs font-black shadow-lg shadow-amber-950/40 active:scale-95 transition-all cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Live Customizer</span>
              <span className="sm:hidden">Customizer</span>
            </button>

            {/* Quota / Upgrade Button */}
            <button
              onClick={() => {
                playClickSound();
                onOpenUpgrade();
              }}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 text-xs font-bold font-mono active:scale-95 cursor-pointer"
            >
              {isLifetime ? '👑 Lifetime' : `${quotaRemaining}/5 Left`}
            </button>

            {/* Admin Center Lock */}
            <button
              onClick={() => {
                playClickSound();
                onOpenAdminModal();
              }}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-amber-400 hover:border-amber-500/40 transition-colors cursor-pointer"
              title="Admin Security & Credentials"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. BODY LAYOUT: LEFT SIDEBAR + MAIN CONTENT DASHBOARD */}
      <div className="flex-1 max-w-[1720px] w-full mx-auto px-2 sm:px-4 lg:px-6 py-4 flex gap-4 lg:gap-6">
        {/* EXECUTIVE LEFT SIDEBAR (Desktop) */}
        <aside
          className={`hidden md:flex flex-col gap-1 shrink-0 transition-all duration-300 p-2.5 rounded-2xl bg-[#0b0e17]/90 border border-amber-500/20 shadow-xl backdrop-blur-xl h-fit sticky top-20 ${
            sidebarCollapsed ? 'w-16' : 'w-60'
          }`}
        >
          <div className="flex items-center justify-between px-2 py-2 mb-1 border-b border-slate-800">
            {!sidebarCollapsed && (
              <span className="text-[10px] font-mono font-bold tracking-wider text-amber-400/80 uppercase">
                Main Menu
              </span>
            )}
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 ml-auto"
              title="Toggle Sidebar"
            >
              <Layers className="w-3.5 h-3.5" />
            </button>
          </div>

          {[
            { id: 'home', label: 'Dashboard Home', icon: LayoutDashboard },
            { id: 'analytics', label: 'Real-time Analytics', icon: BarChart3 },
            { id: 'users', label: 'User Management', icon: Users },
            { id: 'content', label: 'Content Editor', icon: FileEdit },
            { id: 'gateway', label: 'Payment Gateway', icon: CreditCard },
            { id: 'theme', label: 'Live UI Theme Control', icon: Sliders },
            { id: '3d_layout', label: '3D Layout Engine', icon: Box },
            { id: 'settings', label: 'System Settings', icon: Settings },
            { id: 'support', label: 'VIP Support', icon: Headphones },
            { id: 'downloader_direct', label: 'Video Downloader', icon: Download },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = sidebarItem === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  playClickSound();
                  setSidebarItem(item.id);
                  if (item.id === 'downloader_direct') {
                    setActiveTab('downloader');
                  } else {
                    setActiveTab('admin');
                  }
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/10 text-amber-300 border border-amber-400/40 shadow-sm font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
                title={sidebarCollapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </aside>

        {/* MAIN DASHBOARD CONTENT AREA */}
        <main className="flex-1 min-w-0 flex flex-col gap-5 pb-24">
          {/* Active Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center justify-between gap-3 animate-in fade-in duration-200">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorMessage}</span>
              </div>
              <button
                onClick={onClearVideoInfo}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Active Analyzed Video Result Card (Rendered prominently right at the top when user enters link!) */}
          {videoInfo && (
            <div className="rounded-3xl bg-[#0a0d15] border-2 border-amber-500/40 p-4 sm:p-6 shadow-2xl relative animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-black text-amber-400 uppercase tracking-wider font-mono">
                    8K / 4K Video Analysis Ready
                  </span>
                </div>
                <button
                  onClick={onClearVideoInfo}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
                  title="Close preview"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <VideoResultCard
                info={videoInfo}
                lang={lang}
                onDownloadStarted={onDownloadStarted}
                hasJoinedWhatsapp={hasUnlockedGate}
                onRequireWhatsappJoin={onRequireWhatsappJoin}
                onOpenStudio={() => {
                  onModeChange('studio');
                  setActiveTab('downloader');
                }}
                onRequireUpgrade={onRequireUpgrade}
              />
            </div>
          )}

          {/* TAB 1: ADMIN ULTRA PREMIUM DASHBOARD (MATCHING SCREENSHOTS) */}
          {activeTab === 'admin' && (
            <>
              {/* PRIMARY ROW 1: LIVE UI CUSTOMIZER + 3D LAYOUT ENGINE + GLOBAL CHAT */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                {/* CARD 1: LIVE UI CUSTOMIZER (Screenshot 1 & 4) */}
                <div className="lg:col-span-4 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <Sliders className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-white">Live UI Customizer</h3>
                        <p className="text-[10px] text-slate-400">Main Theme & Visual Controls</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold">
                      LIVE
                    </span>
                  </div>

                  {/* Main Theme Switcher */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Main Theme
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {[
                        { id: 'deep_gold', label: 'Deep Gold' },
                        { id: 'gloss', label: 'Gloss' },
                        { id: 'glassmorphism', label: 'Glassmorphism' },
                        { id: 'charcoal', label: 'Charcoal' },
                      ].map((tItem) => (
                        <button
                          key={tItem.id}
                          onClick={() => {
                            playClickSound();
                            setCustomTheme(tItem.id as any);
                          }}
                          className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                            customTheme === tItem.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md ring-1 ring-amber-400/40'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {tItem.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Accent Color Swatches */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Accent Color
                    </label>
                    <div className="flex items-center gap-2 flex-wrap">
                      {accentColors.map((c) => (
                        <button
                          key={c}
                          onClick={() => {
                            playClickSound();
                            setSelectedAccentColor(c);
                          }}
                          style={{ backgroundColor: c }}
                          className={`w-7 h-7 rounded-lg transition-transform cursor-pointer border ${
                            selectedAccentColor === c
                              ? 'scale-110 border-white ring-2 ring-amber-400 shadow-lg shadow-amber-500/40'
                              : 'border-black/50 hover:scale-105'
                          }`}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Font Controls */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Font Controls
                    </label>
                    <div className="space-y-2">
                      <select
                        value={fontFamily}
                        onChange={(e) => setFontFamily(e.target.value)}
                        className="w-full py-1.5 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-amber-400"
                      >
                        <option value="Plus Jakarta Sans">Plus Jakarta Sans (Executive)</option>
                        <option value="Inter">Inter (Ultra Clean)</option>
                        <option value="JetBrains Mono">JetBrains Mono (VIP Dev)</option>
                      </select>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>Text Size</span>
                        <span className="text-amber-400 font-bold">{textSize}%</span>
                      </div>
                      <input
                        type="range"
                        min="80"
                        max="125"
                        value={textSize}
                        onChange={(e) => setTextSize(parseInt(e.target.value, 10))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                    </div>
                  </div>

                  {/* Layout Toggles */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Layout Toggles
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <button
                        onClick={() => {
                          playClickSound();
                          setLayoutToggle('sidebar');
                        }}
                        className={`py-2 px-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                          layoutToggle === 'sidebar'
                            ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        Vertical Sidebar
                      </button>
                      <button
                        onClick={() => {
                          playClickSound();
                          setLayoutToggle('topbar');
                        }}
                        className={`py-2 px-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                          layoutToggle === 'topbar'
                            ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        Horizontal Top Bar
                      </button>
                    </div>
                  </div>

                  {/* Apply Changes Button (Golden CTA) */}
                  <button
                    onClick={handleApplyChanges}
                    className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Apply Changes</span>
                  </button>
                </div>

                {/* CARD 2: 3D LAYOUT ENGINE (Interactive Three.js Canvas - Screenshot 2) */}
                <div className="lg:col-span-5 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <Box className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-white">3D Layout Engine</h3>
                        <p className="text-[10px] text-slate-400">Isometric Golden Print Wireframe</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      WebGL Active
                    </span>
                  </div>

                  {/* Interactive Three.js 3D Grid Canvas */}
                  <div className="h-56 sm:h-64 w-full">
                    <ThreeLayoutEngine
                      zDepth={zDepth}
                      perspective={perspectiveCamera}
                      stackingCount={elementStacking ? 2 : 1}
                      glowShift={colorShift / 100}
                    />
                  </div>

                  {/* 3D Controls Grid */}
                  <div className="grid grid-cols-2 gap-3 pt-1 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>Z-axis Depth</span>
                        <span className="text-amber-400 font-bold">{zDepth.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="4.0"
                        step="0.1"
                        value={zDepth}
                        onChange={(e) => setZDepth(parseFloat(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                    </div>

                    <div className="flex items-center justify-between px-2 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[11px] text-slate-300 font-medium">Perspective</span>
                      <button
                        onClick={() => setPerspectiveCamera(!perspectiveCamera)}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer ${
                          perspectiveCamera ? 'bg-amber-400' : 'bg-slate-700'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                            perspectiveCamera ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="flex items-center justify-between px-2 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[11px] text-slate-300 font-medium">Element Stacking</span>
                      <span className="text-[10px] font-mono text-amber-400 font-bold">
                        {elementStacking ? '2-slice' : 'Flat'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between px-2 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[11px] text-slate-300 font-medium">Haptic Level</span>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold">{hapticLevel}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleApplyChanges}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Publish to all Devices</span>
                  </button>
                </div>

                {/* CARD 3: GLOBAL CHAT (Encrypted VIP Chat - Screenshot 1 & 2) */}
                <div className="lg:col-span-3 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col h-[440px]">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
                    <div>
                      <h3 className="font-extrabold text-sm text-white">Global Chat</h3>
                      <span className="text-[9px] font-mono font-bold tracking-wider text-amber-400/80 uppercase">
                        Encrypted VIP Network
                      </span>
                    </div>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  </div>

                  {/* Chat Message Stream */}
                  <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
                    {chatMessages.map((msg) => (
                      <div key={msg.id} className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/80 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-300 flex items-center gap-1">
                            <span>{msg.avatar}</span>
                            <span>{msg.user}</span>
                          </span>
                          <span className="text-[9px] font-mono text-slate-500">{msg.time}</span>
                        </div>
                        <p className="text-slate-300 leading-relaxed text-[11px]">{msg.text}</p>
                      </div>
                    ))}
                  </div>

                  {/* Chat Input */}
                  <form onSubmit={handleSendChat} className="pt-2 border-t border-slate-800 shrink-0 flex gap-2">
                    <input
                      type="text"
                      placeholder="Type a message..."
                      value={inputChat}
                      onChange={(e) => setInputChat(e.target.value)}
                      className="flex-1 py-1.5 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-amber-400"
                    />
                    <button
                      type="submit"
                      className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer active:scale-95 transition-all"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                  <p className="text-[8px] font-mono text-center text-slate-500 mt-2 uppercase tracking-wider">
                    Powered By FADI KING VIP
                  </p>
                </div>
              </div>

              {/* PRIMARY ROW 2: ADVANCED ICON & 3D STUDIO + VIP USER ACTIVITY + USER ACTIVITY FEED */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                {/* CARD 4: ADVANCED ICON & 3D STUDIO (Screenshot 2) */}
                <div className="lg:col-span-5 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-white">Advanced Icon & 3D Studio</h3>
                        <p className="text-[10px] text-slate-400">Beveled Metallic Gold 3D Extrusions</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-amber-400 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 font-bold">
                      STUDIO
                    </span>
                  </div>

                  {/* 3D Extruded Icon Grid */}
                  <div className="grid grid-cols-5 gap-2.5 p-3 rounded-xl bg-[#07090e] border border-slate-800">
                    {[
                      { icon: Download, label: 'Download' },
                      { icon: Users, label: 'Users' },
                      { icon: Music, label: 'Audio' },
                      { icon: Folder, label: 'Folder' },
                      { icon: Shield, label: 'Shield' },
                      { icon: Clock, label: 'Clock' },
                      { icon: FileText, label: 'File' },
                      { icon: RotateCw, label: 'Refresh' },
                      { icon: Cloud, label: 'Cloud' },
                      { icon: Box, label: 'Box' },
                    ].map((item, idx) => {
                      const IconComp = item.icon;
                      return (
                        <div
                          key={idx}
                          className="flex flex-col items-center justify-center p-2 rounded-xl bg-gradient-to-b from-slate-900 via-amber-950/20 to-slate-950 border border-amber-500/30 shadow-md shadow-black/80 group hover:scale-110 hover:border-amber-400 transition-all cursor-pointer icon-style-3d"
                        >
                          <IconComp className="w-5 h-5 text-amber-400 fill-amber-400/20 group-hover:fill-amber-400/40" />
                        </div>
                      );
                    })}
                  </div>

                  {/* 3D Studio Controls Sliders */}
                  <div className="space-y-2 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>Color Shift</span>
                        <span className="text-amber-400 font-bold">{colorShift}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={colorShift}
                        onChange={(e) => setColorShift(parseInt(e.target.value, 10))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>Line Weight</span>
                        <span className="text-amber-400 font-bold">{lineWeight.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="3.0"
                        step="0.1"
                        value={lineWeight}
                        onChange={(e) => setLineWeight(parseFloat(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span>3D Depth & Extrusion</span>
                        <span className="text-amber-400 font-bold">{depthExtrusion}%</span>
                      </div>
                      <input
                        type="range"
                        min="20"
                        max="100"
                        value={depthExtrusion}
                        onChange={(e) => setDepthExtrusion(parseInt(e.target.value, 10))}
                        className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      />
                    </div>
                  </div>

                  {/* 3D Social Icons Preview */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-xs font-bold text-slate-300">Social 3D Preview:</span>
                    <div className="flex items-center gap-2">
                      {['YouTube', 'TikTok', 'Instagram', 'Facebook'].map((p, i) => (
                        <div
                          key={i}
                          className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500/20 to-slate-900 border border-amber-400/40 flex items-center justify-center text-[10px] font-black text-amber-300 shadow-md hover:scale-110 transition-transform cursor-pointer"
                        >
                          {p[0]}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* CARD 5: VIP USER ACTIVITY (Spline Wave Chart - Screenshot 1 & 4) */}
                <div className="lg:col-span-4 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="font-extrabold text-sm text-white">VIP User Activity</h3>
                      <p className="text-[10px] text-slate-400">Concurrent VIP users load</p>
                    </div>
                    <span className="text-[11px] font-mono text-amber-400 font-black">
                      {onlineCount} Online
                    </span>
                  </div>

                  {/* Glowing Golden Spline Area Wave Chart */}
                  <div className="h-40 w-full relative flex items-end">
                    <svg className="w-full h-full overflow-visible" viewBox="0 0 300 120" preserveAspectRatio="none">
                      <defs>
                        <linearGradient id="goldWaveGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#d4af37" stopOpacity="0.45" />
                          <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.2" />
                          <stop offset="100%" stopColor="#0a0a0a" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                      <path
                        d="M0,80 Q40,30 80,70 T160,40 T240,65 T300,25 L300,120 L0,120 Z"
                        fill="url(#goldWaveGrad)"
                      />
                      <path
                        d="M0,80 Q40,30 80,70 T160,40 T240,65 T300,25"
                        fill="none"
                        stroke="#d4af37"
                        strokeWidth="3"
                        strokeLinecap="round"
                        className="drop-shadow-[0_0_8px_rgba(212,175,55,0.7)]"
                      />
                    </svg>
                  </div>

                  {/* Metric Stats Cards */}
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center">
                    <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Concurrent IP</span>
                      <span className="text-sm font-black text-amber-400 font-mono">590</span>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Data Transfer</span>
                      <span className="text-sm font-black text-emerald-400 font-mono">2.8 GB</span>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Active DL</span>
                      <span className="text-sm font-black text-amber-300 font-mono">2 alive</span>
                    </div>
                  </div>
                </div>

                {/* CARD 6: USER ACTIVITY FEED (Screenshot 1 & 4) */}
                <div className="lg:col-span-3 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h3 className="font-extrabold text-sm text-white">User Activity Feed</h3>
                    <span className="text-[9px] font-mono text-slate-400">Live Stream</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    {[
                      { user: 'VIP Member registered', action: 'Downloaded', time: '15m ago' },
                      { user: 'VIP Member registered', action: 'Downloaded', time: '18m ago' },
                      { user: 'VIP Member registered', action: 'Downloaded', time: '19m ago' },
                      { user: 'VIP Member upgraded', action: 'Lifetime pass', time: '22m ago' },
                    ].map((act, i) => (
                      <div key={i} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0 truncate">
                          <div className="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 text-[10px] font-black shrink-0">
                            👑
                          </div>
                          <div className="truncate min-w-0">
                            <span className="font-bold text-white block truncate text-[11px]">{act.user}</span>
                            <span className="text-[10px] text-slate-400">{act.action} · {act.time}</span>
                          </div>
                        </div>
                        <span className="text-[9px] font-mono font-black px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-400/30 shrink-0">
                          VIP
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* PRIMARY ROW 3: VIP PLATFORM COMPATIBILITY + MODULAR FEATURE TOGGLES */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                {/* CARD 7: VIP PLATFORM COMPATIBILITY (Screenshot 1, 2, 3, 4) */}
                <div className="lg:col-span-5 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="font-extrabold text-sm text-white">VIP Platform Compatibility</h3>
                      <p className="text-[10px] text-slate-400">Direct 8K Handshake Extractors</p>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-amber-400 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30">
                      32 Supported platforms
                    </span>
                  </div>

                  {/* 4 Large 3D Beveled Buttons with LED lights */}
                  <div className="grid grid-cols-2 gap-3.5">
                    {[
                      { name: 'YouTube', icon: Video, url: 'https://youtube.com/shorts/dQw4w9WgXcQ', color: 'from-red-600/20 to-amber-500/10' },
                      { name: 'TikTok', icon: Music, url: 'https://www.tiktok.com/@tiktok/video/7123456789', color: 'from-cyan-500/20 to-pink-500/10' },
                      { name: 'Instagram', icon: Eye, url: 'https://www.instagram.com/reel/C3test1234/', color: 'from-pink-500/20 to-amber-500/10' },
                      { name: 'Facebook', icon: Globe, url: 'https://www.facebook.com/watch/?v=123456789', color: 'from-blue-600/20 to-cyan-500/10' },
                    ].map((plat, idx) => {
                      const PlatIcon = plat.icon;
                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            playClickSound();
                            onSelectPlatform(plat.url);
                          }}
                          className={`relative p-4 rounded-2xl bg-gradient-to-br ${plat.color} border border-amber-500/30 hover:border-amber-400/80 shadow-xl shadow-black/80 flex flex-col items-center justify-center gap-2 group hover:scale-105 active:scale-95 transition-all cursor-pointer`}
                        >
                          {/* Golden LED Indicator Dot */}
                          <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#d4af37] animate-pulse" />
                          <div className="w-10 h-10 rounded-xl bg-slate-900/90 border border-amber-500/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <PlatIcon className="w-5 h-5 text-amber-400" />
                          </div>
                          <span className="font-extrabold text-sm text-white group-hover:text-amber-300">
                            {plat.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* CARD 8: MODULAR FEATURE TOGGLES & BLUEPRINT (Screenshot 3) */}
                <div className="lg:col-span-7 rounded-2xl bg-[#0b0e17]/95 border border-amber-500/30 p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="font-extrabold text-sm text-white">Modular Feature Toggle Screen</h3>
                      <p className="text-[10px] text-slate-400">Layout blueprint & dynamic extensions</p>
                    </div>
                    <button
                      onClick={handleApplyChanges}
                      className="px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold hover:bg-amber-500/30"
                    >
                      Apply Modular Changes
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {[
                      { key: 'globalChat', label: 'Global Chat', desc: 'Encrypted GLOBAL CHAT feed' },
                      { key: 'realTimeAnalytics', label: 'Real-time Analytics', desc: 'Real time online display bar' },
                      { key: 'vipMembership', label: 'VIP Membership System', desc: 'VIP Membership System' },
                      { key: 'liveCustomizer', label: 'Live Customizer (Self)', desc: 'Download VIP Customizer' },
                      { key: 'downloadAccelerator', label: 'Download Accelerator', desc: 'Download Accelerator Engine' },
                      { key: 'platformSync', label: 'Platform Compatibility Sync', desc: 'High priority platform sync' },
                    ].map((fItem) => (
                      <div
                        key={fItem.key}
                        className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <span className="font-bold text-white block truncate">{fItem.label}</span>
                          <span className="text-[10px] text-slate-400 truncate block">{fItem.desc}</span>
                        </div>
                        <button
                          onClick={() => {
                            playClickSound();
                            setFeatures((prev: any) => ({ ...prev, [fItem.key]: !prev[fItem.key] }));
                          }}
                          className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer shrink-0 ${
                            (features as any)[fItem.key] ? 'bg-amber-400' : 'bg-slate-700'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                              (features as any)[fItem.key] ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Blueprint Layout Preview */}
                  <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/20 space-y-2">
                    <span className="text-[10px] font-mono text-amber-400/80 uppercase font-bold">
                      Real-time Layout Blueprint
                    </span>
                    <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-mono">
                      <div className="col-span-4 p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300">
                        Hero Banner & Direct Downloader (8K ULTRA)
                      </div>
                      <div className="col-span-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                        Featured Panels
                      </div>
                      <div className="col-span-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                        Global Chat Feed
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 2 & 5: DIRECT UNIVERSAL MEDIA DOWNLOADER ENGINE */}
          {(activeTab === 'downloader' || sidebarItem === 'downloader_direct') && (
            <div className="rounded-3xl bg-[#0b0e17]/95 border-2 border-amber-500/30 p-5 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                    <Crown className="w-6 h-6 text-amber-400 fill-amber-400" />
                    <span>FADI KING VIP Universal Media Downloader</span>
                  </h2>
                  <p className="text-xs text-amber-200/80 font-mono mt-0.5">
                    8K Ultra HDR · 4K 60FPS · 320kbps Studio Audio · Zero Watermark
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-3 py-1 rounded-xl bg-amber-500/15 border border-amber-500/35 text-amber-300">
                    {quotaRemaining}/5 Free Downloads
                  </span>
                  <button
                    onClick={() => {
                      playClickSound();
                      onOpenUpgrade();
                    }}
                    className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs active:scale-95"
                  >
                    Upgrade VIP
                  </button>
                </div>
              </div>

              {/* Mode Switcher Tabs */}
              <div className="flex items-center gap-2 p-1 rounded-2xl bg-slate-950 border border-slate-800 max-w-md">
                <button
                  onClick={() => onModeChange('single')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    activeMode === 'single'
                      ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Single Video
                </button>
                <button
                  onClick={() => onModeChange('batch')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    activeMode === 'batch'
                      ? 'bg-emerald-400 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Batch Queue
                </button>
                <button
                  onClick={() => onModeChange('studio')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    activeMode === 'studio'
                      ? 'bg-cyan-400 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Studio Audio
                </button>
              </div>

              {/* Single Mode Input */}
              {activeMode === 'single' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                      Paste Media Link (YouTube, TikTok, Instagram, Facebook, X, etc.)
                    </label>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="url"
                        placeholder="https://www.instagram.com/reel/... or https://youtube.com/watch?v=..."
                        value={currentUrl}
                        onChange={(e) => onUrlChange(e.target.value)}
                        className="flex-1 py-3.5 px-4 rounded-2xl bg-slate-950 border border-amber-500/40 text-sm text-white placeholder-slate-500 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20"
                      />
                      <button
                        onClick={() => {
                          playClickSound();
                          onAnalyze(currentUrl);
                        }}
                        disabled={isAnalyzing || !currentUrl.trim()}
                        className="py-3.5 px-8 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-300 disabled:opacity-50 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/30 active:scale-95 transition-all cursor-pointer min-w-[150px]"
                      >
                        {isAnalyzing ? (
                          <span className="animate-spin">⏳ Analyzing...</span>
                        ) : (
                          <>
                            <Download className="w-4 h-4 stroke-[2.5]" />
                            <span>Download 8K</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Recent Downloads History */}
                  {history.length > 0 && (
                    <div className="pt-4 border-t border-slate-800">
                      <DownloadHistory
                        history={history}
                        onReDownload={onReDownload}
                        onClearHistory={onClearHistory}
                        lang={lang}
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Batch Downloader Mode */}
              {activeMode === 'batch' && (
                <BatchDownloader
                  lang={lang}
                  onDownloadStarted={onDownloadStarted}
                  hasJoinedWhatsapp={hasUnlockedGate}
                  onRequireWhatsappJoin={onRequireWhatsappJoin}
                />
              )}

              {/* Studio Audio Mode */}
              {activeMode === 'studio' && (
                <AudioStudio
                  lang={lang}
                  videoInfo={videoInfo}
                  onDownloadStarted={onDownloadStarted}
                  hasJoinedWhatsapp={hasUnlockedGate}
                  onRequireWhatsappJoin={onRequireWhatsappJoin}
                  onRequireUpgrade={onRequireUpgrade}
                />
              )}
            </div>
          )}

          {/* TAB 3: REAL-TIME ANALYTICS TAB */}
          {activeTab === 'analytics' && (
            <div className="rounded-3xl bg-[#0b0e17]/95 border border-amber-500/30 p-6 shadow-2xl space-y-6">
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-amber-400" />
                <span>Real-time Network Analytics</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                  <span className="text-xs text-slate-400">Total VIP Users</span>
                  <p className="text-2xl font-black text-amber-400 font-mono mt-1">2,511</p>
                  <span className="text-[10px] text-emerald-400 font-bold">+18% this week</span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                  <span className="text-xs text-slate-400">Today's Downloads</span>
                  <p className="text-2xl font-black text-emerald-400 font-mono mt-1">19,783</p>
                  <span className="text-[10px] text-emerald-400 font-bold">100% Success Rate</span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                  <span className="text-xs text-slate-400">Active Live Nodes</span>
                  <p className="text-2xl font-black text-cyan-400 font-mono mt-1">493 Active</p>
                  <span className="text-[10px] text-cyan-300 font-bold">SG-VIP Server 0.4ms</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: USERS MANAGEMENT TAB */}
          {activeTab === 'users' && (
            <div className="rounded-3xl bg-[#0b0e17]/95 border border-amber-500/30 p-6 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-400" />
                  <span>VIP Members Directory</span>
                </h2>
                <button
                  onClick={onOpenUpgrade}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs"
                >
                  Issue VIP Pass
                </button>
              </div>

              <div className="space-y-2">
                {[
                  { name: 'VIP Super Admin', role: 'Owner', quota: 'Unlimited', status: 'Online' },
                  { name: 'Fadi Member #102', role: 'Lifetime VIP', quota: 'Unlimited', status: 'Active' },
                  { name: 'Global Guest #882', role: 'Free User', quota: '3/5 Left', status: 'Active' },
                ].map((u, i) => (
                  <div key={i} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white text-sm block">{u.name}</span>
                      <span className="text-xs text-amber-400/80">{u.role} · {u.quota}</span>
                    </div>
                    <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                      {u.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* 3. MOBILE EXECUTIVE BOTTOM DOCK (Matching Phone Mockup in Screenshots) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0a0d14]/98 border-t border-amber-500/30 backdrop-blur-2xl py-2 px-6 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => {
            playClickSound();
            setMobileBottomTab('chat');
            setActiveTab('admin');
            setSidebarItem('home');
          }}
          className={`flex flex-col items-center gap-1 text-[11px] font-bold ${
            mobileBottomTab === 'chat' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          <span>Chat</span>
        </button>

        <button
          onClick={() => {
            playClickSound();
            setMobileBottomTab('downloads');
            setActiveTab('downloader');
            setSidebarItem('downloader_direct');
          }}
          className={`flex flex-col items-center gap-1 text-[11px] font-bold ${
            mobileBottomTab === 'downloads' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Download className="w-5 h-5" />
          <span>Downloads</span>
        </button>

        <button
          onClick={() => {
            playClickSound();
            setMobileBottomTab('live');
            setActiveTab('admin');
            setSidebarItem('3d_layout');
          }}
          className={`flex flex-col items-center gap-1 text-[11px] font-bold ${
            mobileBottomTab === 'live' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Radio className="w-5 h-5" />
          <span>Live 3D</span>
        </button>

        <button
          onClick={() => {
            playClickSound();
            setMobileBottomTab('profile');
            onOpenUpgrade();
          }}
          className={`flex flex-col items-center gap-1 text-[11px] font-bold ${
            mobileBottomTab === 'profile' ? 'text-amber-400' : 'text-slate-400'
          }`}
        >
          <Crown className="w-5 h-5" />
          <span>Profile</span>
        </button>
      </div>
    </div>
  );
};
